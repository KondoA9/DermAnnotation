#include "UIEditorView.h"

void UIEditorView::updateInputEvents() {
	if (mouseCondition().hover && mouseCondition().left.down) {
		m_paintStarted = true;
		registerInputEvent(PaintStart(this));
	}

	if (m_paintStarted) {
		if (!mouseCondition().hover || mouseCondition().left.up) {
			m_paintStarted = false;
			registerInputEvent(PaintEnd(this));
		}
		else if (currentPixel() != prePixel()) {
			registerInputEvent(Painting(this));
		}
	}

	UIZStackedImageView::updateInputEvents();
}
