#pragma once

#include <GUIKit.h>

class UIEditorView final : public gui::UIZStackedImageView {
public:
	GUICreateInputEvent(PaintStart);
	GUICreateInputEvent(Painting);
	GUICreateInputEvent(PaintEnd);

private:
	bool m_paintStarted = false;

protected:
	void updateInputEvents() override;
};
