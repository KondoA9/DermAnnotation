#include "UIEditorControllerView.h"

void UIEditorControllerView::initialize() {
	setChildConstraints();
	appendComponents();

	UIView::initialize();
}

void UIEditorControllerView::release() {
	ui_pencilBoxView.release();
	ui_imageMoveView.release();
}

void UIEditorControllerView::setPencilAlphaRate(double value) {
	ui_allPencilsAlphaRateSlider.setValue(value);

	for (size_t i : step(ui_pencilBoxView.pencilCount())) {
		setPencilAlphaRate(i, value);
	}

	setAllPencilAlphaRateValueLabel(value);
}

void UIEditorControllerView::setChildConstraints() {
	const double hRate = 0.04, hConst = 15_px;

	// Change file
	const double w = 100_px;
	ui_changeFileBackButton.setConstraint(gui::LayerDirection::Top, *this, gui::LayerDirection::Top);
	ui_changeFileBackButton.setConstraint(gui::LayerDirection::Height, *this, gui::LayerDirection::Height, hConst, hRate);
	ui_changeFileBackButton.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left);
	ui_changeFileBackButton.setConstraint(gui::LayerDirection::Width, w);

	ui_changeFileLabel.setConstraint(gui::LayerDirection::Top, *this, gui::LayerDirection::Top);
	ui_changeFileLabel.setConstraint(gui::LayerDirection::Height, *this, gui::LayerDirection::Height, hConst, hRate);
	ui_changeFileLabel.setConstraint(gui::LayerDirection::Left, ui_changeFileBackButton, gui::LayerDirection::Right);
	ui_changeFileLabel.setConstraint(gui::LayerDirection::Right, ui_changeFileNextButton, gui::LayerDirection::Left);

	ui_changeFileNextButton.setConstraint(gui::LayerDirection::Top, *this, gui::LayerDirection::Top);
	ui_changeFileNextButton.setConstraint(gui::LayerDirection::Height, *this, gui::LayerDirection::Height, hConst, hRate);
	ui_changeFileNextButton.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);
	ui_changeFileNextButton.setConstraint(gui::LayerDirection::Width, w);

	// Change folder
	ui_changeFolderBackButton.setConstraint(gui::LayerDirection::Top, ui_changeFileLabel, gui::LayerDirection::Bottom);
	ui_changeFolderBackButton.setConstraint(gui::LayerDirection::Height, *this, gui::LayerDirection::Height, hConst, hRate);
	ui_changeFolderBackButton.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left);
	ui_changeFolderBackButton.setConstraint(gui::LayerDirection::Width, w);

	ui_changeFolderLabel.setConstraint(gui::LayerDirection::Top, ui_changeFileLabel, gui::LayerDirection::Bottom);
	ui_changeFolderLabel.setConstraint(gui::LayerDirection::Height, *this, gui::LayerDirection::Height, hConst, hRate);
	ui_changeFolderLabel.setConstraint(gui::LayerDirection::Left, ui_changeFolderBackButton, gui::LayerDirection::Right);
	ui_changeFolderLabel.setConstraint(gui::LayerDirection::Right, ui_changeFolderNextButton, gui::LayerDirection::Left);

	ui_changeFolderNextButton.setConstraint(gui::LayerDirection::Top, ui_changeFileLabel, gui::LayerDirection::Bottom);
	ui_changeFolderNextButton.setConstraint(gui::LayerDirection::Height, *this, gui::LayerDirection::Height, hConst, hRate);
	ui_changeFolderNextButton.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);
	ui_changeFolderNextButton.setConstraint(gui::LayerDirection::Width, w);

	// Pencil controller
	ui_pencilBoxView.drawFrame = true;
	ui_pencilBoxView.setConstraint(gui::LayerDirection::Top, ui_changeFolderLabel, gui::LayerDirection::Bottom);
	ui_pencilBoxView.setConstraint(gui::LayerDirection::Height, *this, gui::LayerDirection::Height, 0.0, 0.35);
	ui_pencilBoxView.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left);
	ui_pencilBoxView.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);

	// Sliders
	ui_pencilRadiusSlider.setConstraint(gui::LayerDirection::Top, ui_pencilBoxView, gui::LayerDirection::Bottom);
	ui_pencilRadiusSlider.setConstraint(gui::LayerDirection::Height, *this, gui::LayerDirection::Height, hConst, hRate);
	ui_pencilRadiusSlider.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left, 10_px);
	ui_pencilRadiusSlider.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right, -80_px);

	ui_allPencilsAlphaRateSlider.setConstraint(gui::LayerDirection::Top, ui_pencilRadiusSlider, gui::LayerDirection::Bottom);
	ui_allPencilsAlphaRateSlider.setConstraint(gui::LayerDirection::Height, *this, gui::LayerDirection::Height, hConst, hRate);
	ui_allPencilsAlphaRateSlider.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left, 10_px);
	ui_allPencilsAlphaRateSlider.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right, -80_px);

	ui_editorScalingSlider.setConstraint(gui::LayerDirection::Top, ui_allPencilsAlphaRateSlider, gui::LayerDirection::Bottom);
	ui_editorScalingSlider.setConstraint(gui::LayerDirection::Height, *this, gui::LayerDirection::Height, hConst, hRate);
	ui_editorScalingSlider.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left, 10_px);
	ui_editorScalingSlider.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right, -80_px);

	// Slider value
	ui_pencilRadiusValueLabel.setConstraint(gui::LayerDirection::CenterY, ui_pencilRadiusSlider, gui::LayerDirection::CenterY);
	ui_pencilRadiusValueLabel.setConstraint(gui::LayerDirection::CenterX, ui_editorScaleValueLabel, gui::LayerDirection::CenterX);

	ui_pencilAlphaRateValueLabel.setConstraint(gui::LayerDirection::Top, ui_allPencilsAlphaRateSlider, gui::LayerDirection::Top);
	ui_pencilAlphaRateValueLabel.setConstraint(gui::LayerDirection::Bottom, ui_allPencilsAlphaRateSlider, gui::LayerDirection::Bottom);
	ui_pencilAlphaRateValueLabel.setConstraint(gui::LayerDirection::Left, ui_allPencilsAlphaRateSlider, gui::LayerDirection::Right);
	ui_pencilAlphaRateValueLabel.setConstraint(gui::LayerDirection::Width, 80_px);

	ui_editorScaleValueLabel.setConstraint(gui::LayerDirection::Top, ui_editorScalingSlider, gui::LayerDirection::Top);
	ui_editorScaleValueLabel.setConstraint(gui::LayerDirection::Bottom, ui_editorScalingSlider, gui::LayerDirection::Bottom);
	ui_editorScaleValueLabel.setConstraint(gui::LayerDirection::Left, ui_editorScalingSlider, gui::LayerDirection::Right);
	ui_editorScaleValueLabel.setConstraint(gui::LayerDirection::Width, 80_px);

	// Image movement view
	ui_imageMoveView.drawFrame = true;
	ui_imageMoveView.setConstraint(gui::LayerDirection::Top, ui_editorScalingSlider, gui::LayerDirection::Bottom);
	ui_imageMoveView.setConstraint(gui::LayerDirection::Bottom, *this, gui::LayerDirection::Bottom);
	ui_imageMoveView.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left);
	ui_imageMoveView.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);
}

void UIEditorControllerView::appendComponents() {
	UIView::appendComponent(ui_changeFileBackButton);
	UIView::appendComponent(ui_changeFileNextButton);
	UIView::appendComponent(ui_changeFileLabel);
	UIView::appendComponent(ui_changeFolderBackButton);
	UIView::appendComponent(ui_changeFolderNextButton);
	UIView::appendComponent(ui_changeFolderLabel);

	UIView::appendComponent(ui_pencilBoxView);

	UIView::appendComponent(ui_pencilRadiusSlider);
	UIView::appendComponent(ui_allPencilsAlphaRateSlider);
	UIView::appendComponent(ui_editorScalingSlider);

	UIView::appendComponent(ui_pencilRadiusValueLabel);
	UIView::appendComponent(ui_pencilAlphaRateValueLabel);
	UIView::appendComponent(ui_editorScaleValueLabel);

	UIView::appendComponent(ui_imageMoveView);
}
