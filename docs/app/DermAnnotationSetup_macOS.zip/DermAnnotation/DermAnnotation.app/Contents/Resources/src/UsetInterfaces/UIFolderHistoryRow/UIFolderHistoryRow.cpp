#include "UIFolderHistoryRow.h"

UIFolderHistoryRow::UIFolderHistoryRow(const FolderHistory::FolderData& folderData) :
	UIRect(gui::DynamicColor::Clear),
	m_folderData(folderData)
{
	m_folderNameFont = gui::UnifiedFont::Get(gui::UnifiedFontStyle::Medium);
	m_folderPathFont = gui::UnifiedFont::Get(gui::UnifiedFontStyle::Small);
}

void UIFolderHistoryRow::initialize() {
	addEventListener<gui::MouseEvent::Hovered>([this] {
		backgroundColor.highlight(gui::DynamicColor::BackgroundHovered);
		});

	addEventListener<gui::MouseEvent::UnHovered>([this] {
		backgroundColor.lowlight(gui::DynamicColor::Clear);
		});

	gui::UIRect::initialize();
}

void UIFolderHistoryRow::updateLayer(const Rect& scissor) {
	gui::UIRect::updateLayer(scissor);
	m_border = Line(rect().x, rect().y, rect().x + rect().w, rect().y);
}

void UIFolderHistoryRow::draw() {
	gui::UIRect::draw();

	m_border.draw(1.0, gui::DynamicColor::Separator);

	const double h = rect().h * 0.25;
	m_folderNameFont(FileSystem::BaseName(m_folderData.path)).draw(Arg::leftCenter(rect().x + 50_px, rect().center().y - h), gui::DynamicColor::Text);
	m_folderPathFont(m_folderData.path).draw(Arg::leftCenter(rect().x + 80_px, rect().center().y + h), gui::DynamicColor::Text);
	m_folderPathFont(m_folderData.datetime).draw(Arg::rightCenter(rect().x + rect().w - 30_px, rect().center().y - h), gui::DynamicColor::Text);
}
