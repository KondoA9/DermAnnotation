#include "TIFFImageIO.h"

#include "TIFFInfo.h"

#include <thread>
#include <future>

namespace ImageIO::TIFFImage {
	namespace Internal {
		Image loadScanlineTIFF(TIFF* tiff, const TIFFInfo& tiffInfo) {
			Image image(tiffInfo.width, tiffInfo.height, Color(255, 255, 255, 0));

			uint8* line = static_cast<uint8*>(_TIFFmalloc(tiffInfo.scanlineSize));
			for (uint32 y = 0; y < tiffInfo.height; ++y) {
				if (TIFFReadScanline(tiff, line, y, 0) < 0) {
					break;
				}

				auto row = image[y];

				for (uint32 x = 0; x < tiffInfo.width; ++x) {
					const int x4 = x * 4;

					row[x].a = line[x4 + 3];

					if (row[x].a == 0) {
						row[x].r = row[x].g = row[x].b = 255;
					}
					else {
						row[x].r = line[x4];
						row[x].g = line[x4 + 1];
						row[x].b = line[x4 + 2];
					}
				}
			}
			_TIFFfree(line);

			return image;
		}

		Image loadStripTIFF(TIFF* tiff, const TIFFInfo& tiffInfo) {
			Image image(tiffInfo.width, tiffInfo.height, Color(255, 255, 255, 0));

			tdata_t buf = _TIFFmalloc(tiffInfo.stripSize);

			for (tstrip_t strip = 0; strip < tiffInfo.strips; ++strip) {
				if (TIFFReadRawStrip(tiff, strip, buf, static_cast<tsize_t>(-1)) == -1) {
					break;
				}

				const uint32 rows = strip * tiffInfo.rowsPerStrip;
				const uint8* buffer = static_cast<uint8*>(buf);

				for (uint32 row = 0; row < tiffInfo.rowsPerStrip && rows + row < tiffInfo.height; ++row) {
					const size_t y = static_cast<size_t>(strip) * tiffInfo.rowsPerStrip + row;

					for (uint32 x = 0; x < tiffInfo.width; ++x) {
						const uint32 x4 = row * tiffInfo.width + x * 4;
						image[y][x].r = buffer[x4];
						image[y][x].g = buffer[x4 + 1];
						image[y][x].b = buffer[x4 + 2];
						image[y][x].a = buffer[x4 + 3];
					}
				}
			}

			_TIFFfree(buf);

			return image;
		}

		Image loadTiledTIFF(TIFF*, const TIFFInfo&) {
			return Image();
		}

		Array<Array<uint8>> ImageToBuffer(int samples, int width, int height, const Image& image) {
			Array<Array<uint8>> buffer(height, Array<uint8>(width * samples));

#pragma omp parallel for
			for (int y = 0; y < height; ++y) {
				auto& buf = buffer[y];
				const auto row = image[y];

#pragma omp parallel for
				for (int x = 0; x < width; ++x) {
					const size_t c = static_cast<size_t>(x * samples);

					buf[c] = row[x].r;
					buf[c + 1] = row[x].g;
					buf[c + 2] = row[x].b;
					buf[c + 3] = row[x].a;
				}
			}

			return buffer;
		}
	}

	DermImage Load(const String& path) {
		const std::string str = path.narrow();
		TIFF* tif = TIFFOpen(str.c_str(), "r");

		if (!tif) {
			return DermImage(0, 0);
		}

		const TIFFInfo tiffInfo(tif);
		const size_t layerCount = static_cast<size_t>(tiffInfo.directories - 1);
		TIFFClose(tif);

		DermImage dermImage = DermImage(tiffInfo.width, tiffInfo.height);

		// Initialize layers
		for (size_t i = 0; i < layerCount; i++) {
			dermImage.appendEmptyLayer();
		}

		// Load images
		Array<std::thread> threads;
		for (size_t i = 0; i < layerCount + 1; ++i) {
			threads.emplace_back([=, &dermImage]() {
				TIFF* tiff = TIFFOpen(str.c_str(), "r");

				// Skip pages
				for (size_t l = 0; l < i; ++l) {
					TIFFReadDirectory(tiff);
				}

				// Read image
				Image image;
				switch (tiffInfo.arrayType) {
				case TIFFArrayType::Scanline:
					image = Internal::loadScanlineTIFF(tiff, tiffInfo);
					break;

				case TIFFArrayType::Strip:
					image = Internal::loadStripTIFF(tiff, tiffInfo);
					break;

				case TIFFArrayType::Tiled:
					image = Internal::loadTiledTIFF(tiff, tiffInfo);
					break;

				default:
					image = Image();
					break;
				}

				// Original image
				if (i == 0) {
					dermImage.setOriginalImage(image);
				}
				// Layers
				else {
					// Get pencil info
					const char* pagename = NULL;
					TIFFGetField(tiff, TIFFTAG_PAGENAME, &pagename);
					dermImage.readPencilInfo(i - 1, pagename);

					// Set image
					dermImage.setLayer(i - 1, image);
				}

				TIFFClose(tiff);
				});
		}

		for (auto& t : threads) {
			t.join();
		}

		return dermImage;
	}

	bool Save(const String& path, const DermImage& dermImage) {
		if (!FileSystem::Exists(FileSystem::ParentPath(path))) {
			FileSystem::CreateDirectories(FileSystem::ParentPath(path));
		}

		TIFF* out = TIFFOpen(path.narrow().c_str(), "w");

		if (out && dermImage.layerCount() > 0) {
			const size_t pagesCount = dermImage.layerCount() + 1;
			const int height = dermImage.size().y;
			const int width = dermImage.size().x;
			const int nsamples = 4;

			// Writer
			Array<std::future<Array<Array<uint8>>>> threads;
			for (size_t page = 0; page < pagesCount; page++) {
				threads.emplace_back(std::async(std::launch::async, Internal::ImageToBuffer, nsamples, width, height, (page == 0 ? dermImage.originalImage() : dermImage.layer(page - 1).image())));
			}

			for (size_t page : step(threads.size())) {
				TIFFSetField(out, TIFFTAG_SOFTWARE, "DermAnnotation");
				TIFFSetField(out, TIFFTAG_IMAGELENGTH, height);
				TIFFSetField(out, TIFFTAG_IMAGEWIDTH, width);
				TIFFSetField(out, TIFFTAG_PLANARCONFIG, PLANARCONFIG_CONTIG);
				TIFFSetField(out, TIFFTAG_PHOTOMETRIC, PHOTOMETRIC_RGB);
				TIFFSetField(out, TIFFTAG_SAMPLESPERPIXEL, nsamples);
				TIFFSetField(out, TIFFTAG_COMPRESSION, COMPRESSION_LZW);
				TIFFSetField(out, TIFFTAG_BITSPERSAMPLE, 8);
				TIFFSetField(out, TIFFTAG_ROWSPERSTRIP, TIFFDefaultStripSize(out, width * nsamples));
				TIFFSetField(out, TIFFTAG_SUBFILETYPE, FILETYPE_PAGE);
				TIFFSetField(out, TIFFTAG_PAGENUMBER, page, pagesCount);
				if (page != 0) {
					TIFFSetField(out, TIFFTAG_PAGENAME, dermImage.layer(page - 1).getTiffPageName().c_str());
				}

				auto buf = threads[page].get();
				for (int row = 0; row < height; row++) {
					TIFFWriteScanline(out, buf[row].data(), row);
				}

				TIFFWriteDirectory(out);
			}

			TIFFClose(out);
			return true;
		}

		return false;
	}
}
