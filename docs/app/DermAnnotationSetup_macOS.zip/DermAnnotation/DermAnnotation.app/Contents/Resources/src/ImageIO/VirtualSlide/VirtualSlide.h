#pragma once

#include "../../DermImage/DermImage.h"

#include <Siv3D.hpp>

namespace ImageIO::VirtualSlide {
	DermImage Load(const String& path);
}
