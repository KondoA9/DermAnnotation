#include <Siv3D.hpp>

namespace CommandExecuter {
	bool Execute(const String& command);
}
