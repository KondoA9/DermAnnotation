#pragma once

#include "../../Storage/FolderHistory/FolderHistory.h"

#include <GUIKit.h>

class UIFolderHistoryRow final : public gui::UIRect {
	const FolderHistory::FolderData m_folderData;

	Line m_border;

	Font m_folderNameFont, m_folderPathFont;

public:
	UIFolderHistoryRow(const FolderHistory::FolderData& folderData);

	void initialize() override;

	void updateLayer(const Rect& scissor) override;

	void draw() override;
};
