#include "UIControllButtonsView.h"

void UIControllButtonsTopView::initialize() {
	appendComponent(ui_toggleFilesViewButton);
}

void UIControllButtonsBottomView::initialize() {
	appendComponent(ui_trashButton);
	appendComponent(ui_redoButton);
	appendComponent(ui_undoButton);
	appendComponent(ui_toggleAreaSelectorButton);
	appendComponent(ui_toggleEraserButton);
}

void UIControllButtonsBottomView::setEraserEnabled(bool enabled) {
	if (ui_toggleEraserButton.isEnabled() != enabled) {
		ui_toggleEraserButton.setEnabled(enabled);
		if (m_eraserChangedHandler) {
			m_eraserChangedHandler();
		}
	}
}

void UIControllButtonsView::initialize() {
	ui_topView.setRowHeight(70_px);

	ui_bottomView.setRowHeight(70_px);
	ui_bottomView.setLeadingDirection(gui::LeadingDirection::Bottom);

	appendComponent(ui_topView);
	appendComponent(ui_bottomView);
}

void UIControllButtonsBottomView::setEraserChangedHandler(const std::function<void()>& handler) {
	m_eraserChangedHandler = handler;
	ui_toggleEraserButton.addEventListener<gui::MouseEvent::LeftDown>(handler);
}
