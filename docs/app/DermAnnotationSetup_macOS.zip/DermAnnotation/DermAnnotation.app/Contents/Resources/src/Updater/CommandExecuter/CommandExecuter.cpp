#include "CommandExecuter.h"

#if SIV3D_PLATFORM(WINDOWS)
#include <Siv3D/Windows.hpp>
#endif

namespace CommandExecuter {
	bool Execute(const String& command) {
#if SIV3D_PLATFORM(WINDOWS)
		STARTUPINFO  si;
		PROCESS_INFORMATION pi;

		memset(&si, 0, sizeof(si));
		si.cb = sizeof(si);
		si.dwFlags = STARTF_USESHOWWINDOW;
		si.wShowWindow = SW_HIDE;

		std::wstring cmd = command.toWstr();
		const auto result = CreateProcess(NULL, cmd.data(), NULL, NULL, FALSE,
			CREATE_DEFAULT_ERROR_MODE | NORMAL_PRIORITY_CLASS,
			NULL, NULL, &si, &pi);

		const auto hWndmain = pi.hProcess;
		CloseHandle(pi.hThread);

		WaitForSingleObject(hWndmain, INFINITE);
		CloseHandle(hWndmain);

		return static_cast<bool>(result);
        
#elif SIV3D_PLATFORM(MACOS)
        return system(command.narrow().c_str()) == 0;
#endif
        
        return false;
	}
}
