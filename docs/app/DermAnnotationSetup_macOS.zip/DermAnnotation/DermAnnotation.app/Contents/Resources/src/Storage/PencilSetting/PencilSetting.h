#pragma once

#include "../../DermImage/Pencil.h"

struct PencilBox {
	String name;
	Array<Pencil> pencils;
};

namespace PencilSetting {
	Array<PencilBox> GetSettings();

	/// <summary>
	/// Export the setting to the specified folder
	/// </summary>
	/// <param name="pencilBox"></param>
	/// <param name="directory"></param>
	/// <returns></returns>
	bool Export(const PencilBox& pencilBox, const FilePath& directory);

	/// <summary>
	/// Export all settings to the specified folder
	/// </summary>
	/// <param name="directory">Save direction</param>
	/// <returns>True if export succeeded</returns>
	bool ExportAllSettings(const FilePath& directory);

	/// <summary>
	/// Save setting to application
	/// </summary>
	/// <param name="pencilBox"></param>
	/// <returns></returns>
	bool SaveSetting(const PencilBox& pencilBox);

	bool SaveSetting(const String& name, const Array<Pencil>& pencils);

	bool ImportFromFile(const FilePath& path);

	// void Remove()
};
