#include "UIPencilEditorView.h"
#include "../UINotifier/UINotifier.h"

void UIPencilEditorView::setup(const Array<Pencil>& pencils) {
	m_pencils = pencils;

	setViewType(ViewType::Edit);
}

void UIPencilEditorView::initialize() {
	ui_title.drawFrame = true;
	ui_title.setConstraint(gui::LayerDirection::Top, *this, gui::LayerDirection::Top);
	ui_title.setConstraint(gui::LayerDirection::Height, 50_px);
	ui_title.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left);
	ui_title.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);

	ui_closeButton.setConstraint(gui::LayerDirection::Top, *this, gui::LayerDirection::Top);
	ui_closeButton.setConstraint(gui::LayerDirection::Height, ui_title, gui::LayerDirection::Height);
	ui_closeButton.setConstraint(gui::LayerDirection::Width, ui_title, gui::LayerDirection::Height);
	ui_closeButton.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);
	ui_closeButton.addEventListener<gui::MouseEvent::LeftDown>([this] {
		hidden = true;
		UINotifier::Hide();
		});

	ui_menu.drawFrame = true;
	ui_menu.setRowHeight(40_px);
	ui_menu.setConstraint(gui::LayerDirection::Top, ui_title, gui::LayerDirection::Bottom);
	ui_menu.setConstraint(gui::LayerDirection::Bottom, *this, gui::LayerDirection::Bottom);
	ui_menu.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left);
	ui_menu.setConstraint(gui::LayerDirection::Width, 200_px);

	ui_menu.appendTemporaryComponent(createMenu(U"編集", ViewType::Edit));
	ui_menu.appendTemporaryComponent(createMenu(U"設定", ViewType::Setting));
	ui_menu.appendTemporaryComponent(createMenu(U"保存", ViewType::Save));

	// view
	ui_editView.setConstraint(gui::LayerDirection::Top, ui_title, gui::LayerDirection::Bottom);
	ui_editView.setConstraint(gui::LayerDirection::Bottom, *this, gui::LayerDirection::Bottom);
	ui_editView.setConstraint(gui::LayerDirection::Left, ui_menu, gui::LayerDirection::Right);
	ui_editView.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);

	ui_settingView.setConstraint(gui::LayerDirection::Top, ui_title, gui::LayerDirection::Bottom);
	ui_settingView.setConstraint(gui::LayerDirection::Bottom, *this, gui::LayerDirection::Bottom);
	ui_settingView.setConstraint(gui::LayerDirection::Left, ui_menu, gui::LayerDirection::Right);
	ui_settingView.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);

	ui_saveView.setConstraint(gui::LayerDirection::Top, ui_title, gui::LayerDirection::Bottom);
	ui_saveView.setConstraint(gui::LayerDirection::Bottom, *this, gui::LayerDirection::Bottom);
	ui_saveView.setConstraint(gui::LayerDirection::Left, ui_menu, gui::LayerDirection::Right);
	ui_saveView.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);

	appendComponent(ui_editView);
	appendComponent(ui_settingView);
	appendComponent(ui_saveView);

	appendComponent(ui_menu);
	appendComponent(ui_title);
	appendComponent(ui_closeButton);
}

gui::UIToggleButton UIPencilEditorView::createMenu(const String& label, ViewType type) {
	auto menu = gui::UIToggleButton(label, gui::DynamicColor::Background, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text, gui::DynamicColor::ButtonPushed);
	menu.addEventListener <gui::MouseEvent::LeftDown>([this, type] {
		setViewType(type);
		});

	return menu;
}

void UIPencilEditorView::setViewType(ViewType type) {
	for (auto c : ui_menu.components()) {
		static_cast<gui::UIToggleButton*>(c)->setEnabled(false);
	}

	static_cast<gui::UIToggleButton*>(ui_menu.components()[static_cast<size_t>(type)])->setEnabled(true);

	ui_editView.hidden = type != ViewType::Edit;
	ui_settingView.hidden = type != ViewType::Setting;
	ui_saveView.hidden = type != ViewType::Save;

	switch (type)
	{
	case UIPencilEditorView::ViewType::Edit:
		ui_editView.setup(m_pencils);
		break;

	case UIPencilEditorView::ViewType::Setting:
		ui_settingView.setup();
		break;

	case UIPencilEditorView::ViewType::Save:
		ui_saveView.setup(m_pencils);
		break;

	default:
		break;
	}
}
