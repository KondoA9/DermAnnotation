#pragma once

#include "../../UsetInterfaces/UIMenubar/UIMenubar.h"
#include "../../UsetInterfaces/UISettingCheckBox/UISettingCheckBox.h"
#include "../../UsetInterfaces/UISettingInputField/UISettingInputField.h"

#include <GUIKit.h>

class SettingPage : public gui::Page {
    UIMenubar ui_menubar = UIMenubar();

    gui::UIVStackView ui_settingStackView = gui::UIVStackView();

	UISettingInputField ui_saveDirection = UISettingInputField(U"規定の保存先", U"編集したファイルの保存先のフォルダを指定します。デフォルトは\"ピクチャ/DermAnnotation/\"です。");
	UISettingCheckBox ui_leftSideControllerEnable = UISettingCheckBox(U"操作パネルの配置", U"ペン選択や各種操作ボタンなどを含む操作パネルを左側に配置します。");
	UISettingCheckBox ui_autoSaveEnable = UISettingCheckBox(U"自動保存", U"自動保存が有効な場合、塗る・消す・ペンを追加するなどの操作が行われた際に自動で画像が保存されます。");
	UISettingCheckBox ui_clippingEnable = UISettingCheckBox(U"高解像度画像編集時にトリミングを行う", U"トリミングすることで編集箇所を限定できる他、アプリケーションのパフォーマンスが向上します。");
	UISettingCheckBox ui_confirmClippngEnable = UISettingCheckBox(U"トリミング前に確認ダイアログを表示する", U"トリミングが可能な場合に事前に確認を行います。");
	UISettingCheckBox ui_resetPencilRadiusAuto = UISettingCheckBox(U"自動でペンの太さをリセットする", U"画像変更時に、自動でペンの太さを初期値にリセットします。");

public:
    using Page::Page;

    void onLoaded() override;

    void onBeforeAppeared() override;

    void onAfterDisappeared() override;
};

