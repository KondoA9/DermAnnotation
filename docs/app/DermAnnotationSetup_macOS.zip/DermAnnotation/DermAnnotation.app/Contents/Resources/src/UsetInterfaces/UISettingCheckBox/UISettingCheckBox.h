#pragma once

#include <GUIKit.h>

class UISettingCheckBox final : public gui::UIView {
private:
	gui::UIText ui_summary = gui::UIText(gui::UnifiedFontStyle::SmallBold);
	gui::UICheckBox ui_checkBox = gui::UICheckBox();
	gui::UIText ui_description = gui::UIText(gui::UnifiedFontStyle::SmallLight, gui::TextDirection::LeftTop);

public:
	UISettingCheckBox(const String& summary, const String& description, bool checked = false) :
		UIView()
	{
		ui_summary.setText(summary);
		ui_description.setText(description);
		ui_checkBox.setChecked(checked);
	}

	bool isChecked() const {
		return ui_checkBox.isChecked();
	}

	void setChecked(bool checked) {
		ui_checkBox.setChecked(checked);
	}

protected:
	void initialize() override;
};
