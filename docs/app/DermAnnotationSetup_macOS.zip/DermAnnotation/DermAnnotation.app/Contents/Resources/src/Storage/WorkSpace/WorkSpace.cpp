#include "WorkSpace.h"

bool WorkSpace::imageChangeable(int index) const {
	if (index > static_cast<int>(m_imageFiles.size() - 1)) {
		index = 0;
	}
	else if (index < 0) {
		index = static_cast<int>(m_imageFiles.size() - 1);
	}

	return m_imageIndex != index;
}

void WorkSpace::open(const FilePath& directory) {
	const FilePath path = directory + U".dermano/workspace-settings.json";
	if (!FileSystem::Exists(path)) {
		FileSystem::CreateDirectories(FileSystem::ParentPath(path));
	}

	m_directory = directory;
	m_settingFilePath = path;

	JSONReader reader(path);

	if (reader) {
		m_setting.outputDirectory = reader[U"output_dir"].getString();
		m_setting.lastOpenedImagePath = reader[U"last_opened_image"].getString();
	}
	else {
		save();
	}

	m_imageFiles = FileManager::GetImagesInFolder(directory);
	m_imageIndex = 0;

	for (size_t i = 0; i < m_imageFiles.size(); i++) {
		if (m_imageFiles[i] == m_setting.lastOpenedImagePath) {
			m_imageIndex = i;
			break;
		}
	}

	setImage(static_cast<int>(m_imageIndex));
}

bool WorkSpace::setImage(int index) {
	const size_t previousIndex = m_imageIndex;

	m_imageIndex = static_cast<size_t>(index);

	if (index > static_cast<int>(m_imageFiles.size() - 1)) {
		index = 0;
	}
	else if (index < 0) {
		index = static_cast<int>(m_imageFiles.size() - 1);
	}

	m_imageIndex = static_cast<size_t>(index);

	setLastOpenedImage();

	return m_imageIndex != previousIndex;
}

void WorkSpace::setOutputDirectory(const FilePath& outputDirectory) {
	m_setting.outputDirectory = outputDirectory[outputDirectory.size() - 1] == '/' ? outputDirectory : outputDirectory + U"/";
	save();
}

void WorkSpace::setLastOpenedImage() {
	m_setting.lastOpenedImagePath = m_imageFiles[m_imageIndex];
	save();
}

void WorkSpace::save() {
	JSONWriter writer;

	writer.startObject();
	{
		writer.key(U"output_dir").writeString(m_setting.outputDirectory);
		writer.key(U"last_opened_image").writeString(m_setting.lastOpenedImagePath);
	}
	writer.endObject();

	writer.save(m_settingFilePath);
}
