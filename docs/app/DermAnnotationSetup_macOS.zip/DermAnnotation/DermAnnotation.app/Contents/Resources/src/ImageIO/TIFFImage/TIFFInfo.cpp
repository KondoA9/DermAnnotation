#include "TIFFInfo.h"


TIFFInfo::TIFFInfo(TIFF* tiff) {
    //TAGS
    TIFFGetField(tiff, TIFFTAG_IMAGEWIDTH, &width);
    TIFFGetField(tiff, TIFFTAG_IMAGELENGTH, &height);
    TIFFGetField(tiff, TIFFTAG_SAMPLESPERPIXEL, &samplePerPixel);
    TIFFGetField(tiff, TIFFTAG_BITSPERSAMPLE, &bitPerSample);
    TIFFGetField(tiff, TIFFTAG_PHOTOMETRIC, &photoMetric);
    TIFFGetField(tiff, TIFFTAG_PLANARCONFIG, &planarConfig);
    TIFFGetField(tiff, TIFFTAG_COMPRESSION, &compression);
    TIFFGetField(tiff, TIFFTAG_ROWSPERSTRIP, &rowsPerStrip);

    directories = TIFFNumberOfDirectories(tiff);
    strips = TIFFNumberOfStrips(tiff);
    tiles = TIFFNumberOfTiles(tiff);

    scanlineSize = TIFFScanlineSize(tiff);
    stripSize = TIFFStripSize(tiff);

    //ArrayType
    if (TIFFIsTiled(tiff)) {
        arrayType = TIFFArrayType::Tiled;
    }
    else {
        uint8* line = static_cast<uint8*>(_TIFFmalloc(TIFFScanlineSize(tiff)));
        if (TIFFReadScanline(tiff, line, 0, 0) == 1)
            arrayType = TIFFArrayType::Scanline;
        else {
            tdata_t buf = _TIFFmalloc(stripSize);
            if (TIFFReadRawStrip(tiff, 0, buf, static_cast<tsize_t>(-1)) != -1)
                arrayType = TIFFArrayType::Strip;
        }
    }
}
