#include "UISettingInputField.h"

void UISettingInputField::initialize() {
	addEventListener<gui::MouseEvent::LeftDown>([this] {
		ui_inputField.focus();
		});
	addEventListener<gui::MouseEvent::Hovered>([this] {
		backgroundColor.highlight(gui::DynamicColor::BackgroundHovered);
		});
	addEventListener<gui::MouseEvent::UnHovered>([this] {
		backgroundColor.lowlight(gui::DynamicColor::Background);
		});
	addEventListener<gui::MouseEvent::Hovering>([] {
		Cursor::RequestStyle(CursorStyle::Hand);
		});

	ui_summary.penetrateMouseEvent = true;
	ui_summary.setConstraint(gui::LayerDirection::Top, *this, gui::LayerDirection::Top, 10_px);
	ui_summary.setConstraint(gui::LayerDirection::Height, 20_px);
	ui_summary.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left, 10_px);
	ui_summary.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);

	ui_description.penetrateMouseEvent = true;
	ui_description.setConstraint(gui::LayerDirection::Top, ui_summary, gui::LayerDirection::Bottom);
	ui_description.setConstraint(gui::LayerDirection::Height, 20_px);
	ui_description.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left, 15_px);
	ui_description.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);

	ui_inputField.penetrateMouseEvent = true;
	ui_inputField.setConstraint(gui::LayerDirection::Top, ui_description, gui::LayerDirection::Bottom);
	ui_inputField.setConstraint(gui::LayerDirection::Bottom, *this, gui::LayerDirection::Bottom);
	ui_inputField.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left, 15_px);
	ui_inputField.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right, -15_px);

	appendComponent(ui_summary);
	appendComponent(ui_description);
	appendComponent(ui_inputField);
}
