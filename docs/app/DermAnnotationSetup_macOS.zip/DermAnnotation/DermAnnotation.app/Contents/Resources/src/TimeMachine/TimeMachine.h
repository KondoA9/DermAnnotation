#pragma once

#include <vector>

template<class T>
class TimeMachine {
private:
	const size_t m_limit;
	std::vector<T> m_elements;
	size_t m_index = 0;
	size_t m_size = 0;

public:
	TimeMachine(size_t limit):
		m_limit(limit + 1),
		m_elements(std::vector<T>(limit))
	{}

	T& currentElement() {
		return m_elements[m_index - 1];
	}

	T& element(size_t index) {
		return m_elements[index];
	}

	size_t index() const {
		return m_index;
	}

	bool isLimit() const {
		return m_index == (m_limit - 1);
	}

	bool hasElement() const {
		return m_size > 0;
	}

	void release() {
		m_elements = std::vector<T>(m_limit);
		m_index = 0;
		m_size = 0;
	}

	void update(const T& element) {
		// Current index is at end of elements
		if (m_index == m_limit - 1) {
			for (size_t i = 1; i < m_limit; i++) {
				m_elements[i - 1] = m_elements[i];
			}
			m_elements[m_limit - 1] = element;
		}
		else {
			m_elements[m_index] = element;
			m_index++;
			m_size = m_index;
		}
	}

	void update(size_t index, const T& element) {
		m_elements[index] = element;
	}

	bool redo() {
		if (m_index < m_size + 1) {
			m_index++;
			return true;
		}
		return false;
	}

	bool undo() {
		if (m_index > 1) {
			m_index--;
			return true;
		}
		return false;
	}
};
