#include "FileManager.h"
#include "../ImageIO/ImageIO.h"
#include "../Storage/UserConfiguration/UserConfiguration.h"

namespace FileManager {
	Array<FilePath> GetImagesInFolder(const FilePath& path) {
		auto contents = FileSystem::DirectoryContents(path, false);
		contents.remove_if([](const FilePath& p) {
			return !ImageIO::isAvailableImageType(p);
			});
		return contents;
	}

	FilePath OutputRootFolder() {
		if (FileSystem::Exists(UserConfiguration::Config.outputImagesRootFolder)) {
			return UserConfiguration::Config.outputImagesRootFolder;
		}
		else {
			if (FileSystem::CreateDirectories(UserConfiguration::Config.outputImagesRootFolder)) {
				return UserConfiguration::Config.outputImagesRootFolder;
			}
			else {
				// Could not save to the path, save to default path
				const FilePath path = FileSystem::SpecialFolderPath(SpecialFolder::Pictures) + U"DermAnnotation";
				UserConfiguration::Config.outputImagesRootFolder = path;
				return path;;
			}
		}
	}

	FilePath AnnotatedImageFolder(const FilePath& openedImagePath) {
		const FilePath parentFolderName = FileSystem::BaseName(FileSystem::ParentPath(openedImagePath));
		return OutputRootFolder() + U"/Annotated/" + parentFolderName + U"/";
	}

	FilePath StackedImageFolder(const FilePath& openedImagePath) {
		const FilePath parentFolderName = FileSystem::BaseName(FileSystem::ParentPath(openedImagePath));
		return OutputRootFolder() + U"/Stacked/" + parentFolderName + U"/";
	}

	FilePath AnnotatedImagePath(const FilePath& openedImagePath) {
		return AnnotatedImageFolder(openedImagePath) + FileSystem::BaseName(openedImagePath) + U".tiff";
	}

	FilePath StackedImagePath(const FilePath& openedImagePath) {
		return StackedImageFolder(openedImagePath) + FileSystem::BaseName(openedImagePath) + U".png";
	}

	FilePath ApplicationDataPath() {
		return FileSystem::SpecialFolderPath(SpecialFolder::LocalAppData) + U"DermAnnotation/";
	}
}
