#pragma once

#include <Siv3D.hpp>

namespace FileManager {
	Array<FilePath> GetImagesInFolder(const FilePath& path);

	FilePath AnnotatedImagePath(const FilePath& openedImagePath);

	FilePath StackedImagePath(const FilePath& openedImagePath);

	FilePath ApplicationDataPath();
}
