#pragma once

#include "UIPencilEditorPencil/UIPencilEditorPencil.h"

#include <GUIKit.h>

class UIPencilEditorPencilsView final : public gui::UIVStackView {
public:
	using UIVStackView::UIVStackView;

	Pencil pencil(size_t index) {
		return static_cast<UIPencilEditorPencil*>(components()[index])->pencil();
	}

	void setPencilName(size_t index, const String& name) {
		static_cast<UIPencilEditorPencil*>(components()[index])->setPencilName(name);
	}

	void setPencilColor(size_t index, const Color& color) {
		static_cast<UIPencilEditorPencil*>(components()[index])->setPencilColor(color);
	}

	UIPencilEditorPencil* const appendPencil(const Pencil& pencil);

protected:
	void initialize() override {
		UIVStackView::initialize();
		setRowHeight(45_px);
	}
};

