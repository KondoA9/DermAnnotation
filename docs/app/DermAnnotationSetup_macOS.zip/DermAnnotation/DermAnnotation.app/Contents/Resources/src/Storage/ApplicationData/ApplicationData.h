#pragma once

#include <Siv3D.hpp>

struct ApplicationData {
	struct Data {
		Size windowSize = Size(1280, 720);
		bool initialLaunch = true;

		template <class Archive>
		void SIV3D_SERIALIZE(Archive& archive)
		{
			archive(windowSize, initialLaunch);
		}
	};

	static Data AppData;

private:
	static const FilePath Path;

public:
	static void Load();

	static void Save();

	static void Remove();
};
