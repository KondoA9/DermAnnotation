#include "UIPencilEditorPencil.h"

void UIPencilEditorPencil::setPencilColor(const Color& color) {
	m_pencil.color = color;
	ui_circle.backgroundColor = color;
}

void UIPencilEditorPencil::setPencilName(const String& name) {
	m_pencil.name = name;
	ui_name.setText(name);
}

void UIPencilEditorPencil::initialize() {
	ui_circle.penetrateMouseEvent = true;
	ui_circle.setConstraint(gui::LayerDirection::CenterY, *this, gui::LayerDirection::CenterY);
	ui_circle.setConstraint(gui::LayerDirection::Height, 20_px);
	ui_circle.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left, 15_px);
	ui_circle.setConstraint(gui::LayerDirection::Width, 20_px);

	ui_name.penetrateMouseEvent = true;
	ui_name.setConstraint(gui::LayerDirection::CenterY, *this, gui::LayerDirection::CenterY);
	ui_name.setConstraint(gui::LayerDirection::Height, *this, gui::LayerDirection::Height);
	ui_name.setConstraint(gui::LayerDirection::Left, ui_circle, gui::LayerDirection::Right, 15_px);
	ui_name.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);

	appendComponent(ui_circle);
	appendComponent(ui_name);
}
