#pragma once

#include "Pencil.h"

#include <Siv3D.hpp>

class ImageLayer {
	Pencil m_pencil;
	Image m_image;

public:
	explicit ImageLayer(const Image& image) :
		m_image(image)
	{}

	ImageLayer(const Image & image, const Pencil & pencil) :
		m_image(image),
		m_pencil(pencil)
	{}

	ImageLayer(const Image& image, const String& pencilName, const Color& pencilColor) :
    ImageLayer(image, Pencil{pencilName, pencilColor})
	{}

	ImageLayer(size_t width, size_t height) :
		ImageLayer(Image(width, height, Color(255, 255, 255, 0)))
	{}

	ImageLayer(size_t width, size_t height, const Pencil& pencil) :
		ImageLayer(Image(width, height), pencil)
	{}

	ImageLayer(size_t width, size_t height, const String & pencilName, const Color & pencilColor) :
        ImageLayer(Image(width, height), Pencil{pencilName, pencilColor})
	{}

	const Pencil& pencil() const {
		return m_pencil;
	}

	const Image& image() const {
		return m_image;
	}

	void setImage(const Image& image) {
		m_image = image;
	}

	void setPencil(const String& name, const Color& color) {
		m_pencil.name = name;
		m_pencil.color = color;
	}

	std::string getTiffPageName() const {
		return (m_pencil.name + U"/" + Format(m_pencil.color)).narrow();
	}

	void releaseImage() {
		m_image.release();
	}

	void readPencliInfo(const char* tiffPageName) {
		if (tiffPageName == nullptr) {
			return;
		}

		if (const auto arr = Unicode::Widen(std::string(tiffPageName)).split('/'); arr.size() > 0) {
			try {
				m_pencil.color = Parse<Color>(arr[1]);
				m_pencil.name = arr[0];
			}
			catch (...) {}
		}
	}
};
