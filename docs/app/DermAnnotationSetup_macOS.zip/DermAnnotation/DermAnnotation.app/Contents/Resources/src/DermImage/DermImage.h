#pragma once

#include "ImageLayer.h"

#include <Siv3D.hpp>

class DermImage {
	struct ImageSize {
		uint32 width = 0, height = 0;

		bool isEmpty() const {
			return width == 0 || height == 0;
		}
	};

private:
	ImageSize m_size;
	Image m_originalImage;
	Array<ImageLayer> m_layers;

public:
	DermImage()
	{}

	explicit DermImage(const Image& originalImage) :
		m_originalImage(originalImage),
        m_size(ImageSize{static_cast<uint32>(originalImage.width()), static_cast<uint32>(originalImage.height())})
	{}

	DermImage(uint32 width, uint32 height) :
        m_size(ImageSize{width, height})
	{}

	const ImageLayer& layer(size_t index) const {
		return m_layers[index];
	}

	const Image& originalImage() const {
		return m_originalImage;
	}

	Size size() const {
		return Size(m_size.width, m_size.height);
	}

	size_t layerCount() const {
		return m_layers.size();
	}

	bool hasPencils() const {
		return m_layers.size() > 0;
	}

	bool isValidImage() const {
		return !m_size.isEmpty();
	}

	Array<Pencil> pencils() const {
		auto pencils = Array<Pencil>();
		for (const auto& layer : m_layers) {
			pencils.push_back(layer.pencil());
		}
		return pencils;
	}

	void release() {
		m_originalImage.release();
		m_layers.release();
	}

	void releaseLayers() {
		for (auto& layer : m_layers) {
			layer.releaseImage();
		}
	}

	void setOriginalImage(const Image& image) {
		m_originalImage = image;
        m_size = ImageSize{static_cast<uint32>(image.width()), static_cast<uint32>(image.height())};
	}

	void setLayer(size_t index, const Image& image) {
		m_layers[index].setImage(image);
	}

	void setPencil(size_t index, const String& name, const Color& color) {
		m_layers[index].setPencil(name, color);
	}

	void readPencilInfo(size_t index, const char* tiffPageName) {
		m_layers[index].readPencliInfo(tiffPageName);
	}

	void appendLayer(const String& name, const Color& color) {
		m_layers.push_back(ImageLayer(m_size.width, m_size.height, name, color));
	}

	void appendLayer(const Pencil& pencil) {
		m_layers.push_back(ImageLayer(m_size.width, m_size.height, pencil));
	}

	void appendEmptyLayer() {
		m_layers.push_back(ImageLayer(m_size.width, m_size.height));
	}

	void removeLayer(size_t index) {
		m_layers.remove_at(index);
	}
};
