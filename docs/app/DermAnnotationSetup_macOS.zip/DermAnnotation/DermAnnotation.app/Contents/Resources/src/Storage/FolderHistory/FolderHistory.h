#pragma once

#include <Siv3D.hpp>

struct FolderHistory {
	struct FolderData {
		FilePath path;
		DateTime datetime;

		template <class Archive>
		void SIV3D_SERIALIZE(Archive& archive)
		{
			archive(path, datetime);
		}
	};

	static Array<FolderData> History;

private:
	static const FilePath Path;

public:
	static void Load();

	static void Add(const FilePath& path);

	static void Save();

	static void Remove();
};
