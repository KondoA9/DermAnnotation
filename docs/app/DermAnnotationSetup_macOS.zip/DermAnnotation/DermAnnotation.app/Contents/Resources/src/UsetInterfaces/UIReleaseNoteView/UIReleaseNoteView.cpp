#include "UIReleaseNoteView.h"
#include "../../Version.h"

gui::UIText createFeatureText(const wchar_t* const str) {
	auto text = gui::UIText(Unicode::FromWString(str), gui::UnifiedFontStyle::Small, gui::TextDirection::Center);
	return text;
}

void UIReleaseNoteView::initialize() {
	setRowHeight(40_px);

	// Empty
	{
		auto dummy = gui::UIText();
		appendTemporaryComponent(dummy);
	}

	// Title
	{
		auto title = gui::UIText(U"リリースノート", gui::UnifiedFontStyle::Large, gui::TextDirection::Center);
		appendTemporaryComponent(title);
	}

	// Empty
	{
		auto dummy = gui::UIText();
		appendTemporaryComponent(dummy);
	}

	// Label
	{
		auto label = gui::UIText(U"重要", gui::TextDirection::Center);
		appendTemporaryComponent(label);
	}

	// Releases
	for (const auto f : Version::ImportantFeatures) {
		appendTemporaryComponent(createFeatureText(f));
	}

	// Empty
	{
		auto dummy = gui::UIText();
		appendTemporaryComponent(dummy);
	}

	// Label
	{
		auto label = gui::UIText(U"その他", gui::TextDirection::Center);
		appendTemporaryComponent(label);
	}

	// Releases
	for (const auto f : Version::Features) {
		appendTemporaryComponent(createFeatureText(f));
	}
}
