#include "UIMenubar.h"

void UIMenubar::appendButton(const String& label, const std::function<void()>& handler) {
	auto button = new gui::UIButton(label, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::BackgroundTertiary, gui::DynamicColor::Text);

	button->setConstraint(gui::LayerDirection::Top, *this, gui::LayerDirection::Top);
	button->setConstraint(gui::LayerDirection::Bottom, *this, gui::LayerDirection::Bottom);
	if (components()) {
		button->setConstraint(gui::LayerDirection::Left, *components()[components().size() - 1], gui::LayerDirection::Right);
	}
	else {
		button->setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left);
	}
	button->setConstraint(gui::LayerDirection::Width, 80_px);
	button->addEventListener<gui::MouseEvent::LeftDown>(handler);

	appendComponent(*button);
}
