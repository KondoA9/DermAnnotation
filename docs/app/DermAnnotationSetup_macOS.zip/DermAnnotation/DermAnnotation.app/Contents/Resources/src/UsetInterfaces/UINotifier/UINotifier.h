#pragma once

#include <GUIKit.h>

class UINotifier final : public gui::UIText {
public:
	enum class MessageType {
		Info,
		Warning,
		Error
	};

private:
	static std::shared_ptr<UINotifier> ui_Notifier;

	const double m_hideTime = 5.0; // seconds
	double m_timer = 0.0;
	bool m_hideProgress = false;
	bool m_hideAutomatically = true;

public:
	static void Show(const String& message, MessageType type, bool hideAutomatically = true);

	static void Hide(bool instant = false);

protected:
	void initialize() override;

	void draw() override;

private:
	UINotifier() :
		UIText(gui::DynamicColor::Clear, gui::DynamicColor::Clear)
	{
		hidden = true;
	}

	static std::tuple<gui::ColorTheme, gui::ColorTheme> MessageColor(MessageType type);

	void hide(double transition = 0.3);
};
