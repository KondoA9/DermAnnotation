#include "VersionChecker.h"
#include "../../Version.h"
#include "../../FileManager/FileManager.h"

namespace VersionChecker {
	bool IsNewVersion() {
		const String currentVersion = Unicode::FromWString(Version::DermAnnotationVersion);
		const String path = FileManager::ApplicationDataPath() + U"Version";

		// Load
		TextReader reader(path);
		const auto version = reader.readLine();
		reader.close();

		// Save
		TextWriter writer(path);
		writer << currentVersion;
		writer.close();

		return !version.has_value() || version.value() != currentVersion;
	}
}
