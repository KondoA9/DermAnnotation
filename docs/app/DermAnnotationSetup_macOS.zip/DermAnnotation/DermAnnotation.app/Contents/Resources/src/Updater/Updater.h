#include <Siv3D.hpp>

namespace Updater {
	enum class Status {
		UnChecked,
		Checked,
		Failed
	};

	bool IsNewVersionAvailable();

	String LatestVersion();

	Status GetStatus();
}
