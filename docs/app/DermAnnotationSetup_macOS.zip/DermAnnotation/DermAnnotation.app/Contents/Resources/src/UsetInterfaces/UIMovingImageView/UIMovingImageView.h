#pragma once

#include <GUIKit.h>

class UIMovingImageView final : public gui::UIView {
	bool m_rectInitialized = false;
	double m_resizedImageScale = 1.0;
	std::function<void(const Point& centerPixel)> m_imageMovedHandler;
	Rect m_frameRect;
	Color m_frameColor;

	gui::UIZStackedImageView ui_imageView = gui::UIZStackedImageView();

public:
	using UIView::UIView;

	void release();

	void setOriginalImage(const Image& image);

	void setRect(const Rect& textureRegion, const Rect& visibleTextureRect, const Point& centerPixel);

	void setImageMovedHandler(const std::function<void(const Point& centerPixel)>& func) {
		m_imageMovedHandler = func;
	}

protected:
	void initialize() override;

	void draw() override;

private:
	void restrictFrameRect();

	Color getOppositeColor(const Image& image);
};
