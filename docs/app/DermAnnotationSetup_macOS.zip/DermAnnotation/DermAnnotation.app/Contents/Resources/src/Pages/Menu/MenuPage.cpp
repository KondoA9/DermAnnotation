#include "MenuPage.h"
#include "../Editor/EditorPage.h"
#include "../../FileManager/FileManager.h"
#include "../../UsetInterfaces/UIFolderHistoryRow/UIFolderHistoryRow.h"
#include "../../Storage/UserConfiguration/UserConfiguration.h"
#include "../../Storage//FolderHistory/FolderHistory.h"
#include "../../UsetInterfaces/UINotifier/UINotifier.h"
#include "../../Storage/VersionChecker/VersionChecker.h"

void MenuPage::onLoaded() {
	ui_toolBox.setConstraint(gui::LayerDirection::Top, view(), gui::LayerDirection::Top);
	ui_toolBox.setConstraint(gui::LayerDirection::Bottom, view(), gui::LayerDirection::Bottom);
	ui_toolBox.setConstraint(gui::LayerDirection::Left, view(), gui::LayerDirection::Left);
	ui_toolBox.setConstraint(gui::LayerDirection::Width, 110_px);

	ui_openDirectoryButton.setConstraint(gui::LayerDirection::Top, ui_toolBox, gui::LayerDirection::Top);
	ui_openDirectoryButton.setConstraint(gui::LayerDirection::Height, 110_px);
	ui_openDirectoryButton.setConstraint(gui::LayerDirection::Left, ui_toolBox, gui::LayerDirection::Left);
	ui_openDirectoryButton.setConstraint(gui::LayerDirection::Width, ui_toolBox, gui::LayerDirection::Width);
	ui_openDirectoryButton.addEventListener<gui::MouseEvent::LeftDown>([this]() {
		if (const auto result = Dialog::SelectFolder(); result) {
#if SIV3D_PLATFORM(MACOS)
			const FilePath path = result.value() + U"/";
#else
			const FilePath path = result.value();
#endif
			selectFolder(path);
		}
		});

	ui_settingButton.setConstraint(gui::LayerDirection::Top, ui_openDirectoryButton, gui::LayerDirection::Bottom);
	ui_settingButton.setConstraint(gui::LayerDirection::Height, ui_openDirectoryButton, gui::LayerDirection::Height);
	ui_settingButton.setConstraint(gui::LayerDirection::Left, ui_openDirectoryButton, gui::LayerDirection::Left);
	ui_settingButton.setConstraint(gui::LayerDirection::Width, ui_openDirectoryButton, gui::LayerDirection::Width);
	ui_settingButton.addEventListener<gui::MouseEvent::LeftDown>([this]() {
		gui::GUIKit::Instance().switchPage(U"setting");
		});

	ui_toggleColorModeButton.setConstraint(gui::LayerDirection::Bottom, view(), gui::LayerDirection::Bottom);
	ui_toggleColorModeButton.setConstraint(gui::LayerDirection::Height, ui_openDirectoryButton, gui::LayerDirection::Height);
	ui_toggleColorModeButton.setConstraint(gui::LayerDirection::Left, ui_openDirectoryButton, gui::LayerDirection::Left);
	ui_toggleColorModeButton.setConstraint(gui::LayerDirection::Width, ui_openDirectoryButton, gui::LayerDirection::Width);
	ui_toggleColorModeButton.addEventListener<gui::MouseEvent::LeftDown>([this]() {
		gui::GUIKit::Instance().toggleColorMode();
		UserConfiguration::Config.colorMode = gui::ColorTheme::CurrentColorMode();
		});

	ui_openHomepageButton.setConstraint(gui::LayerDirection::Bottom, ui_toggleColorModeButton, gui::LayerDirection::Top);
	ui_openHomepageButton.setConstraint(gui::LayerDirection::Height, 40_px);
	ui_openHomepageButton.setConstraint(gui::LayerDirection::Left, ui_toggleColorModeButton, gui::LayerDirection::Left);
	ui_openHomepageButton.setConstraint(gui::LayerDirection::Width, ui_toggleColorModeButton, gui::LayerDirection::Width);
	ui_openHomepageButton.addEventListener<gui::MouseEvent::LeftDown>([]() {
		System::LaunchBrowser(U"https://kondoa9.github.io/DermAnnotation/");
		});

	ui_appTitle.setConstraint(gui::LayerDirection::Top, view(), gui::LayerDirection::Top, 20_px);
	ui_appTitle.setConstraint(gui::LayerDirection::Height, 50_px);
	ui_appTitle.setConstraint(gui::LayerDirection::Left, ui_toolBox, gui::LayerDirection::Right, 30_px);
	ui_appTitle.setConstraint(gui::LayerDirection::Width, 450_px);

	ui_toggleReleaseNoteButton.setConstraint(gui::LayerDirection::Top, ui_appTitle, gui::LayerDirection::Top);
	ui_toggleReleaseNoteButton.setConstraint(gui::LayerDirection::Height, ui_appTitle, gui::LayerDirection::Height);
	ui_toggleReleaseNoteButton.setConstraint(gui::LayerDirection::Right, view(), gui::LayerDirection::Right, -70_px);
	ui_toggleReleaseNoteButton.setConstraint(gui::LayerDirection::Width, 220_px);
	ui_toggleReleaseNoteButton.addEventListener<gui::MouseEvent::LeftDown>([this] {
		ui_releaseNoteView.hidden = !ui_releaseNoteView.hidden;
		ui_toggleReleaseNoteButton.title = ui_releaseNoteView.hidden ? U"リリースノート" : U"閉じる";
		});

	ui_recentlyOpenedDirectoryLabel.setConstraint(gui::LayerDirection::Top, ui_appTitle, gui::LayerDirection::Bottom);
	ui_recentlyOpenedDirectoryLabel.setConstraint(gui::LayerDirection::Height, 80_px);
	ui_recentlyOpenedDirectoryLabel.setConstraint(gui::LayerDirection::Left, ui_appTitle, gui::LayerDirection::Left, 20_px);
	ui_recentlyOpenedDirectoryLabel.setConstraint(gui::LayerDirection::Right, view(), gui::LayerDirection::Right);

	ui_recentlyOpenedDirectoryView.scrollingEnabled = false;
	ui_recentlyOpenedDirectoryView.setMaxStackCount(10);
	ui_recentlyOpenedDirectoryView.setConstraint(gui::LayerDirection::Top, ui_recentlyOpenedDirectoryLabel, gui::LayerDirection::Bottom, 30_px);
	ui_recentlyOpenedDirectoryView.setConstraint(gui::LayerDirection::Bottom, view(), gui::LayerDirection::Bottom, -100_px);
	ui_recentlyOpenedDirectoryView.setConstraint(gui::LayerDirection::Left, ui_recentlyOpenedDirectoryLabel, gui::LayerDirection::Left, 10_px);
	ui_recentlyOpenedDirectoryView.setConstraint(gui::LayerDirection::Right, view(), gui::LayerDirection::Right, -70_px);

	// Paging
	ui_backHistoryPageButton.setConstraint(gui::LayerDirection::Top, ui_recentlyOpenedDirectoryView, gui::LayerDirection::Bottom);
	ui_backHistoryPageButton.setConstraint(gui::LayerDirection::Bottom, view(), gui::LayerDirection::Bottom);
	ui_backHistoryPageButton.setConstraint(gui::LayerDirection::Right, view(), gui::LayerDirection::CenterX, -20_px);
	ui_backHistoryPageButton.setConstraint(gui::LayerDirection::Width, 100_px);
	ui_backHistoryPageButton.addEventListener<gui::MouseEvent::LeftDown>([this] {
		if (m_historyPageIndex != 0) {
			updateHistoryView(m_historyPageIndex - 1);
		}
		});

	ui_nextHistoryPageButton.setConstraint(gui::LayerDirection::Top, ui_recentlyOpenedDirectoryView, gui::LayerDirection::Bottom);
	ui_nextHistoryPageButton.setConstraint(gui::LayerDirection::Bottom, view(), gui::LayerDirection::Bottom);
	ui_nextHistoryPageButton.setConstraint(gui::LayerDirection::Left, view(), gui::LayerDirection::CenterX, 20_px);
	ui_nextHistoryPageButton.setConstraint(gui::LayerDirection::Width, 100_px);
	ui_nextHistoryPageButton.addEventListener<gui::MouseEvent::LeftDown>([this] {
		updateHistoryView(m_historyPageIndex + 1);
		});

	// Release note
	ui_releaseNoteView.setConstraint(gui::LayerDirection::Top, ui_recentlyOpenedDirectoryLabel, gui::LayerDirection::Top);
	ui_releaseNoteView.setConstraint(gui::LayerDirection::Bottom, view(), gui::LayerDirection::Bottom);
	ui_releaseNoteView.setConstraint(gui::LayerDirection::Left, ui_appTitle, gui::LayerDirection::Left);
	ui_releaseNoteView.setConstraint(gui::LayerDirection::Right, view(), gui::LayerDirection::Right);

	// version
	const bool newVersion = false;// VersionChecker::IsNewVersion();
	ui_toggleReleaseNoteButton.title = newVersion ? U"閉じる" : U"リリースノート";
	ui_releaseNoteView.hidden = newVersion ? false : true;

	view().appendComponent(ui_toolBox);
	view().appendComponent(ui_openDirectoryButton);
	view().appendComponent(ui_settingButton);
	view().appendComponent(ui_toggleColorModeButton);
	view().appendComponent(ui_openHomepageButton);

	view().appendComponent(ui_appTitle);
	view().appendComponent(ui_toggleReleaseNoteButton);

	view().appendComponent(ui_recentlyOpenedDirectoryLabel);
	view().appendComponent(ui_recentlyOpenedDirectoryView);

	view().appendComponent(ui_backHistoryPageButton);
	view().appendComponent(ui_nextHistoryPageButton);

	view().appendComponent(ui_releaseNoteView);
}

void MenuPage::onBeforeAppeared() {
	updateHistoryView(0);

	if (startup) {
		startup = false;
	}
	else {
		UINotifier::Hide(true);
	}
}

void MenuPage::selectFolder(const FilePath& path) {
	if (auto& editor = gui::GUIKit::Instance().getPage<EditorPage>(U"editor"); editor.setRootFolder(path)) {
		gui::GUIKit::Instance().switchPage(U"editor");
	}
	else {
		UINotifier::Show(U"読み込み可能な画像が存在しないため、フォルダを開けません。", UINotifier::MessageType::Warning);
	}
}

void MenuPage::updateHistoryView(size_t page) {
	ui_recentlyOpenedDirectoryView.release();

	const size_t maxPageIndex = static_cast<size_t>(FolderHistory::History.size() / 10);
	m_historyPageIndex = Clamp(page, size_t(0), maxPageIndex);

	const size_t start = m_historyPageIndex * 10;
	const size_t end = start + 10 < FolderHistory::History.size() ? start + 10 : FolderHistory::History.size();

	for (size_t i = start; i < end; i++) {
		const auto& history = FolderHistory::History[i];
		auto row = UIFolderHistoryRow(history);
		row.addEventListener<gui::MouseEvent::LeftDown>([this, history]() {
			selectFolder(history.path);
			});
		ui_recentlyOpenedDirectoryView.appendTemporaryComponent(row);
	}

	ui_backHistoryPageButton.hidden = m_historyPageIndex == 0;
	ui_nextHistoryPageButton.hidden = m_historyPageIndex == maxPageIndex;

}
