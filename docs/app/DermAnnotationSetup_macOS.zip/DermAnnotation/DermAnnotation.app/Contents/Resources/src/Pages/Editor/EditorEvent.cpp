#include "EditorPage.h"
#include "Painter/Painter.h"
#include "../../UsetInterfaces/UINotifier/UINotifier.h"

void EditorPage::setEvents() {
	/* Setup Menubar*/
	ui_menubar.appendButton(U"Menu", [this] {
		gui::GUIKit::Instance().switchPage(U"menu");
		});

	ui_menubar.appendButton(U"File", [this] {
		if (const auto result = Dialog::SelectFolder(); result) {
			if (setRootFolder(result.value())) {
				saveImageSyncIfNeeded();
				initializeEditor();
				setupEditor();
			}
			else {
				UINotifier::Show(U"読み込み可能な画像が存在しないため、フォルダを開けません。", UINotifier::MessageType::Warning);
			}
		}
		});

	ui_menubar.appendButton(U"Pencil", [this] {
		ui_pencilEditorView.hidden = !ui_pencilEditorView.hidden;
		ui_pencilEditorView.setup(m_dermImage.pencils());
		});

	/* Setup Pencil editor view */
	ui_pencilEditorView.setEditCompletedHandler([this](const Array<EditedPencil>& pencils) {
		if (fixPencils(pencils)) {
			autoSave();
		}
		});

	ui_pencilEditorView.setPencilSettingCalledHandler([this](const Array<Pencil>& pencils) {
		ui_controllerView.releasePencilBoxView();

		for (int i = static_cast<int>(m_dermImage.layerCount()) - 1; i >= 0; i--) {
			removePencil(static_cast<size_t>(i));
		}
		for (const auto& pencil : pencils) {
			appendPencil(pencil);
		}

		m_layerIndex = 0;
		ui_controllerView.selectPencil(m_layerIndex);
		ui_cursor.frameColor = m_dermImage.layer(m_layerIndex).pencil().color;
		});

	/* Setup Editor view */
	ui_editorView.addEventListener<gui::MouseEvent::Hovering>([this](const gui::MouseEvent::Hovering& e) {
		ui_cursor.setConstraint(gui::LayerDirection::CenterY, e.pos.y);
		ui_cursor.setConstraint(gui::LayerDirection::CenterX, e.pos.x);
		if (ui_buttonsView.isAreaSelectorEnabled()) {
			Cursor::RequestStyle(CursorStyle::Cross);
		}
		else {
			Cursor::RequestStyle(CursorStyle::Hidden);
		}
		});

	ui_editorView.addEventListener<UIEditorView::PaintStart>([this] {
		gui::GUIKit::Instance().stopTimeout(m_savingImageProcessID);

		m_layerTimeMachine.prepare(m_layerIndex, m_layers);

		Painter::StartPaint();

		if (ui_buttonsView.isAreaSelectorEnabled()) {
			m_drawPoints.release();
			m_drawPolygons.release();
		}
		else {
			paintByPencil();
		}
		});

	ui_editorView.addEventListener<UIEditorView::PaintEnd>([this] {
		if (ui_buttonsView.isAreaSelectorEnabled()) {
			Painter::Region::Paint(m_layers[m_layerIndex], ui_buttonsView.isEraserEnabled() ? Color(255, 255, 255, 0) : m_dermImage.layer(m_layerIndex).pencil().color);
		}

		// Update time machine
		const Rect rect = Painter::DrawnRect();
		m_layerTimeMachine.updateLayer(m_layerIndex, m_layers, rect);

		if (ui_buttonsView.isAreaSelectorEnabled()) {
			ui_editorView.updateTexture(m_layerIndex + 1, m_layers[m_layerIndex]);
		}

		autoSave();
		});

	ui_editorView.addEventListener<UIEditorView::Painting>([this] {
		if (ui_buttonsView.isAreaSelectorEnabled()) {
			paintRegion();
		}
		else {
			paintByPencil();
		}
		});

	ui_editorView.addEventListener<gui::MouseEvent::RightDragging>([this] {
		setMovingImageView();
		});

	ui_editorView.addEventListener<gui::MouseEvent::Wheel>([this] {
		ui_controllerView.setEditorScale(ui_editorView.scaleRate());
		setMovingImageView();
		});

	/* Setup Controll buttons view */
	ui_buttonsView.setAreaSelectorToggledHandler([this] {
		ui_cursor.exist = !ui_buttonsView.isAreaSelectorEnabled();
		});

	ui_buttonsView.setUndoHandler([this] {
		if (const auto index = m_layerTimeMachine.undo(m_layers); index.has_value()) {
			ui_editorView.updateTexture(index.value() + 1, m_layers[index.value()]);
			autoSave();
		}
		});

	ui_buttonsView.setRedoHandler([this] {
		if (const auto index = m_layerTimeMachine.redo(m_layers); index.has_value()) {
			ui_editorView.updateTexture(index.value() + 1, m_layers[index.value()]);
			autoSave();
		}
		});

	ui_buttonsView.setTrashHandler([this] {
		m_layerTimeMachine.prepare(m_layerIndex, m_layers);

		m_layers[m_layerIndex] = Image(m_layers[m_layerIndex].size(), Color(255, 255, 255, 0));

		const Rect rect = Rect(0, 0, m_layers[m_layerIndex].size());
		m_layerTimeMachine.updateLayer(m_layerIndex, m_layers, rect);
		ui_editorView.updateTexture(m_layerIndex + 1, m_layers[m_layerIndex]);

		autoSave();
		});

	ui_buttonsView.setFilesViewToggledHandler([this] {
		ui_controllerView.controllable = !ui_controllerView.controllable;
		ui_controllerView.hidden = !ui_controllerView.hidden;
		ui_filesView.controllable = !ui_filesView.controllable;
		ui_filesView.hidden = !ui_filesView.hidden;
		});

	ui_buttonsView.setEraserChangedHandler([this]() {
		ui_cursor.fillInner = !ui_cursor.fillInner;
		});

	/* Setup Controller view */
	ui_controllerView.setFileBackHandler([this] {
		moveImage(static_cast<int>(m_workSpace.currentIndex() - 1));
		});

	ui_controllerView.setFileNextHandler([this] {
		moveImage(static_cast<int>(m_workSpace.currentIndex() + 1));
		});

	ui_controllerView.setFolderBackHandler([this] {
		moveFolder(static_cast<int>(m_currentFolderIndex - 1));
		});

	ui_controllerView.setFolderNextHandler([this] {
		moveFolder(static_cast<int>(m_currentFolderIndex + 1));
		});

	ui_controllerView.setPencilChangedHandler([this](size_t index) {
		m_layerIndex = index;
		ui_cursor.frameColor = m_dermImage.layer(m_layerIndex).pencil().color;
		});

	ui_controllerView.setPencilAlphaRateChangedHandler([this](size_t index, double value) {
		ui_editorView.setAlphaRate(index + 1, value);
		});

	ui_controllerView.setAllPencilAlphaRateChangedHandler([this](double value) {
		for (size_t i = 0; i < m_dermImage.layerCount(); i++) {
			ui_editorView.setAlphaRate(i + 1, value);
		}
		ui_controllerView.setPencilAlphaRate(value);
		});

	ui_controllerView.setPencilRadiusChangedHandler([this](double value) {
		setPencilRadius(value);
		});

	ui_controllerView.setEditorScalingChangedHandler([this](double value) {
		ui_editorView.setScale(value);
		setMovingImageView();
		});

	ui_controllerView.setImageMovedHandler([this](const Point& centerPixel) {
		ui_editorView.setViewingCenterPixel(centerPixel);
		});

	// Output directory
	ui_outputDirectory.addEventListener<gui::UIInputField::KeyEnterDown>([this] {
		ui_outputDirectory.unFocus();
		m_workSpace.setOutputDirectory(ui_outputDirectory.text());
		ui_outputDirectory.setText(m_workSpace.setting().outputDirectory);
		});
}
