#include "PencilSetting.h"
#include "../../FileManager/FileManager.h"

const FilePath Path = FileManager::ApplicationDataPath() + U"PencilSetting.json";

namespace PencilSetting {
	namespace Internal {
		PencilBox ReadPencilBox(const JSONValue& root) {
			const auto name = root[U"name"].getString();
			const auto pencilsView = root[U"pencils"].arrayView();

			auto pencils = Array<Pencil>();
			for (const auto& pencil : pencilsView) {
				pencils.push_back({
					.name = pencil[U"name"].getString(),
					.color = pencil[U"color"].get<Color>()
					});
			}

			return {
				.name = name,
				.pencils = pencils
			};
		}

		void WritePencilBox(JSONWriter& writer, const PencilBox& pencilBox) {
			writer.startObject();
			{
				writer.key(U"name").writeString(pencilBox.name);
				writer.key(U"pencils").startArray();
				for (const auto& pencil : pencilBox.pencils) {
					writer.startObject();
					{
						writer.key(U"name").writeString(pencil.name);
						writer.key(U"color").write(pencil.color);
					}
					writer.endObject();
				}
				writer.endArray();
			}
			writer.endObject();
		}

		String CreateFileName(const PencilBox& pencilBox) {
			return U"DermAnnotationPencil-{}.json"_fmt(pencilBox.name);
		}
	}


	Array<PencilBox> GetSettings() {
		auto settings = Array<PencilBox>();

		JSONReader reader(Path);
		const auto settingsView = reader[U"settings"].arrayView();

		for (const auto& setting : settingsView) {
			settings.push_back(Internal::ReadPencilBox(setting));
		}

		return settings;
	}


	bool Export(const PencilBox& pencilBox, const FilePath& directory) {
		const FilePath path = directory + Internal::CreateFileName(pencilBox);

		JSONWriter writer;
		Internal::WritePencilBox(writer, pencilBox);
		return writer.save(path);
	}

	bool ExportAllSettings(const FilePath& directory) {
		const Array<PencilBox> settings = GetSettings();

		JSONWriter writer;

		writer.startObject();
		{
			writer.key(U"settings").startArray();
			for (const auto& setting : settings) {
				Internal::WritePencilBox(writer, setting);
			}
			writer.endArray();
		}
		writer.endObject();

		return writer.save(directory + U"DermAnnotationPencils.json");
	}

	bool SaveSetting(const PencilBox& pencilBox) {
		JSONWriter writer;

		Array<PencilBox> settings = GetSettings();
		if (pencilBox.name.isEmpty() || pencilBox.pencils.isEmpty()
			|| settings.includes_if([pencilBox](const PencilBox& box) { return box.name == pencilBox.name; })) {
			return false;
		}

		settings.push_back(pencilBox);

		writer.startObject();
		{
			writer.key(U"settings").startArray();
			for (const auto& setting : settings) {
				Internal::WritePencilBox(writer, setting);
			}
			writer.endArray();
		}
		writer.endObject();

		return writer.save(Path);
	}

	bool SaveSetting(const String& name, const Array<Pencil>& pencils) {
		return SaveSetting({ .name = name, .pencils = pencils });
	}

	bool ImportFromFile(const FilePath& path) {
		JSONReader reader(path);

		if (!reader) {
			return false;
		}

		if (reader.hasMember(U"settings")) {
			bool ok = false;
			for (const auto& setting : reader[U"settings"].arrayView()) {
				const auto pencilBox = Internal::ReadPencilBox(setting);
				ok |= SaveSetting(pencilBox);
			}
			return ok;
		}
		else {
			const auto pencilBox = Internal::ReadPencilBox(reader);
			return SaveSetting(pencilBox);
		}
	}
}
