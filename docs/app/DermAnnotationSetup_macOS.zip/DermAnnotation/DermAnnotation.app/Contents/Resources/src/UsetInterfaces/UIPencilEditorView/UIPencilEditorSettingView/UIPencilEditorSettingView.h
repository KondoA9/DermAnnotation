#pragma once

#include "../UIPencilEditorPencilsView/UIPencilEditorPencilsView.h"
#include "../../../Storage/PencilSetting/PencilSetting.h"

#include <GUIKit.h>

class UIPencilEditorSettingView final : public gui::UIView {
	Optional<size_t> m_index = none;
	Array<PencilBox> m_pencilBoxes;
	std::function<void(const Array<Pencil>&)> m_pencilSettingCalledHandler;

	gui::UIVStackView ui_settingsView = gui::UIVStackView();
	UIPencilEditorPencilsView ui_pencilsView = UIPencilEditorPencilsView();
	gui::UIButton ui_callSettingButton = gui::UIButton(U"設定を呼び出す", gui::DynamicColor::Background, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text);
	gui::UIButton ui_exportSettingButton = gui::UIButton(U"設定をエクスポート", gui::DynamicColor::Background, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text);
	gui::UIButton ui_exportAllSettingButton = gui::UIButton(U"全ての設定をエクスポート", gui::DynamicColor::Background, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text);
	gui::UIButton ui_importSettingButton = gui::UIButton(U"設定をインポート", gui::DynamicColor::Background, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text);

public:
	void setup();

	void setPencilSettingCalledHandler(const std::function<void(const Array<Pencil>&)>& handler) {
		m_pencilSettingCalledHandler = handler;
	}

protected:
	void initialize() override;

private:
	void setupPencilsView(const Array<Pencil>& pencils);
};
