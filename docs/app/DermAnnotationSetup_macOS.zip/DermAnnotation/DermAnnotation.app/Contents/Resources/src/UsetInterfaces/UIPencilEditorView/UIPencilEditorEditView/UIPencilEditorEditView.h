#pragma once

#include "../../../DermImage/Pencil.h"
#include "../UIPencilEditorPencilsView/UIPencilEditorPencilsView.h"

#include <GUIKit.h>

enum class PencilEditedStatus {
	Same,
	Edited,
	Deleted,
	Added
};

struct EditedPencil {
	PencilEditedStatus status = PencilEditedStatus::Same;
	Pencil pencil;
};

class UIPencilEditorEditView final : public gui::UIView {
private:
	enum class RGBColor {
		Red,
		Green,
		Blue
	};

	size_t m_index = 0;
	Array<EditedPencil> m_pencils;
	String m_pencilName;
	std::function<void(const Array<EditedPencil>&)> m_pencilEditCompletedHandler;

	UIPencilEditorPencilsView ui_pencilsView = UIPencilEditorPencilsView();

	gui::UIRect ui_colorRect = gui::UIRect(gui::DynamicColor::Background);
	gui::UIVStackView ui_editView = gui::UIVStackView();
	gui::UIVStackView ui_editButtonsView = gui::UIVStackView();

	gui::UIButton ui_addPencilButton = gui::UIButton(U"ペンを追加", gui::DynamicColor::Background, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text);
	gui::UIButton ui_saveButton = gui::UIButton(U"保存", gui::DynamicColor::Background, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text);

public:
	void setup(const Array<Pencil>& pencils);

	void setEditCompletedHandler(const std::function<void(const Array<EditedPencil>&)>& handler) {
		m_pencilEditCompletedHandler = handler;
	}

protected:
	void initialize() override;

private:
	String getEditingPencilName() const {
		return m_pencilName;
	}

	Color getEditingPencilColor() const {
		return ui_colorRect.backgroundColor;
	}

	void setupPencilsView();

	void setupPencilEditView(const Pencil& pencil, bool addPencil);

	void setupEditButtonsView(bool addPencil);

	gui::UIInputField createPencilColorInputField(const Pencil& pencil, RGBColor rgb);

	void applyPencilColorInputField(const Pencil& pencil, RGBColor rgb);

	uint32 pencilColor(const Pencil& pencil, RGBColor rgb) const;

	void setPencilColor(uint32 color, RGBColor rgb);

	void setPencilNameByEditingName();

	void setPencilColorByEditingColor();

	bool appendPencil();

	bool deletePencil();

	void clearEditingView();
};
