#pragma once

#include <GUIKit.h>

struct UserConfiguration {
	struct Configurations {
		gui::ColorMode colorMode = gui::ColorMode::Dark;
		FilePath outputImagesRootFolder = FileSystem::SpecialFolderPath(SpecialFolder::Pictures) + U"DermAnnotation/";
		bool leftSideController = false;
		bool autoSave = true;
		bool clippingIfLoadBigImage = true, showMessageBoxWhenClipping = true;
		bool resetPencilRadiusAutomatically = false;

		template <class Archive>
		void SIV3D_SERIALIZE(Archive& archive)
		{
			archive(
				colorMode,
				outputImagesRootFolder,
				leftSideController,
				autoSave,
				clippingIfLoadBigImage,
				showMessageBoxWhenClipping,
				resetPencilRadiusAutomatically
			);
		}
	};

	static Configurations Config;

private:
	static const FilePath Path;

public:
	static void Load();

	static void Save();

	static void Remove();
};
