#pragma once

#include <GUIKit.h>

class UIReleaseNoteView final : public gui::UIVStackView {


public:
	using UIVStackView::UIVStackView;

protected:
	void initialize() override;
};
