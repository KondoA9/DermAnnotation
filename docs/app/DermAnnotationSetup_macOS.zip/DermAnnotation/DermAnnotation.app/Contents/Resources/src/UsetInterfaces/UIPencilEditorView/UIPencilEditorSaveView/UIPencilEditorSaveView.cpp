#include "UIPencilEditorSaveView.h"
#include "../../../Storage/PencilSetting/PencilSetting.h"
#include "../../UINotifier/UINotifier.h"

void UIPencilEditorSaveView::initialize() {
	auto& inputFieldView = appendTemporaryComponent(gui::UIView());
	inputFieldView.setConstraint(gui::LayerDirection::Top, *this, gui::LayerDirection::Top, 15_px);
	inputFieldView.setConstraint(gui::LayerDirection::Height, 40_px);
	inputFieldView.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left, 15_px);
	inputFieldView.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);

	auto& inputFieldLabel = inputFieldView.appendTemporaryComponent(gui::UIText(U"名称"));

	inputFieldLabel.setConstraint(gui::LayerDirection::Top, inputFieldView, gui::LayerDirection::Top);
	inputFieldLabel.setConstraint(gui::LayerDirection::Bottom, inputFieldView, gui::LayerDirection::Bottom);
	inputFieldLabel.setConstraint(gui::LayerDirection::Left, inputFieldView, gui::LayerDirection::Left);
	inputFieldLabel.setConstraint(gui::LayerDirection::Width, 80_px);

	auto& inputField = inputFieldView.appendTemporaryComponent(gui::UIInputField());
	inputField.setConstraint(gui::LayerDirection::Top, inputFieldView, gui::LayerDirection::Top);
	inputField.setConstraint(gui::LayerDirection::Bottom, inputFieldView, gui::LayerDirection::Bottom);
	inputField.setConstraint(gui::LayerDirection::Left, inputFieldLabel, gui::LayerDirection::Right);
	inputField.setConstraint(gui::LayerDirection::Right, inputFieldView, gui::LayerDirection::Right, -15_px);

	ui_pencilsView.setConstraint(gui::LayerDirection::Top, inputFieldView, gui::LayerDirection::Bottom);
	ui_pencilsView.setConstraint(gui::LayerDirection::Bottom, ui_saveSettingButton, gui::LayerDirection::Bottom);
	ui_pencilsView.setConstraint(gui::LayerDirection::Left, inputFieldView, gui::LayerDirection::Left);
	ui_pencilsView.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);

	ui_saveSettingButton.drawFrame = true;
	ui_saveSettingButton.setConstraint(gui::LayerDirection::Height, 40_px);
	ui_saveSettingButton.setConstraint(gui::LayerDirection::Bottom, *this, gui::LayerDirection::Bottom);
	ui_saveSettingButton.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left);
	ui_saveSettingButton.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);
	ui_saveSettingButton.addEventListener<gui::MouseEvent::LeftDown>([this, inputField] {
		if (inputField.text().isEmpty()) {
			UINotifier::Show(U"設定の名称を入力してください。", UINotifier::MessageType::Error);
		}
		else if (PencilSetting::SaveSetting(inputField.text(), m_pencils)) {
			UINotifier::Show(U"設定を保存しました。", UINotifier::MessageType::Info);
		}
		else {
			UINotifier::Show(U"保存に失敗しました。", UINotifier::MessageType::Error);
		}
		});

	appendComponent(ui_pencilsView);
	appendComponent(ui_saveSettingButton);
}

void UIPencilEditorSaveView::setup(const Array<Pencil>& pencils) {
	m_pencils = pencils;

	ui_pencilsView.release();

	for (const auto& pencil : pencils) {
		ui_pencilsView.appendPencil(pencil);
	}
}
