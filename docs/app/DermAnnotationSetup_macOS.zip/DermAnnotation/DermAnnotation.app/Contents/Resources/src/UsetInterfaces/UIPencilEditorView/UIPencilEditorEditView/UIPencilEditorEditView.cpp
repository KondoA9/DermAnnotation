#include "UIPencilEditorEditView.h"
#include "../../UINotifier/UINotifier.h"

void UIPencilEditorEditView::initialize() {
	ui_pencilsView.setConstraint(gui::LayerDirection::Top, *this, gui::LayerDirection::Top, 15_px);
	ui_pencilsView.setConstraint(gui::LayerDirection::Height, *this, gui::LayerDirection::Height, 0.0, 0.4);
	ui_pencilsView.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left);
	ui_pencilsView.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);

	ui_colorRect.setCornerRadius(5);
	ui_colorRect.setConstraint(gui::LayerDirection::Top, ui_pencilsView, gui::LayerDirection::Bottom, 5_px);
	ui_colorRect.setConstraint(gui::LayerDirection::Bottom, ui_addPencilButton, gui::LayerDirection::Top, -15_px);
	ui_colorRect.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left, 15_px);
	ui_colorRect.setConstraint(gui::LayerDirection::Width, 100_px);

	ui_editView.scrollingEnabled = false;
	ui_editView.setMaxStackCount(4);
	ui_editView.setConstraint(gui::LayerDirection::Top, ui_colorRect, gui::LayerDirection::Top);
	ui_editView.setConstraint(gui::LayerDirection::Bottom, ui_editButtonsView, gui::LayerDirection::Bottom);
	ui_editView.setConstraint(gui::LayerDirection::Left, ui_colorRect, gui::LayerDirection::Right);
	ui_editView.setConstraint(gui::LayerDirection::Right, ui_editButtonsView, gui::LayerDirection::Left);

	ui_editButtonsView.hidden = true;
	ui_editButtonsView.setRowHeight(40_px);
	ui_editButtonsView.setLeadingDirection(gui::LeadingDirection::Bottom);
	ui_editButtonsView.setConstraint(gui::LayerDirection::Top, ui_colorRect, gui::LayerDirection::Top);
	ui_editButtonsView.setConstraint(gui::LayerDirection::Bottom, ui_colorRect, gui::LayerDirection::Bottom);
	ui_editButtonsView.setConstraint(gui::LayerDirection::Width, 120_px);
	ui_editButtonsView.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right, -15_px);

	ui_addPencilButton.drawFrame = true;
	ui_addPencilButton.setConstraint(gui::LayerDirection::Bottom, ui_saveButton, gui::LayerDirection::Top);
	ui_addPencilButton.setConstraint(gui::LayerDirection::Height, 40_px);
	ui_addPencilButton.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left);
	ui_addPencilButton.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);
	ui_addPencilButton.addEventListener <gui::MouseEvent::LeftDown>([this] {
		setupPencilEditView(Pencil(), true);
		});

	ui_saveButton.drawFrame = true;
	ui_saveButton.setConstraint(gui::LayerDirection::Bottom, *this, gui::LayerDirection::Bottom);
	ui_saveButton.setConstraint(gui::LayerDirection::Height, 40_px);
	ui_saveButton.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left);
	ui_saveButton.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);
	ui_saveButton.addEventListener<gui::MouseEvent::LeftDown>([this] {
		if (m_pencils.includes_if([](const EditedPencil& pencil) {return pencil.status != PencilEditedStatus::Deleted; })) {
			m_pencilEditCompletedHandler(m_pencils);
		}
		else {
			UINotifier::Show(U"１つ以上のペンを登録してください。", UINotifier::MessageType::Error);
		}
		});

	appendComponent(ui_pencilsView);
	appendComponent(ui_addPencilButton);
	appendComponent(ui_colorRect);
	appendComponent(ui_editView);
	appendComponent(ui_editButtonsView);
	appendComponent(ui_saveButton);
}

void UIPencilEditorEditView::setup(const Array<Pencil>& pencils) {
	m_pencils.release();
	for (const auto& pencil : pencils) {
		m_pencils.push_back({ .pencil = pencil });
	}

	setupPencilsView();
}

void UIPencilEditorEditView::setupPencilsView() {
	ui_pencilsView.release();

	for (size_t index = 0; const auto & pencil : m_pencils) {
		if (pencil.status == PencilEditedStatus::Deleted) {
			continue;
		}

		auto* const view = ui_pencilsView.appendPencil(pencil.pencil);

		view->addEventListener<gui::MouseEvent::Hovered>([](const gui::MouseEvent::Hovered& e) {
			e.component->backgroundColor.highlight(gui::DynamicColor::BackgroundSecondary);
			});
		view->addEventListener<gui::MouseEvent::UnHovered>([](const gui::MouseEvent::UnHovered& e) {
			e.component->backgroundColor.lowlight(gui::DynamicColor::Background);
			});
		view->addEventListener<gui::MouseEvent::LeftDown>([this, index] {
			const auto pencil = ui_pencilsView.pencil(index);
			setupPencilEditView(pencil, false);
			m_index = index;
			});

		index += 1;
	}
}

void UIPencilEditorEditView::setupPencilEditView(const Pencil& pencil, bool addPencil) {
	ui_editView.release();

	// Initialize
	m_pencilName = pencil.name;
	ui_colorRect.backgroundColor = pencil.color;

	// InputField of pencil name
	auto& view = ui_editView.appendTemporaryComponent(gui::UIView());

	auto& label = view.appendTemporaryComponent(gui::UIText(U"名称", gui::TextDirection::Center));
	label.setConstraint(gui::LayerDirection::Top, view, gui::LayerDirection::Top);
	label.setConstraint(gui::LayerDirection::Bottom, view, gui::LayerDirection::Bottom);
	label.setConstraint(gui::LayerDirection::Left, view, gui::LayerDirection::Left);
	label.setConstraint(gui::LayerDirection::Width, 95_px);

	auto& inputfield = view.appendTemporaryComponent(gui::UIInputField(pencil.name));
	inputfield.setConstraint(gui::LayerDirection::Top, view, gui::LayerDirection::Top);
	inputfield.setConstraint(gui::LayerDirection::Bottom, view, gui::LayerDirection::Bottom);
	inputfield.setConstraint(gui::LayerDirection::Left, label, gui::LayerDirection::Right);
	inputfield.setConstraint(gui::LayerDirection::Right, view, gui::LayerDirection::Right);
	inputfield.addEventListener<gui::UIInputField::KeyDown>([this](const gui::UIInputField::KeyDown& e) {
		m_pencilName = static_cast<gui::UIInputField*>(e.component)->text();
		});
	
	// InputField of pencil color
	applyPencilColorInputField(pencil, RGBColor::Red);
	applyPencilColorInputField(pencil, RGBColor::Green);
	applyPencilColorInputField(pencil, RGBColor::Blue);

	// Buttons
	setupEditButtonsView(addPencil);
}

void UIPencilEditorEditView::setupEditButtonsView(bool addPencil) {
	ui_editButtonsView.release();

	if (addPencil) {
		auto button = gui::UIButton(U"追加", gui::DynamicColor::Background, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text);
		button.drawFrame = true;
		button.addEventListener<gui::MouseEvent::LeftDown>([this] {
			if (appendPencil()) {
				clearEditingView();
				setupPencilsView();
			}
			else {
				UINotifier::Show(U"ペンを追加できませんでした。", UINotifier::MessageType::Error);
			}
			});
		ui_editButtonsView.appendTemporaryComponent(button);
	}
	else {
		auto deleteButton = gui::UIButton(U"削除", gui::DynamicColor::Background, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text);
		deleteButton.drawFrame = true;
		deleteButton.addEventListener<gui::MouseEvent::LeftDown>([this] {
			if (deletePencil()) {
				clearEditingView();
				setupPencilsView();
			}
			});
		ui_editButtonsView.appendTemporaryComponent(deleteButton);

		auto changeButton = gui::UIButton(U"変更", gui::DynamicColor::Background, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text);
		changeButton.drawFrame = true;
		changeButton.addEventListener<gui::MouseEvent::LeftDown>([this] {
			if (!getEditingPencilName().isEmpty()) {
				setPencilColorByEditingColor();
				setPencilNameByEditingName();
				m_pencils[m_index].status = PencilEditedStatus::Edited;
			}
			else {
				UINotifier::Show(U"ペンを変更できませんでした。", UINotifier::MessageType::Error);
			}
			});
		ui_editButtonsView.appendTemporaryComponent(changeButton);
	}

	ui_editButtonsView.hidden = false;
}

void UIPencilEditorEditView::clearEditingView() {
	m_index = 0;
	ui_editButtonsView.hidden = true;
	ui_colorRect.backgroundColor = gui::DynamicColor::Background;
	ui_editView.release();
}

uint32 UIPencilEditorEditView::pencilColor(const Pencil& pencil, RGBColor rgb) const {
	switch (rgb)
	{
	case UIPencilEditorEditView::RGBColor::Red:
		return pencil.color.r;

	case UIPencilEditorEditView::RGBColor::Green:
		return pencil.color.g;

	case UIPencilEditorEditView::RGBColor::Blue:
		return pencil.color.b;

	default:
		return 0;
	}
}

void UIPencilEditorEditView::setPencilColor(uint32 color, RGBColor rgb) {
	const Color c = ui_colorRect.backgroundColor;

	switch (rgb)
	{
	case UIPencilEditorEditView::RGBColor::Red:
		ui_colorRect.backgroundColor.setColor(Color(color, c.g, c.b));
		break;

	case UIPencilEditorEditView::RGBColor::Green:
		ui_colorRect.backgroundColor.setColor(Color(c.r, color, c.b));
		break;

	case UIPencilEditorEditView::RGBColor::Blue:
		ui_colorRect.backgroundColor.setColor(Color(c.r, c.g, color));
		break;

	default:
		break;
	}
}

gui::UIInputField UIPencilEditorEditView::createPencilColorInputField(const Pencil& pencil, RGBColor rgb) {
	auto inputfield = gui::UIInputField(ToString(pencilColor(pencil, rgb)));

	inputfield.addEventListener<gui::UIInputField::KeyDown>([this, rgb](const gui::UIInputField::KeyDown& e) {
		auto inputfield = static_cast<gui::UIInputField*>(e.component);
		try {
			uint32 color = ParseInt<uint32>(inputfield->text(), Arg::radix = 10);
			if (color > 255) {
				color = static_cast<uint32>(color * 0.1);
				inputfield->setText(ToString(color));
			}
			setPencilColor(color, rgb);
		}
		catch (...) {
			inputfield->setText(U"");
			setPencilColor(0, rgb);
		}
		});

	return inputfield;
}

void UIPencilEditorEditView::applyPencilColorInputField(const Pencil& pencil, RGBColor rgb) {
	auto& view = ui_editView.appendTemporaryComponent(gui::UIView());

	auto text = gui::UIText(U"{}"_fmt(rgb == RGBColor::Red ? U"Red" : (rgb == RGBColor::Green ? U"Green" : U"Blue")), gui::TextDirection::Center);
	text.setConstraint(gui::LayerDirection::Top, view, gui::LayerDirection::Top);
	text.setConstraint(gui::LayerDirection::Bottom, view, gui::LayerDirection::Bottom);
	text.setConstraint(gui::LayerDirection::Left, view, gui::LayerDirection::Left);
	text.setConstraint(gui::LayerDirection::Width, 95_px);
	auto& textEntity = view.appendTemporaryComponent(text);

	auto input = createPencilColorInputField(pencil, rgb);
	input.setConstraint(gui::LayerDirection::Top, view, gui::LayerDirection::Top);
	input.setConstraint(gui::LayerDirection::Bottom, view, gui::LayerDirection::Bottom);
	input.setConstraint(gui::LayerDirection::Left, textEntity, gui::LayerDirection::Right);
	input.setConstraint(gui::LayerDirection::Right, view, gui::LayerDirection::Right);
	view.appendTemporaryComponent(input);
}

void UIPencilEditorEditView::setPencilNameByEditingName() {
	const String name = getEditingPencilName();
	ui_pencilsView.setPencilName(m_index, name);
	m_pencils[m_index].pencil.name = name;
}

void UIPencilEditorEditView::setPencilColorByEditingColor() {
	const Color color = getEditingPencilColor();
	ui_pencilsView.setPencilColor(m_index, color);
	m_pencils[m_index].pencil.color = color;
}

bool UIPencilEditorEditView::appendPencil() {
	if (const auto name = getEditingPencilName(); !name.isEmpty()) {
		m_pencils.push_back({
			.status = PencilEditedStatus::Added,
			.pencil = {
				.name = getEditingPencilName(),
				.color = getEditingPencilColor()
				}
			});
		return true;
	}
	else {
		return false;
	}
}

bool UIPencilEditorEditView::deletePencil() {
	const auto result = System::ShowMessageBox(U"ペンを削除します。", MessageBoxStyle::Warning, MessageBoxButtons::OKCancel);
	if (result == MessageBoxSelection::OK) {
		m_pencils[m_index].status = PencilEditedStatus::Deleted;
		return true;
	}
	return false;
}
