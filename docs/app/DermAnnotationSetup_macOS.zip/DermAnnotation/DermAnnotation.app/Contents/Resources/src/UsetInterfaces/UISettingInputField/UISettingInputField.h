#pragma once

#include <GUIKit.h>

class UISettingInputField final :public gui::UIView {
private:
	gui::UIText ui_summary = gui::UIText(gui::UnifiedFontStyle::SmallBold);
	gui::UIText ui_description = gui::UIText(gui::UnifiedFontStyle::SmallLight, gui::TextDirection::LeftTop);
	gui::UIInputField ui_inputField = gui::UIInputField(gui::UnifiedFontStyle::Small);

public:
	UISettingInputField(const String& summary, const String& description, const String& inputText = U"") :
		UIView()
	{
		ui_summary.setText(summary);
		ui_description.setText(description);
		ui_inputField.setText(inputText);
	}

	String text() const {
		return ui_inputField.text();
	}

	void setText(const String& text) {
		ui_inputField.setText(text);
	}

protected:
	void initialize() override;
};
