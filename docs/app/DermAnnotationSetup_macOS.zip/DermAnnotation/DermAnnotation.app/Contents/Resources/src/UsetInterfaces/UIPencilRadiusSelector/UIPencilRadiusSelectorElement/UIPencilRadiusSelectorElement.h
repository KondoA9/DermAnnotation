#pragma once

#include <GUIKit.h>

class UIPencilRadiusSelectorElement final : public gui::UIView {
private:
	const int m_radius;

	gui::UICircle ui_circle = gui::UICircle();

public:
	UIPencilRadiusSelectorElement(int radius) :
		UIView(gui::DynamicColor::Clear),
		m_radius(radius)
	{}

	void setColor(const Color& color) {
		ui_circle.backgroundColor.highlight(color);
	}

protected:
	void initialize() override;
};
