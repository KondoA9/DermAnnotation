#include "UIPencilRadiusSelector.h"

void UIPencilRadiusSelector::setColor(const Color& color) {
	ui_pencilSmall.setColor(color);
	ui_pencilMedium.setColor(color);
	ui_pencilLarge.setColor(color);
}

void UIPencilRadiusSelector::setPencilRadiusSelectedHandler(const std::function<void(int)>& handler) {
	ui_pencilSmall.addEventListener<gui::MouseEvent::LeftDown>([this, handler] {
		handler(static_cast<int>(PencilRadius::Small));
		});
	ui_pencilMedium.addEventListener<gui::MouseEvent::LeftDown>([this, handler] {
		handler(static_cast<int>(PencilRadius::Medium));
		});
	ui_pencilLarge.addEventListener<gui::MouseEvent::LeftDown>([this, handler] {
		handler(static_cast<int>(PencilRadius::Large));
		});
}

void UIPencilRadiusSelector::initialize() {
	ui_pencilSmall.setConstraint(gui::LayerDirection::Top, *this, gui::LayerDirection::Top);
	ui_pencilSmall.setConstraint(gui::LayerDirection::Bottom, *this, gui::LayerDirection::Bottom);
	ui_pencilSmall.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left);
	ui_pencilSmall.setConstraint(gui::LayerDirection::Width, *this, gui::LayerDirection::Width, 0.0, 1.0 / 3.0);

	ui_pencilMedium.setConstraint(gui::LayerDirection::Top, *this, gui::LayerDirection::Top);
	ui_pencilMedium.setConstraint(gui::LayerDirection::Bottom, *this, gui::LayerDirection::Bottom);
	ui_pencilMedium.setConstraint(gui::LayerDirection::Left, ui_pencilSmall, gui::LayerDirection::Right);
	ui_pencilMedium.setConstraint(gui::LayerDirection::Right, ui_pencilLarge, gui::LayerDirection::Left);

	ui_pencilLarge.setConstraint(gui::LayerDirection::Top, *this, gui::LayerDirection::Top);
	ui_pencilLarge.setConstraint(gui::LayerDirection::Bottom, *this, gui::LayerDirection::Bottom);
	ui_pencilLarge.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);
	ui_pencilLarge.setConstraint(gui::LayerDirection::Width, *this, gui::LayerDirection::Width, 0.0, 1.0 / 3.0);

	appendComponent(ui_pencilSmall);
	appendComponent(ui_pencilMedium);
	appendComponent(ui_pencilLarge);
}
