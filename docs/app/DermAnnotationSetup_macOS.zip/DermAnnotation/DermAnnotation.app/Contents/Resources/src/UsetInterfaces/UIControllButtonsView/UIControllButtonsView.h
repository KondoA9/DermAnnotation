#pragma once

#include <GUIKit.h>

class UIControllButtonsTopView final : public gui::UIVStackView {
	gui::UIToggleButton ui_toggleFilesViewButton = gui::UIToggleButton(Texture(Icon(0xf07c, 30_px)), gui::DynamicColor::Clear, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text);

public:
	bool isFilesViewEnabled() const {
		return ui_toggleFilesViewButton.isEnabled();
	}

	void setFilesViewToggledHandler(const std::function<void()>& handler) {
		ui_toggleFilesViewButton.addEventListener<gui::MouseEvent::LeftDown>(handler);
	}

	void setFilesViewEnabled(bool enabled) {
		ui_toggleFilesViewButton.setEnabled(enabled);
	}

protected:
	void initialize() override;
};

class UIControllButtonsBottomView final : public gui::UIVStackView {
	std::function<void()> m_eraserChangedHandler;

	gui::UIButton ui_redoButton = gui::UIButton(Texture(Icon(0xf01e, 30_px)), gui::DynamicColor::Clear, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text);
	gui::UIButton ui_undoButton = gui::UIButton(Texture(Icon(0xf0e2, 30_px)), gui::DynamicColor::Clear, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text);
	gui::UIToggleButton ui_toggleAreaSelectorButton = gui::UIToggleButton(Texture(Icon(0xf5ee, 30_px)), gui::DynamicColor::Clear, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text);
	gui::UIToggleButton ui_toggleEraserButton = gui::UIToggleButton(Texture(Icon(0xf12d, 30_px)), gui::DynamicColor::Clear, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text);
	gui::UIButton ui_trashButton = gui::UIButton(Texture(Icon(0xf1f8, 30_px)), gui::DynamicColor::Clear, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text);

public:
	bool isAreaSelectorEnabled() const {
		return ui_toggleAreaSelectorButton.isEnabled();
	}

	bool isEraserEnabled() const {
		return ui_toggleEraserButton.isEnabled();
	}

	void setEraserEnabled(bool enabled);

	void setEraserChangedHandler(const std::function<void()>& handler);

	void setAreaSelectorToggledHandler(const std::function<void()>& handler) {
		ui_toggleAreaSelectorButton.addEventListener<gui::MouseEvent::LeftDown>(handler);
	}

	void setRedoHandler(const std::function<void()>& handler) {
		ui_redoButton.addEventListener<gui::MouseEvent::LeftDown>(handler);
	}

	void setUndoHandler(const std::function<void()>& handler) {
		ui_undoButton.addEventListener<gui::MouseEvent::LeftDown>(handler);
	}

	void setTrashHandler(const std::function<void()>& handler) {
		ui_trashButton.addEventListener<gui::MouseEvent::LeftDown>(handler);
	}

	void setAreaSelectorEnabled(bool enabled) {
		ui_toggleAreaSelectorButton.setEnabled(enabled);
	}

protected:
	void initialize() override;
};

class UIControllButtonsView final : public gui::UIVStackView {
private:
	UIControllButtonsTopView ui_topView = UIControllButtonsTopView();
	UIControllButtonsBottomView ui_bottomView = UIControllButtonsBottomView();

public:
	bool isAreaSelectorEnabled() const {
		return ui_bottomView.isAreaSelectorEnabled();
	}

	bool isEraserEnabled() const {
		return ui_bottomView.isEraserEnabled();
	}

	bool isFilesViewEnabled() const {
		return ui_topView.isFilesViewEnabled();
	}

	void setEraserEnabled(bool enabled) {
		ui_bottomView.setEraserEnabled(enabled);
	}

	// Set handlers
	void setEraserChangedHandler(const std::function<void()>& handler) {
		ui_bottomView.setEraserChangedHandler(handler);
	}

	void setFilesViewToggledHandler(const std::function<void()>& handler) {
		ui_topView.setFilesViewToggledHandler(handler);
	}

	void setFilesViewEnabled(bool enabled) {
		ui_topView.setFilesViewEnabled(enabled);
	}

	void setAreaSelectorToggledHandler(const std::function<void()>& handler) {
		ui_bottomView.setAreaSelectorToggledHandler(handler);
	}

	void setRedoHandler(const std::function<void()>& handler) {
		ui_bottomView.setRedoHandler(handler);
	}

	void setUndoHandler(const std::function<void()>& handler) {
		ui_bottomView.setUndoHandler(handler);
	}

	void setTrashHandler(const std::function<void()>& handler) {
		ui_bottomView.setTrashHandler(handler);
	}

	void setAreaSelectorEnabled(bool enabled) {
		ui_bottomView.setAreaSelectorEnabled(enabled);
	}

protected:
	void initialize() override;
};
