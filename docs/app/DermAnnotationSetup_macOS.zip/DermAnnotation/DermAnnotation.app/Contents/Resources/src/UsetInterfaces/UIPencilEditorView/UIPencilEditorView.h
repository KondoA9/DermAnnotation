#pragma once

#include "UIPencilEditorEditView/UIPencilEditorEditView.h"
#include "UIPencilEditorSettingView/UIPencilEditorSettingView.h"
#include "UIPencilEditorSaveView/UIPencilEditorSaveView.h"

#include <GUIKit.h>

class UIPencilEditorView final : public gui::UIView {
public:
	enum class ViewType : size_t {
		Edit,
		Setting,
		Save
	};

private:
	Array<Pencil> m_pencils;

	gui::UIText ui_title = gui::UIText(U"ペン", gui::TextDirection::Center, gui::DynamicColor::BackgroundSecondary);
	gui::UIVStackView ui_menu = gui::UIVStackView();
	gui::UIButton ui_closeButton = gui::UIButton(Texture(Icon(0xf00d, 30)), gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::DefaultRed, gui::DynamicColor::Text);

	// views
	UIPencilEditorEditView ui_editView = UIPencilEditorEditView();
	UIPencilEditorSettingView ui_settingView = UIPencilEditorSettingView();
	UIPencilEditorSaveView ui_saveView = UIPencilEditorSaveView();

public:
	void setup(const Array<Pencil>& pencils);

	void setPencilSettingCalledHandler(const std::function<void(const Array<Pencil>&)>& handler) {
		ui_settingView.setPencilSettingCalledHandler(handler);
	}

	void setEditCompletedHandler(const std::function<void(const Array<EditedPencil>&)>& handler) {
		ui_editView.setEditCompletedHandler([this, handler](const Array<EditedPencil>& pencils) {
			m_pencils.release();

			for (const auto& pencil : pencils) {
				if (pencil.status != PencilEditedStatus::Deleted) {
					m_pencils.push_back(pencil.pencil);
				}
			}

			hidden = true;

			handler(pencils);
			});
	}

protected:
	void initialize() override;

private:
	gui::UIToggleButton createMenu(const String& label, ViewType type);

	void setViewType(ViewType type);
};
