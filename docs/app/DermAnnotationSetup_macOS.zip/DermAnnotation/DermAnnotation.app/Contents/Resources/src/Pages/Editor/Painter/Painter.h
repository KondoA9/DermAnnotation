#pragma once

#include <Siv3D.hpp>

namespace Painter {
	void StartPaint();

	void SetCanvas(const Size& size);

	void SetCanvas(int32 width, int32 height);

	Rect DrawnRect();

	namespace Pencil {
		Rect Paint(Image& dst, double radius, const Color& color, const Point& currentPixel, const Point& previousPixel);
	}

	namespace Region {
		void Update(const Point& currentPixel);

		void Paint(Image& image, const Color& color);
	}
}
