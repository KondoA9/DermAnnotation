#include "Proxy.h"

#if SIV3D_PLATFORM(WINDOWS)
#include <Siv3D/Windows.hpp>
#include <winhttp.h>
#endif

namespace Proxy {
	Optional<String> GetDefaultProxy() {
#if SIV3D_PLATFORM(WINDOWS)
		if (WINHTTP_CURRENT_USER_IE_PROXY_CONFIG info; WinHttpGetIEProxyConfigForCurrentUser(&info) && info.lpszProxy != nullptr) {
			return Unicode::FromWString(info.lpszProxy);
		}
#endif
		return none;
	}
}
