#include "UIPencilBoxView.h"

void UIPencilBoxView::appendPencil(const Pencil& pencil) {
	auto uipencil = UIPencil(pencil);

	const size_t i = components().size();
	uipencil.unSelect();

	uipencil.addEventListener<gui::MouseEvent::LeftDown>([this, i](const gui::MouseEvent::LeftDown& e) {
		for (auto component : components()) {
			static_cast<UIPencil*>(component)->unSelect();
		}
		static_cast<UIPencil*>(e.component)->select();
		m_pencilChangedHandler(i);
		});

	uipencil.setAlphaChangedHandler([this, i](double value) {m_pencilAlphaChangedHandler(i, value); });

	appendTemporaryComponent(uipencil);
}

void UIPencilBoxView::setPencil(size_t index, const String& name, const Color& color) {
	static_cast<UIPencil*>(components()[index])->setName(name);
	static_cast<UIPencil*>(components()[index])->setColor(color);
}

void UIPencilBoxView::selectPencil(size_t index) {
	for (auto component : components()) {
		static_cast<UIPencil*>(component)->unSelect();
	}

	static_cast<UIPencil*>(components()[index])->select();
}
