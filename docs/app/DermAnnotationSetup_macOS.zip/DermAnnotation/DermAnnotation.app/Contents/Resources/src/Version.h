#pragma once

#include <Siv3D.hpp>

namespace Version {
	const wchar_t* const DermAnnotationVersion = L"2.0.2";

	const wchar_t* const ImportantFeatures[] = {
		L"開いたフォルダごとに出力先フォルダを設定可能になりました。編集画面下の出力欄で個別の出力フォルダが設定でき、設定から規定の出力フォルダを設定可能です。",
		L"以前開いたフォルダを開いた際、最後に編集していた画像を開くようになりました。",
		L"画像変更時にペンのサイズがリセットされないようになりました。この機能は設定で切替可能です。"
	};

	const wchar_t* const Features[] = {
		L"画像編集中、しばらくするとペンで塗る際の負荷が増大する問題を修正。",
		L"スライダーのハンドルが隠れる場合がある問題を修正。"
		L"新しいバージョンに更新した際、リリースノートが自動で開かれないように修正。",
		L"画像読込中、メニューバーを操作不可に変更。"
	};
}
