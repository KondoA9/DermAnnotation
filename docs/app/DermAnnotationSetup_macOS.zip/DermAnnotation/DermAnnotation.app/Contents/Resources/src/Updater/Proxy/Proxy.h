#include <Siv3D.hpp>

namespace Proxy {
	Optional<String> GetDefaultProxy();
}
