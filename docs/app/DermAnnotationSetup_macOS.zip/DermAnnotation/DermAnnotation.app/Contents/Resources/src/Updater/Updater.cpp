#include "Updater.h"

#include "../Version.h"
#include "../FileManager/FileManager.h"
#include "CommandExecuter/CommandExecuter.h"
#include "Proxy/Proxy.h"

namespace Updater {
	const String url = U"https://raw.githubusercontent.com/KondoA9/DermAnnotation/master/application/VERSION";
	String latestVersion = U"";
	Status status = Status::UnChecked;

	namespace Internal {
		FilePath TempVersionFilePath() {
			return FileManager::ApplicationDataPath() + U"tempversion";
		}

		bool ReadVersion() {
			TextReader reader(TempVersionFilePath());

			if (const auto line = reader.readLine(); line.has_value()) {
                if (const auto version = line.value(); version != U"404: Not Found") {
                    latestVersion = version;
                    reader.close();
                    FileSystem::Remove(TempVersionFilePath());
                    return true;
                }
			}

			return false;
		}
    
    String BaseCommand() {
#if SIV3D_PLATFORM(WINDOWS)
        return  U"cmd /c curl " + url;
#else
        return  U"curl " + url;
#endif
        }
	}

	bool IsNewVersionAvailable() {
        String command = Internal::BaseCommand();
		command += U" -o " + Internal::TempVersionFilePath();

		if (const auto proxy = Proxy::GetDefaultProxy(); proxy.has_value()) {
			command += U" -x " + proxy.value();
		}

		if (CommandExecuter::Execute(command) && Internal::ReadVersion()) {
			status = Status::Checked;
			return latestVersion != Unicode::FromWString(Version::DermAnnotationVersion);
		}
		else {
			status = Status::Failed;
		}

		return false;
	}

	String LatestVersion() {
		const String currentVersion = Unicode::FromWString(Version::DermAnnotationVersion);

		switch (status)
		{
		case Updater::Status::UnChecked:
			return currentVersion;
			break;

		case Updater::Status::Checked:
			return latestVersion;
			break;

		case Updater::Status::Failed:
			return currentVersion;
			break;
		}

		return currentVersion;
	}

	Status GetStatus() {
		return status;
	}
}
