#include "SettingPage.h"
#include "../../Storage/FolderHistory/FolderHistory.h"
#include "../../Storage/UserConfiguration/UserConfiguration.h"
#include "../../UsetInterfaces/UINotifier/UINotifier.h"

void SettingPage::onLoaded() {
	// Setup menubar
	ui_menubar.setup(view());
	ui_menubar.appendButton(U"Menu", [this] {
		gui::GUIKit::Instance().switchPage(U"menu");
		});

	// Setup settings view
	ui_settingStackView.setRowHeight(100_px);
	ui_settingStackView.setConstraint(gui::LayerDirection::Top, ui_menubar, gui::LayerDirection::Bottom, 40_px);
	ui_settingStackView.setConstraint(gui::LayerDirection::Bottom, view(), gui::LayerDirection::Bottom);
	ui_settingStackView.setConstraint(gui::LayerDirection::Left, view(), gui::LayerDirection::Width, 0.0, 0.3);
	ui_settingStackView.setConstraint(gui::LayerDirection::Right, view(), gui::LayerDirection::Right, 0.0, 0.7);

	ui_settingStackView.appendComponent(ui_saveDirection);
	ui_settingStackView.appendComponent(ui_leftSideControllerEnable);
	ui_settingStackView.appendComponent(ui_autoSaveEnable);
	ui_settingStackView.appendComponent(ui_clippingEnable);
	ui_settingStackView.appendComponent(ui_confirmClippngEnable);
	ui_settingStackView.appendComponent(ui_resetPencilRadiusAuto);

	// Append
	view().appendComponent(ui_menubar);
	view().appendComponent(ui_settingStackView);
}

void SettingPage::onBeforeAppeared() {
	// Settings
	ui_saveDirection.setText(UserConfiguration::Config.outputImagesRootFolder);

	ui_leftSideControllerEnable.setChecked(UserConfiguration::Config.leftSideController);
	ui_autoSaveEnable.setChecked(UserConfiguration::Config.autoSave);
	ui_clippingEnable.setChecked(UserConfiguration::Config.clippingIfLoadBigImage);
	ui_confirmClippngEnable.setChecked(UserConfiguration::Config.showMessageBoxWhenClipping);
	ui_resetPencilRadiusAuto.setChecked(UserConfiguration::Config.resetPencilRadiusAutomatically);

	UINotifier::Hide(true);
}

void SettingPage::onAfterDisappeared() {
	{
		const auto text = ui_saveDirection.text();
		UserConfiguration::Config.outputImagesRootFolder = text.ends_with(U"/") ? text : text + U"/";
	}
	UserConfiguration::Config.leftSideController = ui_leftSideControllerEnable.isChecked();
	UserConfiguration::Config.autoSave = ui_autoSaveEnable.isChecked();
	UserConfiguration::Config.clippingIfLoadBigImage = ui_clippingEnable.isChecked();
	UserConfiguration::Config.showMessageBoxWhenClipping = ui_confirmClippngEnable.isChecked();
	UserConfiguration::Config.resetPencilRadiusAutomatically = ui_resetPencilRadiusAuto.isChecked();
}
