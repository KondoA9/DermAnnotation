#pragma once

#include "LayerTimeMachine/LayerTimeMachine.h"
#include "../../DermImage/DermImage.h"
#include "../../TimeMachine/TimeMachine.h"
#include "../../Storage/WorkSpace/WorkSpace.h"
#include "../../UsetInterfaces/UIEditorControllerView/UIEditorControllerView.h"
#include "../../UsetInterfaces/UIControllButtonsView/UIControllButtonsView.h"
#include "../../UsetInterfaces/UIMenubar/UIMenubar.h"
#include "../../UsetInterfaces/UIPencilEditorView/UIPencilEditorView.h"
#include "../../UsetInterfaces/UIEditorView/UIEditorView.h"

#include <GUIKit.h>

class EditorPage : public gui::Page {
	enum class ImageStatus {
		Saved,
		Pending,
		Saving,
		Loading
	};

private:
	// Filesystem
	size_t m_currentFolderIndex = 0;
	Array<FilePath> m_folders;
	FilePath m_folderPath;
	bool m_sameFolderSelected = false;

	// Image
	DermImage m_dermImage;

	// Layer
	size_t m_layerIndex = 0;
	Array<Image> m_layers;

	// Pencil
	const double m_minPencilRadius = 3.0_px, m_maxPencilRadius = 40.0_px;
	double m_pencilRadius = 1.0;
	Array<Pencil> m_previousPencils;

	// WorkSpace
	WorkSpace m_workSpace;

	// Editor
	LayerTimeMachine m_layerTimeMachine;

	// Clipping
	bool m_clipping = false, m_clipped = false;
	Rect m_editingImageRect;

	// IO
	size_t m_savingImageProcessID = 0;
	volatile bool m_imageSaved = true, m_imageEdited = false;

	// Draw frame when area painting
	Array<Vec2> m_drawPoints;
	Array<Polygon> m_drawPolygons;

	// GUI Compoenents
	gui::UICircle ui_cursor = gui::UICircle();

	UIMenubar ui_menubar = UIMenubar();

	UIPencilEditorView ui_pencilEditorView = UIPencilEditorView();

	UIEditorView ui_editorView = UIEditorView();

	gui::UIIcon ui_imageSavedStatusIcon = gui::UIIcon(Icon(0xf058, 20_px), gui::DynamicColor::Text, gui::DynamicColor::Background);
	gui::UIText ui_inputPathLabel = gui::UIText(U"入力", gui::UnifiedFontStyle::Small, gui::TextDirection::Center, gui::DynamicColor::Background);
	gui::UIText ui_inputPath = gui::UIText(gui::UnifiedFontStyle::Small, gui::TextDirection::LeftCenter, gui::DynamicColor::Background);
	gui::UIText ui_outputPathLabel = gui::UIText(U"出力", gui::UnifiedFontStyle::Small, gui::TextDirection::Center, gui::DynamicColor::Background);
	gui::UIInputField ui_outputDirectory = gui::UIInputField(gui::UnifiedFontStyle::Small, gui::TextDirection::LeftCenter);
	gui::UIText ui_outputPath = gui::UIText(gui::UnifiedFontStyle::Small, gui::TextDirection::LeftCenter, gui::DynamicColor::Background);

	UIControllButtonsView ui_buttonsView = UIControllButtonsView();
	UIEditorControllerView ui_controllerView = UIEditorControllerView();
	gui::UIVStackView ui_filesView = gui::UIVStackView();

	Texture m_savedIcon = Texture(Icon(0xf058, 20_px));
	Texture m_unsavedIcon = Texture(Icon(0xf068, 20_px));
	Texture m_savingIcon = Texture(Icon(0xf1ce, 20_px));

public:
	using Page::Page;

	void onLoaded() override;

	void onBeforeAppeared() override;

	void onAfterAppeared() override;

	void onWindowResized() override;

	void onAppTerminated() override;

	bool setRootFolder(const FilePath& path);

	void clipImage(const Rect& rect) {
		m_clipped = true;
		m_editingImageRect = rect;
	}

private:
	void setConstraints();

	void setEvents();

	bool setWorkingFolder(size_t folderIndex);

	void openFolder() {
		m_workSpace.open(m_folderPath);
		setupFilesView();
	}

	void initializeEditor();

	void setupEditor();

	void applyImageToEditor();

	void setPencilRadius(double radius);

	void repaintLayerByColor(size_t index, const Color& color);

	void saveImageSync();

	void saveImageAsync(double timeout, const std::function<void()>& completion = std::function<void()>());

	/// <summary>
	/// Save current image synchronously if need.
	/// </summary>
	/// <returns>True if need to save and image saved</returns>
	bool saveImageSyncIfNeeded();

	/// <summary>
	/// Save current image asynchronously if need.
	/// </summary>
	/// <param name="timeout">Define timeout by milliseconds.</param>
	/// <param name="completion">Completion process runs after the async process eneded.</param>
	/// <returns>
	/// 0: Do not need to save,
	/// 1: Need to save and async process started,
	/// -1: Need to save but cannot save becouse async saving process is running
	/// </returns>
	int saveImageAsyncIfNeeded(double timeout, const std::function<void()>& completion = std::function<void()>());

	void autoSave();

	void moveImage(int imageIndex);

	void moveFolder(int folderIndex);

	void setImageStatusIcon(const ImageStatus& status);

	void appendPencil(const Pencil& pencil);

	void removePencil(size_t index);

	/// <summary>
	/// This function is called when pencils are edited.
	/// Fix current pencils and layers.
	/// </summary>
	/// <param name="pencils">Pencils with edited status received from UIPencilEditedView</param>
	/// <returns>False if no pencil is edited</returns>
	bool fixPencils(const Array<EditedPencil>& pencils);

	void setupFilesView();

	void setSelectedFileInFilesView();

	void paintByPencil();

	void paintRegion();

	void setMovingImageView() {
		ui_controllerView.setMovingImageViewRect(
			ui_editorView.textureRegion(),
			ui_editorView.visibleTextureRect(),
			gui::Imaging::ScenePosToPixel(ui_editorView.rect().center(), ui_editorView.textureRegion(), ui_editorView.scale())
		);
	}
};
