#pragma once

#include <Siv3D.hpp>

namespace VersionChecker {
	bool IsNewVersion();
}
