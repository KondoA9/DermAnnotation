#pragma once
#include "../../../TimeMachine/TimeMachine.h"

#include <Siv3D.hpp>

class LayerTimeMachine {
	struct IndexedLayer {
		size_t index;
		Image layer;
		Rect drawnRect;
	};

	struct TimeTraveler {
		IndexedLayer layer;
		Optional<IndexedLayer> differenceLayer = none;
	};

	TimeMachine<TimeTraveler> m_timeMachine = TimeMachine<TimeTraveler>(10);

	size_t m_tmpIndex = 0;
	Image m_tmpImage = Image();

public:
	Optional<size_t> redo(Array<Image>& layers);

	Optional<size_t> undo(Array<Image>& layers);

	void setImageSize(const Size& size) {
		m_tmpImage = Image(size);
	}

	void release();

	void prepare(size_t index, const Array<Image>& layers);

	void updateLayer(size_t index, const Array<Image>& layers, const Rect& drawnRect);

private:
	IndexedLayer createIndexedLayer(size_t index, const Image& layer, const Rect& drawnRect);
};
