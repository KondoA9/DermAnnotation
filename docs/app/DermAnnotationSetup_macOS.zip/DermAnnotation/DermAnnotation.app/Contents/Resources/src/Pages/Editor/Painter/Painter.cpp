#include "Painter.h"

namespace Painter {
	Size CanvasSize;
	Optional<Rect> CanvasRect = none;
	Array<Vec2> PaintRegionPoints;
	Array<Polygon> PaintRegionPolyongs;

	namespace Internal {
		void UpdateCanvasRect(const Rect& rect) {
			if (CanvasRect.has_value()) {
				if (CanvasRect.value().x > rect.x) {
					CanvasRect.value().w += CanvasRect.value().x - rect.x;
					CanvasRect.value().x = rect.x;
				}
				if (CanvasRect.value().y > rect.y) {
					CanvasRect.value().h += CanvasRect.value().y - rect.y;
					CanvasRect.value().y = rect.y;
				}

				if (CanvasRect.value().x + CanvasRect.value().w < rect.x + rect.w) {
					CanvasRect.value().w = rect.x + rect.w - CanvasRect.value().x;
				}

				if (CanvasRect.value().y + CanvasRect.value().h < rect.y + rect.h) {
					CanvasRect.value().h = rect.y + rect.h - CanvasRect.value().y;
				}
			}
			else {
				CanvasRect = rect;
			}
		}

		void UpdateCanvasRect() {
			int32 top = CanvasSize.y, left = CanvasSize.x, bottom = 0, right = 0;

			for (const auto& p : PaintRegionPoints) {
				if (top > p.y) top = static_cast<int32>(p.y) - 2;
				if (left > p.x) left = static_cast<int32>(p.x) - 2;
				if (bottom < p.y) bottom = static_cast<int32>(p.y) + 2;
				if (right < p.x) right = static_cast<int32>(p.x) + 2;
			}

			CanvasRect = Rect(left, top, right - left, bottom - top);
		}
	}

	void StartPaint() {
		CanvasRect = none;
		PaintRegionPoints.release();
	}

	void SetCanvas(const Size& size) {
		CanvasSize = size;
	}

	void SetCanvas(int32 width, int32 height) {
		SetCanvas(Size(width, height));
	}

	Rect DrawnRect() {
		return CanvasRect.value();
	}

	namespace Pencil {
		Rect Paint(Image& dst, double radius, const Color& color, const Point& currentPixel, const Point& previousPixel) {
			const int32 tickness = static_cast<int32>(radius > 0.0 ? radius : 1.0);
			const Line line = Line(previousPixel, currentPixel);

			line.overwrite(dst, tickness, color, false);

			const auto w = Abs(currentPixel.x - previousPixel.x) + 2 * tickness + 2;
			const auto h = Abs(currentPixel.y - previousPixel.y) + 2 * tickness + 2;
			const auto center = ((currentPixel + previousPixel) * 0.5).asPoint();
			const Rect drawingRect = Rect(Arg::center(center), Size(w, h));

			Internal::UpdateCanvasRect(drawingRect);

			return drawingRect;
		}
	}

	namespace Region {
		void Update(const Point& currentPixel) {
			PaintRegionPoints.push_back(currentPixel);
		}

		void Paint(Image& image, const Color& color) {
			PaintRegionPolyongs = Polygon::Correct(PaintRegionPoints);
			for (auto& p : PaintRegionPolyongs) {
				p.overwrite(image, color, false);
			}

			Internal::UpdateCanvasRect();
		}
	}
}
