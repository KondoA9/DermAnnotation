#pragma once

#include <GUIKit.h>

class UIMenubar final : public gui::UIView {
public:
	UIMenubar() :
		UIView(gui::DynamicColor::BackgroundSecondary)
	{}

	void setup(UIView& parentView) {
		drawFrame = true;
		setConstraint(gui::LayerDirection::Top, parentView, gui::LayerDirection::Top);
		setConstraint(gui::LayerDirection::Height, 30_px);
		setConstraint(gui::LayerDirection::Left, parentView, gui::LayerDirection::Left);
		setConstraint(gui::LayerDirection::Right, parentView, gui::LayerDirection::Right);
	}

	void appendButton(const String& label, const std::function<void()>& handler);
};
