#pragma once

#include "../../FileManager/FileManager.h"
#include "../UserConfiguration/UserConfiguration.h"

#include <Siv3D.hpp>

struct WorkSpace {
	struct Setting {
		FilePath outputDirectory = UserConfiguration::Config.outputImagesRootFolder;
		FilePath lastOpenedImagePath = U"";
	};

private:
	Setting m_setting;

	FilePath m_directory = U"", m_settingFilePath = U"";

	size_t m_imageIndex = 0;
	Array<FilePath> m_imageFiles;

public:
	WorkSpace() = default;

	explicit WorkSpace(const FilePath& directory) {
		open(directory);
	}

	bool imageChangeable(int index) const;

	const Setting& setting() const {
		return m_setting;
	}

	const FilePath& imagePath() const {
		return m_imageFiles[m_imageIndex];
	}

	const FilePath& imagePath(size_t index) const {
		return m_imageFiles[index];
	}

	size_t imagesCount() const {
		return m_imageFiles.size();
	}

	size_t currentIndex() const {
		return m_imageIndex;
	}

	FilePath outputImagePath() const {
		return m_setting.outputDirectory + FileSystem::BaseName(FileSystem::ParentPath(m_imageFiles[m_imageIndex])) + U"/" + FileSystem::BaseName(m_imageFiles[m_imageIndex]) + U".tiff";
	}

	void open(const FilePath& directory);

	// Return false if image is not changed
	bool setImage(int index);

	void setOutputDirectory(const FilePath& outputDirectory);

private:
	void save();

	void setLastOpenedImage();
};
