#include "UISettingCheckBox.h"

void UISettingCheckBox::initialize() {
	addEventListener<gui::MouseEvent::LeftDown>([this] {
		setChecked(!isChecked());
		});
	addEventListener<gui::MouseEvent::Hovered>([this] {
		backgroundColor.highlight(gui::DynamicColor::BackgroundHovered);
		});
	addEventListener<gui::MouseEvent::UnHovered>([this] {
		backgroundColor.lowlight(gui::DynamicColor::Background);
		});
	addEventListener<gui::MouseEvent::Hovering>([] {
		Cursor::RequestStyle(CursorStyle::Hand);
		});

	ui_summary.penetrateMouseEvent = true;
	ui_summary.setConstraint(gui::LayerDirection::Top, *this, gui::LayerDirection::Top, 10_px);
	ui_summary.setConstraint(gui::LayerDirection::Height, 20_px);
	ui_summary.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left, 10_px);
	ui_summary.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);

	ui_checkBox.penetrateMouseEvent = true;
	ui_checkBox.setConstraint(gui::LayerDirection::Top, ui_summary, gui::LayerDirection::Bottom, 15_px);
	ui_checkBox.setConstraint(gui::LayerDirection::Height, 20_px);
	ui_checkBox.setConstraint(gui::LayerDirection::Left, ui_summary, gui::LayerDirection::Left, 5_px);
	ui_checkBox.setConstraint(gui::LayerDirection::Width, 20_px);

	ui_description.penetrateMouseEvent = true;
	ui_description.setConstraint(gui::LayerDirection::Top, ui_summary, gui::LayerDirection::Bottom, 15_px);
	ui_description.setConstraint(gui::LayerDirection::Height, *this, gui::LayerDirection::Height);
	ui_description.setConstraint(gui::LayerDirection::Left, ui_checkBox, gui::LayerDirection::Right, 10_px);
	ui_description.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);

	appendComponent(ui_summary);
	appendComponent(ui_checkBox);
	appendComponent(ui_description);
}
