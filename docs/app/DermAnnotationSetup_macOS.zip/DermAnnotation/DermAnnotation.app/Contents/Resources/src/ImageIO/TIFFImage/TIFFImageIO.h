#pragma once

#include "../../DermImage/DermImage.h"

#include <Siv3D.hpp>

namespace ImageIO::TIFFImage {
	DermImage Load(const String& path);

	bool Save(const String& path, const DermImage& dermImage);
}
