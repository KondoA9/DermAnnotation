#include "ClippingPage.h"
#include "../Editor/EditorPage.h"
#include "../../UsetInterfaces/UINotifier/UINotifier.h"

void ClippingPage::onLoaded() {
	ui_menubar.setup(view());
	ui_menubar.appendButton(U"OK", [this] {
		fixRect(m_clippedRect);

		if (m_clippedRect.area() != 0) {
			auto& editor = gui::GUIKit::Instance().getPage<EditorPage>(U"editor");
			editor.clipImage(m_clippedRect);
			gui::GUIKit::Instance().switchPage(U"editor");
		}
		else {
			UINotifier::Show(U"領域が指定されていません。", UINotifier::MessageType::Error);
		}
		});
	ui_menubar.appendButton(U"Cancel", [this] {
		gui::GUIKit::Instance().switchPage(U"editor");
		});

	ui_imageView.manualScalingEnabled = false;
	ui_imageView.setConstraint(gui::LayerDirection::Top, ui_menubar, gui::LayerDirection::Bottom);
	ui_imageView.setConstraint(gui::LayerDirection::Bottom, view(), gui::LayerDirection::Bottom);
	ui_imageView.setConstraint(gui::LayerDirection::Left, view(), gui::LayerDirection::Left);
	ui_imageView.setConstraint(gui::LayerDirection::Right, view(), gui::LayerDirection::Right);
	ui_imageView.addEventListener<gui::MouseEvent::LeftDraggingStart>([this](const gui::MouseEvent::LeftDraggingStart& e) {
		m_drawingBasePos = e.pos;
		m_clippedRect.setPos(ui_imageView.currentPixel());
		});
	ui_imageView.addEventListener<gui::MouseEvent::LeftDragging>([this](const gui::MouseEvent::LeftDragging& e) {
		m_clippedRect.setSize(ui_imageView.currentPixel() - m_clippedRect.pos);
		if (m_drawingBasePos.x <= e.pos.x) {
			ui_frameRect.setConstraint(gui::LayerDirection::Left, m_drawingBasePos.x);
			ui_frameRect.setConstraint(gui::LayerDirection::Right, e.pos.x);
		}
		else {
			ui_frameRect.setConstraint(gui::LayerDirection::Left, e.pos.x);
			ui_frameRect.setConstraint(gui::LayerDirection::Right, m_drawingBasePos.x);
		}

		if (m_drawingBasePos.y <= e.pos.y) {
			ui_frameRect.setConstraint(gui::LayerDirection::Top, m_drawingBasePos.y);
			ui_frameRect.setConstraint(gui::LayerDirection::Bottom, e.pos.y);
		}
		else {
			ui_frameRect.setConstraint(gui::LayerDirection::Top, e.pos.y);
			ui_frameRect.setConstraint(gui::LayerDirection::Bottom, m_drawingBasePos.y);
		}
		});
	ui_imageView.addEventListener<gui::MouseEvent::Hovering>([this] {
		Cursor::RequestStyle(CursorStyle::Cross);
		});

	ui_frameRect.setConstraint(gui::LayerDirection::Top, 0);
	ui_frameRect.setConstraint(gui::LayerDirection::Left, 0);
	ui_frameRect.setConstraint(gui::LayerDirection::Width, 0);
	ui_frameRect.setConstraint(gui::LayerDirection::Height, 0);

	ui_frameRect.fillInner = false;
	ui_frameRect.drawFrame = true;
	ui_frameRect.frameColor = Palette::Black;
	ui_frameRect.frameThickness = 4.0_px;
	ui_frameRect.penetrateMouseEvent = true;

	view().appendComponent(ui_menubar);
	view().appendComponent(ui_imageView);
	view().appendComponent(ui_frameRect);
}

void ClippingPage::onBeforeAppeared() {
	m_clippedRect = Rect();
	ui_frameRect.setConstraint(gui::LayerDirection::Top, 0);
	ui_frameRect.setConstraint(gui::LayerDirection::Left, 0);
	ui_frameRect.setConstraint(gui::LayerDirection::Width, 0);
	ui_frameRect.setConstraint(gui::LayerDirection::Height, 0);
	UINotifier::Hide(true);
}

void ClippingPage::onWindowResized() {
	ui_frameRect.setConstraint(gui::LayerDirection::Top, 0);
	ui_frameRect.setConstraint(gui::LayerDirection::Left, 0);
	ui_frameRect.setConstraint(gui::LayerDirection::Width, 0);
	ui_frameRect.setConstraint(gui::LayerDirection::Height, 0);
}

void ClippingPage::onAfterDisappeared() {
	ui_imageView.release();
}

void ClippingPage::setImage(const DermImage& image) {
	ui_imageView.appendImage(image.originalImage());
	for (size_t i = 0; i < image.layerCount(); i++) {
		ui_imageView.appendImage(image.layer(i).image(), 0.7);
	}
}

void ClippingPage::fixRect(Rect& rect) {
	if (rect.w < 0) {
		rect.setPos(rect.x + rect.w, rect.y);
		rect.setSize(-rect.w, rect.h);
	}
	if (rect.h < 0) {
		rect.setPos(rect.x, rect.y + rect.h);
		rect.setSize(rect.w, -rect.h);
	}
}
