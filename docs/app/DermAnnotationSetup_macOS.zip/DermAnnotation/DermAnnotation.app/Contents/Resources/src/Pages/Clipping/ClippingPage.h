#include <GUIKit.h>

#include "../../DermImage/DermImage.h"
#include "../../UsetInterfaces/UIMenubar/UIMenubar.h"

class ClippingPage : public gui::Page {
	DermImage* m_image;
	Rect m_clippedRect;
	Vec2 m_drawingBasePos;

	UIMenubar ui_menubar = UIMenubar();

	gui::UIZStackedImageView ui_imageView = gui::UIZStackedImageView();
	gui::UIRect ui_frameRect = gui::UIRect();

public:
	using Page::Page;

	void onLoaded() override;

	void onBeforeAppeared() override;

	void onWindowResized() override;

	void onAfterDisappeared() override;

	void setImage(const DermImage& image);

	void fixRect(Rect& rect);
};
