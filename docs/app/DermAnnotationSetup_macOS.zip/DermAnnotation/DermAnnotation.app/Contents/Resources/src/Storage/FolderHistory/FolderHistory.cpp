#include "FolderHistory.h"
#include "../../FileManager/FileManager.h"

const FilePath FolderHistory::Path = FileManager::ApplicationDataPath() + U"FolderHistory.bin";

Array<FolderHistory::FolderData> FolderHistory::History;

void FolderHistory::Load() {
	Deserializer<BinaryReader> reader(Path);
	if (reader.getReader()) {
		try {
			reader(History);
		}catch(...){}
	}
}

void FolderHistory::Add(const FilePath& path) {
	History.remove_if([path](const FolderHistory::FolderData& data) { return data.path == path; });
	History.push_front({ path, DateTime::Now() });
}

void FolderHistory::Save() {
	Serializer<BinaryWriter> writer(Path);
	if (writer.getWriter()) {
		try {
			writer(History);
		}
		catch (...) {}
	}
}

void FolderHistory::Remove() {
	History.release();
	FileSystem::Remove(Path);
}
