#pragma once

#include "UIPencilRadiusSelectorElement/UIPencilRadiusSelectorElement.h"

#include <GUIKit.h>

enum class PencilRadius : int {
	Small = 15,
	Medium = 35,
	Large = 80
};

class UIPencilRadiusSelector final : public gui::UIView {
private:
	UIPencilRadiusSelectorElement ui_pencilSmall = UIPencilRadiusSelectorElement(static_cast<int>(PencilRadius::Small));
	UIPencilRadiusSelectorElement ui_pencilMedium = UIPencilRadiusSelectorElement(static_cast<int>(PencilRadius::Medium));
	UIPencilRadiusSelectorElement ui_pencilLarge = UIPencilRadiusSelectorElement(static_cast<int>(PencilRadius::Large));

public:
	void setColor(const Color& color);

	void setPencilRadiusSelectedHandler(const std::function<void(int)>& handler);

protected:
	void initialize() override;
};
