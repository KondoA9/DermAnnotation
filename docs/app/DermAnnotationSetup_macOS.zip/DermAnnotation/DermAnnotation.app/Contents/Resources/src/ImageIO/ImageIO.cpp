#include "ImageIO.h"

#include "../FileManager/FileManager.h"

#include "TIFFImage/TIFFImageIO.h"
#include "VirtualSlide/VirtualSlide.h"

namespace ImageIO {
	const Array<String> Siv3DExtensions = {
		U"jpg", U"jpeg",
		U"png",
		U"gif",
		U"bmp",
	};

	const Array<String> TiffExtensions = {
		U"tiff", U"tif"
	};
	
	const Array<String> VirtualSlideExtensions = {
		U"ndpi", U"vms", U"vmu", U"svs", U"scn"
	};

	namespace Internal {
		DermImage Load(const FilePath& path) {
			const auto ext = FileSystem::Extension(path);
			if (TiffExtensions.includes(ext)) {
				return TIFFImage::Load(path);
			}
			else if (VirtualSlideExtensions.includes(ext)) {
				return VirtualSlide::Load(path);
			}
			else if (Siv3DExtensions.includes(ext)) {
				DermImage dermImage = DermImage(Image(path));
				return dermImage;
			}
			else {
				return DermImage();
			}
		}
	}

	bool isAvailableImageType(const FilePath& path) {
		const String ext = FileSystem::Extension(path);
		return Siv3DExtensions.includes(ext) || TiffExtensions.includes(ext) || VirtualSlideExtensions.includes(ext);
	}

	DermImage Load(const FilePath& path) {
		if (const auto p = path; FileSystem::Exists(p)) {
			// Load annotated image
			if (const DermImage image = Internal::Load(p); image.isValidImage()) {
				return image;
			}
		}

		// Load original image if failed to load annotated image
		return Internal::Load(path);
	}

	bool Save(const DermImage& dermImage, const FilePath& path) {
		return TIFFImage::Save(path, dermImage);
	}
}
