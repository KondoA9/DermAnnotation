#include "EditorPage.h"
#include "../Clipping/ClippingPage.h"
#include "../../ImageIO/ImageIO.h"
#include "../../Storage/UserConfiguration/UserConfiguration.h"

void EditorPage::setupEditor() {
	// Wait saveing image
	while (!m_imageSaved) {}

	// Load image
	setSelectedFileInFilesView();
	setImageStatusIcon(ImageStatus::Loading);
	gui::GUIKit::Instance().insertAsyncProcess(
		[this] {
			const auto output = m_workSpace.outputImagePath();
			m_dermImage = ImageIO::Load(FileSystem::Exists(output) ? output : m_workSpace.imagePath());
        
            if (m_dermImage.size().isZero()){
                return;
            }
        
            m_editingImageRect = Rect(0, 0, m_dermImage.size());

            // Take over the previous pencils if need
            if (!m_dermImage.hasPencils()) {
                if (m_previousPencils.size() > 0) {
                    for (const auto& pencil : m_previousPencils) {
                        m_dermImage.appendLayer(pencil);
                    }
                }
                else {
                    m_dermImage.appendLayer(Pencil());
                }
            }
		},
		[this] {
			m_clipping = UserConfiguration::Config.clippingIfLoadBigImage && (m_dermImage.size().x * m_dermImage.size().y > 25000000);

			if (m_clipping && UserConfiguration::Config.showMessageBoxWhenClipping) {
				const auto result = System::ShowMessageBox(U"トリミングしますか？", MessageBoxButtons::OKCancel);
				m_clipping = result == MessageBoxSelection::OK;
			}

			if (m_clipping) {
				auto& page = gui::GUIKit::Instance().getPage<ClippingPage>(U"clipping");
				page.setImage(m_dermImage);
				gui::GUIKit::Instance().switchPage(U"clipping");
			}
			else {
				applyImageToEditor();
			}
		});
}

void EditorPage::saveImageSync() {
	m_imageEdited = false;
	setImageStatusIcon(ImageStatus::Saving);

	for (size_t i : step(m_layers.size())) {
		if (m_clipped) {
			Image layer = m_dermImage.layer(i).image();
			m_layers[i].overwrite(layer, m_editingImageRect.pos);
			m_dermImage.setLayer(i, layer);
		}
		else {
			m_dermImage.setLayer(i, m_layers[i]);
		}
	}

	const DermImage copiedImage = m_dermImage;
	const auto path = m_workSpace.outputImagePath();
	ImageIO::Save(copiedImage,path);

	m_imageSaved = true;

	if (m_imageEdited) {
		setImageStatusIcon(ImageStatus::Pending);
		gui::GUIKit::Instance().insertProcessToMainThread([this] { autoSave(); });
	}
	else {
		setImageStatusIcon(ImageStatus::Saved);
	}
}

void EditorPage::saveImageAsync(double timeout, const std::function<void()>& completion) {
	m_imageSaved = false;

	if (gui::GUIKit::Instance().isTimeoutAlive(m_savingImageProcessID)) {
		gui::GUIKit::Instance().restartTimeout(m_savingImageProcessID);
	}
	else {
		setImageStatusIcon(ImageStatus::Pending);

		m_savingImageProcessID = gui::GUIKit::Instance().setTimeout(
			[this, completion] {
				saveImageSync();
				if (completion) {
					completion();
				}
			}, timeout, true);
	}
}

bool EditorPage::saveImageSyncIfNeeded() {
	if (gui::GUIKit::Instance().stopTimeout(m_savingImageProcessID)) {
		saveImageSync();
		return true;
	}
	else {
		while (!m_imageSaved) {}
		if (m_imageEdited) {
			saveImageSync();
			return true;
		}
	}

	return false;
}

int EditorPage::saveImageAsyncIfNeeded(double timeout, const std::function<void()>& completion) {
	if (gui::GUIKit::Instance().stopTimeout(m_savingImageProcessID) || m_imageEdited) {
		saveImageAsync(timeout, completion);
		return 1;
	}
	else {
		if (gui::GUIKit::Instance().isTimeoutAlive(m_savingImageProcessID)) {
			// Now saving
			return -1;
		}
	}

	return 0;
}

void EditorPage::autoSave() {
	m_imageEdited = true;
	if (UserConfiguration::Config.autoSave) {
		saveImageAsync(10000);
	}
}
