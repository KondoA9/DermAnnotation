#include "EditorPage.h"
#include "Painter/Painter.h"
#include "../../Storage/FolderHistory/FolderHistory.h"
#include "../../Storage/UserConfiguration/UserConfiguration.h"
#include "../../FileManager/FileManager.h"
#include "../../UsetInterfaces/UINotifier/UINotifier.h"

void EditorPage::onLoaded() {
	ui_menubar.setup(view());

	setConstraints();

	setEvents();

	view().appendComponent(ui_editorView);
	view().appendComponent(ui_cursor);

	view().appendComponent(ui_buttonsView);
	view().appendComponent(ui_controllerView);
	view().appendComponent(ui_filesView);

	view().appendComponent(ui_imageSavedStatusIcon);
	view().appendComponent(ui_inputPathLabel);
	view().appendComponent(ui_inputPath);
	view().appendComponent(ui_outputPathLabel);
	view().appendComponent(ui_outputDirectory);
	view().appendComponent(ui_outputPath);

	view().appendComponent(ui_menubar);

	view().appendComponent(ui_pencilEditorView);
}

void EditorPage::onBeforeAppeared() {
	if (!m_sameFolderSelected && !m_clipping) {
		saveImageSyncIfNeeded();

		openFolder();

		initializeEditor();
	}

	UINotifier::Hide(true);
}

void EditorPage::onAfterAppeared() {
	if (!m_sameFolderSelected && !m_clipping) {
		setupEditor();
	}

	if (m_clipping) {
		applyImageToEditor();
		m_clipping = false;
	}

	m_sameFolderSelected = false;
}

void EditorPage::onWindowResized() {
	ui_controllerView.setEditorScale(ui_editorView.scaleRate());
	setMovingImageView();
}

void EditorPage::onAppTerminated() {
	m_layerTimeMachine.release();

	ui_controllerView.release();
	ui_editorView.release();

	saveImageSyncIfNeeded();
}

bool EditorPage::setRootFolder(const FilePath& path) {
	auto folders = FileSystem::DirectoryContents(FileSystem::ParentPath(path), false);
	folders.remove_if([](const FilePath& path) {
		return !FileSystem::IsDirectory(path);
		});
	folders.remove_if([](const FilePath& path) {
		return FileManager::GetImagesInFolder(path).size() == 0;
		});

	for (size_t i : step(folders.size())) {
		if (folders[i] == path) {
			m_folders = folders;
			return setWorkingFolder(static_cast<int>(i));
		}
	}

	return false;
}

bool EditorPage::setWorkingFolder(size_t folderIndex) {
	// Same folder
	if (m_folderPath == m_folders[folderIndex]) {
		m_sameFolderSelected = true;
		return true;
	}

	m_currentFolderIndex = folderIndex;

	const auto files = FileManager::GetImagesInFolder(m_folders[m_currentFolderIndex]);
	if (files.size() > 0) {
		m_folderPath = m_folders[m_currentFolderIndex];
		FolderHistory::Add(m_folderPath);
		return true;
	}

	return false;
}

void EditorPage::initializeEditor() {
	// Save current pencils for next image
	m_previousPencils.release();
	for (size_t i : step(m_dermImage.layerCount())) {
		m_previousPencils.push_back(m_dermImage.layer(i).pencil());
	}

	m_layerIndex = 0;

	ui_inputPath.setText(m_workSpace.imagePath());
	ui_outputDirectory.setText(m_workSpace.setting().outputDirectory);
	ui_outputPath.setText(FileSystem::BaseName(FileSystem::ParentPath(m_workSpace.imagePath())) + U"/" + FileSystem::FileName(m_workSpace.imagePath()));

	m_clipped = false;

	m_layerTimeMachine.release();
	m_dermImage.release();
	m_layers.release();

	ui_controllerView.release();
	ui_editorView.release();

	ui_menubar.controllable = false;
	ui_controllerView.controllable = false;
	ui_buttonsView.controllable = false;
	ui_editorView.controllable = false;
	ui_filesView.controllable = false;

	UINotifier::Hide();
}

void EditorPage::applyImageToEditor() {
	if (!m_dermImage.size().isZero()) {
		// Original image
		if (m_clipped) {
			const Image clippedOriginalImage = m_dermImage.originalImage().clipped(m_editingImageRect);
			ui_editorView.appendImage(clippedOriginalImage);
			ui_controllerView.setOriginalImageToMovingImageView(clippedOriginalImage);
		}
		else {
			ui_editorView.appendImage(m_dermImage.originalImage());
			ui_controllerView.setOriginalImageToMovingImageView(m_dermImage.originalImage());
		}

		// Layers
		for (size_t i : step(m_dermImage.layerCount())) {
			if (m_clipped) {
				const Image clippedLayer = m_dermImage.layer(i).image().clipped(m_editingImageRect);
				m_layers.push_back(clippedLayer);
				ui_editorView.appendImage(clippedLayer, 0.7);
			}
			else {
				m_layers.push_back(m_dermImage.layer(i).image());
				ui_editorView.appendImage(m_dermImage.layer(i).image(), 0.7);
			}
			ui_controllerView.appendPencil(m_dermImage.layer(i).pencil());
		}

		// Editor view
		ui_editorView.resetScale();

		// Controller view
		ui_controllerView.setPencilAlphaRate(0.7);
		ui_controllerView.setEditorScale(0.0);
		ui_controllerView.selectPencil(0);
		setMovingImageView();

		// Buttons view
		ui_buttonsView.setEraserEnabled(false);
		ui_buttonsView.setAreaSelectorEnabled(false);

		// Editor
		if (UserConfiguration::Config.resetPencilRadiusAutomatically) {
			setPencilRadius((m_minPencilRadius + m_maxPencilRadius) * 0.5);
		}
		ui_cursor.frameColor = m_dermImage.layer(0).pencil().color;
		Painter::SetCanvas(m_editingImageRect.size);
		m_layerTimeMachine.setImageSize(m_editingImageRect.size);

		// Release unnecessary objects
		if (!m_clipped) {
			m_dermImage.releaseLayers();
		}

		// Controllable
		ui_cursor.exist = true;
		ui_buttonsView.controllable = true;
		ui_editorView.controllable = true;
	}
	else {
		UINotifier::Show(U"画像の読み込みに失敗しました。画像サイズが大きすぎる可能性があります。", UINotifier::MessageType::Error);
	}

	// Controllable
	ui_menubar.controllable = true;

	if (ui_buttonsView.isFilesViewEnabled()) {
		ui_filesView.controllable = true;
	}
	else {
		ui_controllerView.controllable = true;
	}

	setImageStatusIcon(ImageStatus::Saved);
}

void EditorPage::setPencilRadius(double radius) {
	m_pencilRadius = radius;
	ui_cursor.setConstraint(gui::LayerDirection::Width, radius);
	ui_cursor.setConstraint(gui::LayerDirection::Height, radius);
	ui_controllerView.setPencilRadius(radius);
}

void EditorPage::repaintLayerByColor(size_t index, const Color& color) {
#pragma omp parallel for
	for (int i = 0; i < m_layers[index].height(); ++i) {
#pragma omp parallel for
		for (int j = 0; j < m_layers[index].width(); ++j) {
			if (m_layers[index][i][j].a == 255) {
				m_layers[index][i][j] = color;
			}
		}
	}

	ui_editorView.updateTexture(index + 1, m_layers[index]);
}

void EditorPage::moveImage(int imageIndex) {
	if (!m_workSpace.imageChangeable(imageIndex)) {
		return;
	}

	// Save current image if needed
	const int status = saveImageAsyncIfNeeded(0.0, [this, imageIndex] {
		gui::GUIKit::Instance().insertProcessToMainThread([this, imageIndex] {
			m_workSpace.setImage(imageIndex);
			initializeEditor();
			setupEditor();
			view().controllable = true;
			});
		});

	if (status == 0) {
		// Do no need to save
		m_workSpace.setImage(imageIndex);
		initializeEditor();
		setupEditor();
	}
	else if (status == 1) {
		// Saving
		view().controllable = false;
		UINotifier::Show(U"保存しています。", UINotifier::MessageType::Info);
	}
	else if (status == -1) {
		UINotifier::Show(U"保存終了後、操作を行ってください。", UINotifier::MessageType::Error);
	}
}

void EditorPage::moveFolder(int folderIndex) {
	if (folderIndex < 0) {
		folderIndex = static_cast<int>(m_folders.size() - 1);
	}
	if (folderIndex > static_cast<int>(m_folders.size() - 1)) {
		folderIndex = 0;
	}

	// Same folder, skip updating editor
	if (m_currentFolderIndex == folderIndex) {
		return;
	}

	// Save current image if needed
	if (setWorkingFolder(folderIndex)) {
		const int status = saveImageAsyncIfNeeded(0.0, [this] {
			gui::GUIKit::Instance().insertProcessToMainThread([this] {
				openFolder();
				initializeEditor();
				setupEditor();
				view().controllable = true;
				});
			});

		if (status == 0) {
			// Do no need to save
			openFolder();
			initializeEditor();
			setupEditor();
		}
		else if (status == 1) {
			// Saving
			view().controllable = false;
			UINotifier::Show(U"保存しています。", UINotifier::MessageType::Info);
		}
		else if (status == -1) {
			UINotifier::Show(U"保存終了後、操作を行ってください。", UINotifier::MessageType::Error);
		}
	}
}

void EditorPage::setImageStatusIcon(const ImageStatus& status) {
	switch (status)
	{
	case ImageStatus::Saved:
		ui_imageSavedStatusIcon.rotate = false;
		ui_imageSavedStatusIcon.iconColor = gui::DynamicColor::DefaultGreen;
		ui_imageSavedStatusIcon.setIcon(m_savedIcon);
		break;

	case ImageStatus::Pending:
		ui_imageSavedStatusIcon.rotate = false;
		ui_imageSavedStatusIcon.iconColor = gui::DynamicColor::DefaultRed;
		ui_imageSavedStatusIcon.setIcon(m_unsavedIcon);
		break;

	case ImageStatus::Saving:
		ui_imageSavedStatusIcon.rotate = true;
		ui_imageSavedStatusIcon.iconColor = gui::DynamicColor::Text;
		ui_imageSavedStatusIcon.setIcon(m_savingIcon);
		break;

	case ImageStatus::Loading:
		ui_imageSavedStatusIcon.rotate = true;
		ui_imageSavedStatusIcon.iconColor = gui::DynamicColor::Text;
		ui_imageSavedStatusIcon.setIcon(m_savingIcon);
		break;
	}
}

void EditorPage::appendPencil(const Pencil& pencil) {
	m_dermImage.appendLayer(pencil);

	ui_controllerView.appendPencil(pencil);
	ui_controllerView.setPencilAlphaRate(m_dermImage.layerCount() - 1, 0.7);

	if (m_clipped) {
		const Image clippedLayer = m_dermImage.layer(m_dermImage.layerCount() - 1).image().clipped(m_editingImageRect);
		ui_editorView.appendImage(clippedLayer, 0.7);
		m_layers.push_back(clippedLayer);
	}
	else {
		ui_editorView.appendImage(m_dermImage.layer(m_dermImage.layerCount() - 1).image(), 0.7);
		m_layers.push_back(m_dermImage.layer(m_dermImage.layerCount() - 1).image());
	}
}

void EditorPage::removePencil(size_t index) {
	m_dermImage.removeLayer(index);
	m_layers.remove_at(index);
	ui_editorView.removeImage(index + 1);
}

bool EditorPage::fixPencils(const Array<EditedPencil>& pencils) {
	bool edited = false;

	// Process for edited or added pencils
	for (size_t i = 0; i < pencils.size(); i++) {
		const auto& pencil = pencils[i].pencil;

		if (pencils[i].status == PencilEditedStatus::Edited) {
			m_dermImage.setPencil(i, pencil.name, pencil.color);
			ui_controllerView.setPencil(i, pencil.name, pencil.color);
			repaintLayerByColor(i, pencil.color);
			edited = true;
		}
		else if (pencils[i].status == PencilEditedStatus::Added) {
			appendPencil(pencil);
			edited = true;
		}
	}

	// Process for deleted pencils
	for (int i = static_cast<int>(pencils.size()) - 1; i >= 0; i--) {
		if (pencils[i].status == PencilEditedStatus::Deleted) {
			removePencil(static_cast<size_t>(i));
			edited = true;
		}
	}

	if (edited) {
		// Apply current pencils to controller view
		ui_controllerView.releasePencilBoxView();
		for (size_t i : step(m_dermImage.layerCount())) {
			ui_controllerView.appendPencil(m_dermImage.layer(i).pencil());
		}

		m_layerIndex = 0;
		ui_controllerView.selectPencil(m_layerIndex);
		ui_controllerView.setPencilAlphaRate(0.7);
		ui_cursor.frameColor = m_dermImage.layer(m_layerIndex).pencil().color;
	}

	return edited;
}

void EditorPage::setupFilesView() {
	ui_filesView.release();

	for (size_t i : step(m_workSpace.imagesCount())) {
		auto text = gui::UIText(FileSystem::FileName(m_workSpace.imagePath(i)), gui::UnifiedFontStyle::Small);
		text.penetrateMouseEvent = true;
		text.setPadding(0, 0, 10_px, 0);
		text.addEventListener<gui::MouseEvent::LeftDown>([this, i]() {
			moveImage(static_cast<int>(i));
			});
		text.addEventListener<gui::MouseEvent::Hovered>([](const gui::MouseEvent::Hovered& e) {
			e.component->backgroundColor.highlight(gui::DynamicColor::BackgroundSecondary);
			});
		text.addEventListener<gui::MouseEvent::UnHovered>([this, i](const gui::MouseEvent::UnHovered& e) {
			if (i != m_workSpace.currentIndex()) {
				e.component->backgroundColor.lowlight(gui::DynamicColor::Background);
			}
			});
		ui_filesView.appendTemporaryComponent(text);
	}
}

void EditorPage::setSelectedFileInFilesView() {
	for (auto c : ui_filesView.components()) {
		c->backgroundColor.lowlight(gui::DynamicColor::Background);
	}

	if (ui_filesView.components()) {
		ui_filesView.components()[m_workSpace.currentIndex()]->backgroundColor.highlight(gui::DynamicColor::BackgroundSecondary);
	}
}

void EditorPage::paintByPencil() {
	const Rect rect = Painter::Pencil::Paint(m_layers[m_layerIndex],
		static_cast<int32>(m_pencilRadius / ui_editorView.scale()),
		ui_buttonsView.isEraserEnabled() ? Color(255, 255, 255, 0) : m_dermImage.layer(m_layerIndex).pencil().color,
		ui_editorView.currentPixel(),
		ui_editorView.prePixel());
	ui_editorView.updateTexture(m_layerIndex + 1, m_layers[m_layerIndex], rect);
}

void EditorPage::paintRegion() {
	Painter::Region::Update(ui_editorView.currentPixel());
	gui::GUIKit::Instance().addDrawingEvent([this] {
		if (const auto pos = Cursor::PosF(); (m_drawPoints.size() <= 1 || m_drawPoints[m_drawPoints.size() - 1].distanceFrom(pos) > 10)) {
			m_drawPoints.push_back(pos);
			m_drawPolygons = Polygon::Correct(m_drawPoints);
		}
		for (auto& p : m_drawPolygons) {
			p.drawFrame(2.0, m_dermImage.layer(m_layerIndex).pencil().color);
		}
		});
}
