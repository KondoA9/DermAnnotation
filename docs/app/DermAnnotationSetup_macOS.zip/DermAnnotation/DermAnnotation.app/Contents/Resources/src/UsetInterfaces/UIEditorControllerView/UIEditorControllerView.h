#pragma once

#include "../UIPencilBoxView/UIPencilBoxView.h"
#include "../UIMovingImageView/UIMovingImageView.h"

#include <GUIKit.h>

class UIEditorControllerView final : public gui::UIView {
private:
    // Change file
    gui::UIButton ui_changeFileBackButton = gui::UIButton(Texture(Icon(0xf0d9, 30_px)), gui::DynamicColor::Background, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text);
    gui::UIButton ui_changeFileNextButton = gui::UIButton(Texture(Icon(0xf0da, 30_px)), gui::DynamicColor::Background, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text);
    gui::UIText ui_changeFileLabel = gui::UIText(U"画像切替", gui::UnifiedFontStyle::Small, gui::TextDirection::Center, gui::DynamicColor::Background);

    // Change folder
    gui::UIButton ui_changeFolderBackButton = gui::UIButton(Texture(Icon(0xf0d9, 30_px)), gui::DynamicColor::Background, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text);
    gui::UIButton ui_changeFolderNextButton = gui::UIButton(Texture(Icon(0xf0da, 30_px)), gui::DynamicColor::Background, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text);
    gui::UIText ui_changeFolderLabel = gui::UIText(U"フォルダ切り替え", gui::UnifiedFontStyle::Small, gui::TextDirection::Center, gui::DynamicColor::Background);

    // Pencil controller
    UIPencilBoxView ui_pencilBoxView = UIPencilBoxView();

    // Slider controller
    gui::UISlider ui_pencilRadiusSlider = gui::UISlider(U"ペンの太さ");
    gui::UISlider ui_allPencilsAlphaRateSlider = gui::UISlider(U"透過率の一括変更");
    gui::UISlider ui_editorScalingSlider = gui::UISlider(U"拡大率");

    // Slider value label
    gui::UICircle ui_pencilRadiusValueLabel = gui::UICircle();
    gui::UIText ui_pencilAlphaRateValueLabel = gui::UIText(gui::UnifiedFontStyle::Small, gui::TextDirection::Center);
    gui::UIText ui_editorScaleValueLabel = gui::UIText(gui::UnifiedFontStyle::Small, gui::TextDirection::Center);

    // Image movement
    UIMovingImageView ui_imageMoveView = UIMovingImageView();

public:
    using UIView::UIView;

    void release();

    void releasePencilBoxView() {
        ui_pencilBoxView.release();
    }

    /* Set handlers */
    void setFileBackHandler(const std::function<void()>& handler) {
        ui_changeFileBackButton.addEventListener<gui::MouseEvent::LeftDown>(handler);
    }

    void setFileNextHandler(const std::function<void()>& handler) {
        ui_changeFileNextButton.addEventListener<gui::MouseEvent::LeftDown>(handler);
    }

    void setFolderBackHandler(const std::function<void()>& handler) {
        ui_changeFolderBackButton.addEventListener<gui::MouseEvent::LeftDown>(handler);
    }

    void setFolderNextHandler(const std::function<void()>& handler) {
        ui_changeFolderNextButton.addEventListener<gui::MouseEvent::LeftDown>(handler);
    }

    void setAllPencilAlphaRateChangedHandler(const std::function<void(double)>& handler) {
        ui_allPencilsAlphaRateSlider.setValueChangedHandler([this, handler](double value) {
            setAllPencilAlphaRateValueLabel(value);
            handler(value);
            });
    }

    void setPencilRadiusChangedHandler(const std::function<void(double)>& handler) {
        ui_pencilRadiusSlider.setValueChangedHandler([this, handler](double value) {
            setPencilRadiusValueLabel(value);
            handler(value);
            });
    }

    void setEditorScalingChangedHandler(const std::function<void(double)>& handler) {
        ui_editorScalingSlider.setValueChangedHandler([this, handler](double value) {
            setEditorScaleValueLabel(value);
            handler(value);
            });
    }

    void setPencilChangedHandler(const std::function<void(size_t)>& handler) {
        ui_pencilBoxView.setPencilChangedHandler([this, handler](size_t index) {
            ui_pencilRadiusValueLabel.backgroundColor.highlight(ui_pencilBoxView.pencil(index).color);
            handler(index);
            });
    }

    void setPencilAlphaRateChangedHandler(const std::function<void(size_t, double)>& handler) {
        ui_pencilBoxView.setPencilAlphaChangedHandler(handler);
    }
    
    void setImageMovedHandler(const std::function<void(const Point& centerPixel)>& func) {
        ui_imageMoveView.setImageMovedHandler(func);
    }

    /* Set controller status */
    void setPencilAlphaRate(double value);

    void setOriginalImageToMovingImageView(const Image& image) {
        ui_imageMoveView.setOriginalImage(image);
    }

    void setPencilAlphaRate(size_t index, double value) {
        ui_pencilBoxView.setAlphaRate(index, value);
    }

    void setEditorScale(double value) {
        ui_editorScalingSlider.setValue(value);
        setEditorScaleValueLabel(value);
    }

    void setEditorScalingRange(double min, double max) {
        ui_editorScalingSlider.setRange(min, max);
    }

    void setMovingImageViewRect(const Rect& textureRegion, const Rect& visibleTextureRect, const Point& centerPixel) {
        ui_imageMoveView.setRect(textureRegion, visibleTextureRect, centerPixel);
    }

    void setPencilSliderRange(double min, double max) {
        ui_pencilRadiusSlider.setRange(min, max);
    }

    void setPencilRadius(double value) {
        ui_pencilRadiusSlider.setValue(value);
        setPencilRadiusValueLabel(value);
    }

    /* Operations */
    void appendPencil(const Pencil& pencil) {
        ui_pencilBoxView.appendPencil(pencil);
    }

    void setPencil(size_t index, const String& name, const Color& color) {
        ui_pencilBoxView.setPencil(index, name, color);
    }

    void selectPencil(size_t index) {
        ui_pencilBoxView.selectPencil(index);
        ui_pencilRadiusValueLabel.backgroundColor.highlight(ui_pencilBoxView.pencil(index).color);
    }

protected:
    void initialize() override;

private:
    void setChildConstraints();

    void appendComponents();

    void setPencilRadiusValueLabel(double value) {
        ui_pencilRadiusValueLabel.setConstraint(gui::LayerDirection::Height, value);
        ui_pencilRadiusValueLabel.setConstraint(gui::LayerDirection::Width, value);
    }

    void setAllPencilAlphaRateValueLabel(double value) {
        ui_pencilAlphaRateValueLabel.setText(ToString(value, 1));
    }

    void setEditorScaleValueLabel(double value) {
		ui_editorScaleValueLabel.setText(ToString(value, 1));
    }
};

