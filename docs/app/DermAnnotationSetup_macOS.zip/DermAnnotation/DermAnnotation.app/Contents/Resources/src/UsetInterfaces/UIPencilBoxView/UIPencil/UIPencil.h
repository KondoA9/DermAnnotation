#pragma once

#include "../../../DermImage/Pencil.h"

#include <GUIKit.h>

class UIPencil final : public gui::UIView {
	Pencil m_pencil;

	bool m_selected = false;
	Color m_color;
	std::function<void(double value)> m_alphaChangedHandler;

	gui::UIRect ui_colorRect;
	gui::UIText ui_pencilName;
	gui::UISlider ui_alphaSlider;

public:
	UIPencil(const Pencil& pencil);

	Pencil pencil() const {
		return m_pencil;
	}

	void select();

	void unSelect();

	void setColor(const Color& color);

	void setName(const String& pencilName) {
		ui_pencilName.setText(pencilName);
		m_pencil.name = pencilName;
	}

	void setAlphaRate(double rate) {
		ui_alphaSlider.setValue(rate);
	}

	void setAlphaChangedHandler(const std::function<void(double value)>& func) {
		m_alphaChangedHandler = func;
	}

protected:
	void initialize() override;

private:
	Color visibleColor(bool selected) const {
		return Color(m_color, selected ? 255 : 60);
	}
};
