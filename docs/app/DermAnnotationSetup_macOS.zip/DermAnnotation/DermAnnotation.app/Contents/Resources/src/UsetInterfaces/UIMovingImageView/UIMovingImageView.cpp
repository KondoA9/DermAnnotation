#include "UIMovingImageView.h"

#include <thread>

void UIMovingImageView::initialize() {
	addEventListener<gui::MouseEvent::LeftDragging>([this] {
		if (m_imageMovedHandler) {
			m_frameRect.setCenter(Cursor::Pos());

			restrictFrameRect();

			m_imageMovedHandler(gui::Imaging::ScenePosToPixel(Cursor::PosF(), ui_imageView.textureRegion(), ui_imageView.scale() * m_resizedImageScale));
		}
		});

	ui_imageView.manualScalingEnabled = false;
	ui_imageView.penetrateMouseEvent = true;
	ui_imageView.setConstraint(gui::LayerDirection::Top, *this, gui::LayerDirection::Top);
	ui_imageView.setConstraint(gui::LayerDirection::Bottom, *this, gui::LayerDirection::Bottom);
	ui_imageView.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left);
	ui_imageView.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);

	appendComponent(ui_imageView);

	UIView::initialize();
}

void UIMovingImageView::release() {
	m_frameRect.setCenter(rect().center().asPoint());
	ui_imageView.release();
}

void UIMovingImageView::setOriginalImage(const Image& image) {
	m_resizedImageScale = Min(static_cast<double>(rect().w) / image.width(), static_cast<double>(rect().h) / image.height());
	m_resizedImageScale = m_resizedImageScale < 1.0 ? m_resizedImageScale : 1.0;

	const Image resizedImage = image.scaled(m_resizedImageScale);
	ui_imageView.appendImage(resizedImage);
	ui_imageView.resetScale();
	m_frameRect.setSize(ui_imageView.textureRegion().size);
	m_frameColor = getOppositeColor(resizedImage);
}

void UIMovingImageView::setRect(const Rect& textureRegion, const Rect& visibleTextureRect, const Point& centerPixel) {
	const double scale = Min(ui_imageView.textureRegion().w / static_cast<double>(textureRegion.w), ui_imageView.textureRegion().h / static_cast<double>(textureRegion.h));
	m_frameRect.setSize(Size(static_cast<uint32>(visibleTextureRect.w * scale), static_cast<uint32>(visibleTextureRect.h * scale)));
	const auto pos = gui::Imaging::PixelToScenePos(centerPixel, ui_imageView.textureRegion(), ui_imageView.scale() * m_resizedImageScale);
	m_frameRect.setCenter(pos.asPoint());
	restrictFrameRect();
}

void UIMovingImageView::draw() {
	UIView::draw();

	if (!m_rectInitialized && ui_imageView.texturesCount() > 0) {
		m_frameRect.setSize(ui_imageView.textureRegion().size);
		m_frameRect.setCenter(rect().center().asPoint());
		m_rectInitialized = true;
	}

	m_frameRect.drawFrame(2.0_px, 0.0, m_frameColor);
}

void UIMovingImageView::restrictFrameRect() {
	if (m_frameRect.x < ui_imageView.textureRegion().x) {
		m_frameRect.x = ui_imageView.textureRegion().x;
	}
	else if (m_frameRect.x + m_frameRect.w > ui_imageView.textureRegion().x + ui_imageView.textureRegion().w) {
		m_frameRect.x = ui_imageView.textureRegion().x + ui_imageView.textureRegion().w - m_frameRect.w;
	}

	if (m_frameRect.y < ui_imageView.textureRegion().y) {
		m_frameRect.y = ui_imageView.textureRegion().y;
	}
	else if (m_frameRect.y + m_frameRect.h > ui_imageView.textureRegion().y + ui_imageView.textureRegion().h) {
		m_frameRect.y = ui_imageView.textureRegion().y + ui_imageView.textureRegion().h - m_frameRect.h;
	}
}

Color UIMovingImageView::getOppositeColor(const Image& image) {
	uint32 r = 0, g = 0, b = 0;
#pragma omp parallel for reduction(+:r) reduction(+:g) reduction(+:b)
	for (int j = 0; j < image.height(); j++) {
#pragma omp parallel for reduction(+:r) reduction(+:g) reduction(+:b)
		for (int i = 0; i < image.width(); i++) {
			r += image[j][i].r;
			g += image[j][i].g;
			b += image[j][i].b;
		}
	}

	const int32 pixels = image.width() * image.height();
	return Color(255 - r / pixels, 255 - g / pixels, 255 - b / pixels);
}
