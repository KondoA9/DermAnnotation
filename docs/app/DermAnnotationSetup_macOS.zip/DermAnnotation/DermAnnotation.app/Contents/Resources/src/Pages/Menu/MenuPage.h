#pragma once

#include "../../Version.h"
#include "../../UsetInterfaces/UIReleaseNoteView/UIReleaseNoteView.h"

#include <GUIKit.h>

class MenuPage : public gui::Page {
	bool startup = true;
    size_t m_historyPageIndex = 0;

    gui::UIRect ui_toolBox = gui::UIRect();
    gui::UIButton ui_openDirectoryButton = gui::UIButton(U"新規");
    gui::UIButton ui_settingButton = gui::UIButton(U"設定");
    gui::UIButton ui_openHomepageButton = gui::UIButton(U"About", gui::DynamicColor::Clear, gui::DynamicColor::Clear, gui::DynamicColor::Text);
    gui::UIButton ui_toggleColorModeButton = gui::UIButton(Texture(Icon(0xf186, 40)));

    gui::UIText ui_appTitle = gui::UIText(U"DermAnnotation " + Unicode::FromWString(Version::DermAnnotationVersion), gui::UnifiedFontStyle::Large, gui::TextDirection::LeftCenter);
    gui::UIButton ui_toggleReleaseNoteButton = gui::UIButton(gui::DynamicColor::Background, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text);

    gui::UIText ui_recentlyOpenedDirectoryLabel = gui::UIText(U"最近開いたフォルダ", gui::UnifiedFontStyle::Medium, gui::TextDirection::LeftCenter);
    gui::UIButton ui_nextHistoryPageButton = gui::UIButton(Texture(Icon(0xf0da, 60_px)), gui::DynamicColor::Background, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text);
    gui::UIButton ui_backHistoryPageButton = gui::UIButton(Texture(Icon(0xf0d9, 60_px)), gui::DynamicColor::Background, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text);
    gui::UIVStackView ui_recentlyOpenedDirectoryView = gui::UIVStackView();

    UIReleaseNoteView ui_releaseNoteView = UIReleaseNoteView();

public:
    using Page::Page;

    void onLoaded() override;

    void onBeforeAppeared() override;

private:
    void selectFolder(const FilePath& path);

    void updateHistoryView(size_t page);
};
