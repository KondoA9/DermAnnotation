#include "UIPencil.h"

UIPencil::UIPencil(const Pencil& pencil) :
	UIView(gui::DynamicColor::Background),
	m_pencil({ .name = pencil.name, .color = pencil.color }),
	m_color(pencil.color),
	ui_colorRect(visibleColor(false)),
	ui_pencilName(gui::UIText(pencil.name, gui::UnifiedFontStyle::Small, gui::TextDirection::LeftCenter)),
	ui_alphaSlider(gui::UISlider())
{}

void UIPencil::initialize() {
	addEventListener<gui::MouseEvent::Hovered>([this] {
		if (!m_selected) {
			ui_colorRect.backgroundColor.highlight(visibleColor(true));
		}
		backgroundColor.highlight(gui::DynamicColor::BackgroundHovered);
		});

	addEventListener<gui::MouseEvent::UnHovered>([this] {
		if (!m_selected) {
			ui_colorRect.backgroundColor.lowlight(visibleColor(false));
		}
		backgroundColor.lowlight(gui::DynamicColor::Background);
		});

	addEventListener<gui::MouseEvent::Hovering>([] {
		Cursor::RequestStyle(CursorStyle::Hand);
		});

	ui_colorRect.penetrateMouseEvent = true;
	ui_colorRect.setConstraint(gui::LayerDirection::Top, *this, gui::LayerDirection::Top);
	ui_colorRect.setConstraint(gui::LayerDirection::Bottom, *this, gui::LayerDirection::Bottom);
	ui_colorRect.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left);
	ui_colorRect.setConstraint(gui::LayerDirection::Width, 100_px);

	ui_pencilName.setPadding(0, 0, 20, 0);
	ui_pencilName.penetrateMouseEvent = true;
	ui_pencilName.setConstraint(gui::LayerDirection::CenterY, *this, gui::LayerDirection::CenterY);
	ui_pencilName.setConstraint(gui::LayerDirection::Height, *this, gui::LayerDirection::Height, 0.0, 0.5);
	ui_pencilName.setConstraint(gui::LayerDirection::Left, ui_colorRect, gui::LayerDirection::Right);
	ui_pencilName.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);

	ui_alphaSlider.setConstraint(gui::LayerDirection::Bottom, *this, gui::LayerDirection::Bottom);
	ui_alphaSlider.setConstraint(gui::LayerDirection::Height, *this, gui::LayerDirection::Height, 0.0, 0.5);
	ui_alphaSlider.setConstraint(gui::LayerDirection::Left, ui_colorRect, gui::LayerDirection::Right, 10_px);
	ui_alphaSlider.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right, -10_px);
	ui_alphaSlider.setValueChangedHandler(m_alphaChangedHandler);

	appendComponent(ui_colorRect);
	appendComponent(ui_pencilName);
	appendComponent(ui_alphaSlider);

	UIView::initialize();
}

void UIPencil::setColor(const Color& color) {
	m_color = color;
	ui_colorRect.backgroundColor = visibleColor(m_selected);
	m_pencil.color = color;
}

void UIPencil::select() {
	m_selected = true;
	ui_pencilName.setFont(gui::UnifiedFontStyle::SmallBold);
	ui_colorRect.backgroundColor.highlight(visibleColor(m_selected));
}

void UIPencil::unSelect() {
	m_selected = false;
	ui_pencilName.setFont(gui::UnifiedFontStyle::Small);
	ui_colorRect.backgroundColor.lowlight(visibleColor(m_selected));
}
