#include "UserConfiguration.h"
#include "../../FileManager/FileManager.h"

const FilePath UserConfiguration::Path = FileManager::ApplicationDataPath() + U"UserConfiguration.bin";

UserConfiguration::Configurations UserConfiguration::Config;

void UserConfiguration::Load() {
	Deserializer<BinaryReader> reader(Path);
	if (reader.getReader()) {
		try {
			reader(Config);
		}
		catch (...) {}
	}
}

void UserConfiguration::Save() {
	Serializer<BinaryWriter> writer(Path);
	if (writer.getWriter()) {
		try {
			writer(Config);
		}
		catch (...) {}
	}
}

void UserConfiguration::Remove() {
	FileSystem::Remove(Path);
}
