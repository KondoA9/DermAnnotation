#include "UIPencilEditorSettingView.h"
#include "../../UINotifier/UINotifier.h"

void UIPencilEditorSettingView::initialize() {
	ui_settingsView.setRowHeight(40_px);
	ui_settingsView.setConstraint(gui::LayerDirection::Top, *this, gui::LayerDirection::Top);
	ui_settingsView.setConstraint(gui::LayerDirection::Bottom, ui_callSettingButton, gui::LayerDirection::Top);
	ui_settingsView.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left);
	ui_settingsView.setConstraint(gui::LayerDirection::Width, *this, gui::LayerDirection::Width, 0.0, 0.5);

	ui_pencilsView.setConstraint(gui::LayerDirection::Top, *this, gui::LayerDirection::Top);
	ui_pencilsView.setConstraint(gui::LayerDirection::Bottom, ui_callSettingButton, gui::LayerDirection::Top);
	ui_pencilsView.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);
	ui_pencilsView.setConstraint(gui::LayerDirection::Width, *this, gui::LayerDirection::Width, 0.0, 0.5);

	ui_callSettingButton.drawFrame = true;
	ui_callSettingButton.setConstraint(gui::LayerDirection::Bottom, ui_exportSettingButton, gui::LayerDirection::Top);
	ui_callSettingButton.setConstraint(gui::LayerDirection::Height, 40_px);
	ui_callSettingButton.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left);
	ui_callSettingButton.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);
	ui_callSettingButton.addEventListener<gui::MouseEvent::LeftDown>([this] {
		if (m_index.has_value()) {
			const auto result = System::ShowMessageBox(U"現在編集中の内容は全て削除され、元に戻すことはできません。", MessageBoxStyle::Warning, MessageBoxButtons::OKCancel);
			if (result == MessageBoxSelection::OK) {
				m_pencilSettingCalledHandler(m_pencilBoxes[m_index.value()].pencils);
			}
		}
		else {
			UINotifier::Show(U"呼び出す設定を選択してください。", UINotifier::MessageType::Error);
		}
		});

	ui_exportSettingButton.drawFrame = true;
	ui_exportSettingButton.setConstraint(gui::LayerDirection::Bottom, ui_exportAllSettingButton, gui::LayerDirection::Top);
	ui_exportSettingButton.setConstraint(gui::LayerDirection::Height, 40_px);
	ui_exportSettingButton.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left);
	ui_exportSettingButton.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);
	ui_exportSettingButton.addEventListener<gui::MouseEvent::LeftDown>([this] {
		if (m_index.has_value()) {
			const auto result = Dialog::SelectFolder();
			if (result.has_value()) {
				PencilSetting::Export(m_pencilBoxes[m_index.value()], result.value());
				UINotifier::Show(U"設定をエクスポートしました。", UINotifier::MessageType::Info);
			}
		}
		else {
			UINotifier::Show(U"エクスポートする設定を選択してください。", UINotifier::MessageType::Error);
		}
		});

	ui_exportAllSettingButton.drawFrame = true;
	ui_exportAllSettingButton.setConstraint(gui::LayerDirection::Bottom, ui_importSettingButton, gui::LayerDirection::Top);
	ui_exportAllSettingButton.setConstraint(gui::LayerDirection::Height, 40_px);
	ui_exportAllSettingButton.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left);
	ui_exportAllSettingButton.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);
	ui_exportAllSettingButton.addEventListener<gui::MouseEvent::LeftDown>([this] {
		const auto result = Dialog::SelectFolder();
		if (result.has_value()) {
			PencilSetting::ExportAllSettings(result.value());
			UINotifier::Show(U"全ての設定をエクスポートしました。", UINotifier::MessageType::Info);
		}
		});

	ui_importSettingButton.drawFrame = true;
	ui_importSettingButton.setConstraint(gui::LayerDirection::Bottom, *this, gui::LayerDirection::Bottom);
	ui_importSettingButton.setConstraint(gui::LayerDirection::Height, 40_px);
	ui_importSettingButton.setConstraint(gui::LayerDirection::Left, *this, gui::LayerDirection::Left);
	ui_importSettingButton.setConstraint(gui::LayerDirection::Right, *this, gui::LayerDirection::Right);
	ui_importSettingButton.addEventListener<gui::MouseEvent::LeftDown>([this] {
		const auto result = Dialog::OpenFile({ FileFilter({.name = U"DermAnnotation Pencil Setting", .patterns = {U"json"}}) });
		if (result.has_value()) {
			if (PencilSetting::ImportFromFile(result.value())) {
				setup();
				UINotifier::Show(U"設定をインポートしました。", UINotifier::MessageType::Info);
			}
			else {
				UINotifier::Show(U"このファイルはインポート出来ないか、すでに追加されています。", UINotifier::MessageType::Error);
			}
		}
		});

	appendComponent(ui_settingsView);
	appendComponent(ui_pencilsView);
	appendComponent(ui_callSettingButton);
	appendComponent(ui_exportSettingButton);
	appendComponent(ui_exportAllSettingButton);
	appendComponent(ui_importSettingButton);
}

void UIPencilEditorSettingView::setup() {
	m_pencilBoxes = PencilSetting::GetSettings();

	m_index = none;
	ui_settingsView.release();
	ui_pencilsView.release();

	for (size_t i = 0; i < m_pencilBoxes.size(); i++) {
		auto button = gui::UIButton(m_pencilBoxes[i].name, gui::DynamicColor::Background, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text);
		button.addEventListener<gui::MouseEvent::LeftDown>([this, i] {
			setupPencilsView(m_pencilBoxes[i].pencils);
			m_index = i;
			});
		ui_settingsView.appendTemporaryComponent(button);
	}
}

void UIPencilEditorSettingView::setupPencilsView(const Array<Pencil>& pencils) {
	ui_pencilsView.release();

	for (const auto& pencil : pencils) {
		ui_pencilsView.appendPencil(pencil);
	}
}
