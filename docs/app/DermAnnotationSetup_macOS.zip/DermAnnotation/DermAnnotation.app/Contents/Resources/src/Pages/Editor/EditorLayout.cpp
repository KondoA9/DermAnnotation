#include "EditorPage.h"
#include "../../Storage/UserConfiguration/UserConfiguration.h"

void EditorPage::setConstraints() {
	/* Pencil editor view */
	ui_pencilEditorView.hidden = true;
	ui_pencilEditorView.drawFrame = true;
	ui_pencilEditorView.setConstraint(gui::LayerDirection::CenterY, view(), gui::LayerDirection::CenterY);
	ui_pencilEditorView.setConstraint(gui::LayerDirection::Height, ui_editorView, gui::LayerDirection::Height, 0.0, 0.8);
	ui_pencilEditorView.setConstraint(gui::LayerDirection::CenterX, view(), gui::LayerDirection::CenterX);
	ui_pencilEditorView.setConstraint(gui::LayerDirection::Width, 800_px);

	/* Setup Editor view */
	ui_editorView.setConstraint(gui::LayerDirection::Top, ui_menubar, gui::LayerDirection::Bottom);
	ui_editorView.setConstraint(gui::LayerDirection::Bottom, ui_inputPath, gui::LayerDirection::Top);
	if (UserConfiguration::Config.leftSideController) {
		ui_editorView.setConstraint(gui::LayerDirection::Left, ui_buttonsView, gui::LayerDirection::Right);
		ui_editorView.setConstraint(gui::LayerDirection::Right, view(), gui::LayerDirection::Right);
	}
	else {
		ui_editorView.setConstraint(gui::LayerDirection::Left);
		ui_editorView.setConstraint(gui::LayerDirection::Right, ui_buttonsView, gui::LayerDirection::Left);
	}

	/* Setup Controll buttons view */
	ui_buttonsView.drawFrame = true;
	ui_buttonsView.setConstraint(gui::LayerDirection::Top, ui_menubar, gui::LayerDirection::Bottom);
	ui_buttonsView.setConstraint(gui::LayerDirection::Bottom, view(), gui::LayerDirection::Bottom);
	ui_buttonsView.setConstraint(gui::LayerDirection::Width, 50_px);
	if (UserConfiguration::Config.leftSideController) {
		ui_buttonsView.setConstraint(gui::LayerDirection::Left, ui_controllerView, gui::LayerDirection::Right);
	}
	else {
		ui_buttonsView.setConstraint(gui::LayerDirection::Right, ui_controllerView, gui::LayerDirection::Left);
	}

	/* Setup Controller view */
	ui_controllerView.drawFrame = true;
	ui_controllerView.setConstraint(gui::LayerDirection::Top, ui_menubar, gui::LayerDirection::Bottom);
	ui_controllerView.setConstraint(gui::LayerDirection::Bottom, view(), gui::LayerDirection::Bottom);
	ui_controllerView.setConstraint(gui::LayerDirection::Width, 350_px);
	if (UserConfiguration::Config.leftSideController) {
		ui_controllerView.setConstraint(gui::LayerDirection::Left);
	}
	else {
		ui_controllerView.setConstraint(gui::LayerDirection::Right, view(), gui::LayerDirection::Right);
	}
	ui_controllerView.setEditorScalingRange(0.0, 1.0);
	ui_controllerView.setPencilSliderRange(m_minPencilRadius, m_maxPencilRadius);
	setPencilRadius((m_minPencilRadius + m_maxPencilRadius) * 0.5);

	/* Setup Files view*/
	ui_filesView.hidden = true;
	ui_filesView.controllable = false;
	ui_filesView.drawFrame = true;
	ui_filesView.setRowHeight(35_px);
	ui_filesView.setConstraint(gui::LayerDirection::Top, ui_menubar, gui::LayerDirection::Bottom);
	ui_filesView.setConstraint(gui::LayerDirection::Bottom, view(), gui::LayerDirection::Bottom);
	ui_filesView.setConstraint(gui::LayerDirection::Width, 350_px);
	if (UserConfiguration::Config.leftSideController) {
		ui_filesView.setConstraint(gui::LayerDirection::Left);
	}
	else {
		ui_filesView.setConstraint(gui::LayerDirection::Right, view(), gui::LayerDirection::Right);
	}

	/* Setup Image saved status icon*/
	ui_imageSavedStatusIcon.drawFrame = true;
	ui_imageSavedStatusIcon.rotationAnglerVelocity = 360_deg;
	ui_imageSavedStatusIcon.setConstraint(gui::LayerDirection::Height, 60_px);
	ui_imageSavedStatusIcon.setConstraint(gui::LayerDirection::Bottom, view(), gui::LayerDirection::Bottom);
	ui_imageSavedStatusIcon.setConstraint(gui::LayerDirection::Left);
	ui_imageSavedStatusIcon.setConstraint(gui::LayerDirection::Width, 60_px);
	setImageStatusIcon(ImageStatus::Saved);

	/* Setup Filename text*/
	ui_inputPathLabel.drawFrame = true;
	ui_inputPathLabel.setConstraint(gui::LayerDirection::Height, ui_imageSavedStatusIcon, gui::LayerDirection::Height, 0.0, 0.5);
	ui_inputPathLabel.setConstraint(gui::LayerDirection::Bottom, ui_outputPath, gui::LayerDirection::Top);
	ui_inputPathLabel.setConstraint(gui::LayerDirection::Left, ui_imageSavedStatusIcon, gui::LayerDirection::Right);
	ui_inputPathLabel.setConstraint(gui::LayerDirection::Width, 80_px);

	ui_inputPath.drawFrame = true;
	ui_inputPath.setPadding(0, 0, 20, 0);
	ui_inputPath.setConstraint(gui::LayerDirection::Height, ui_imageSavedStatusIcon, gui::LayerDirection::Height, 0.0, 0.5);
	ui_inputPath.setConstraint(gui::LayerDirection::Bottom, ui_outputPath, gui::LayerDirection::Top);
	ui_inputPath.setConstraint(gui::LayerDirection::Left, ui_inputPathLabel, gui::LayerDirection::Right);
	ui_inputPath.setConstraint(gui::LayerDirection::Right, ui_buttonsView, gui::LayerDirection::Left);

	ui_outputPathLabel.drawFrame = true;
	ui_outputPathLabel.setConstraint(gui::LayerDirection::Height, ui_imageSavedStatusIcon, gui::LayerDirection::Height, 0.0, 0.5);
	ui_outputPathLabel.setConstraint(gui::LayerDirection::Bottom, view(), gui::LayerDirection::Bottom);
	ui_outputPathLabel.setConstraint(gui::LayerDirection::Left, ui_imageSavedStatusIcon, gui::LayerDirection::Right);
	ui_outputPathLabel.setConstraint(gui::LayerDirection::Width, 80_px);

	ui_outputDirectory.drawFrame = true;
	ui_outputDirectory.setPadding(0, 0, 20, 0);
	ui_outputDirectory.setConstraint(gui::LayerDirection::Height, ui_imageSavedStatusIcon, gui::LayerDirection::Height, 0.0, 0.5);
	ui_outputDirectory.setConstraint(gui::LayerDirection::Bottom, view(), gui::LayerDirection::Bottom);
	ui_outputDirectory.setConstraint(gui::LayerDirection::Left, ui_outputPathLabel, gui::LayerDirection::Right);
	ui_outputDirectory.setConstraint(gui::LayerDirection::Width, 700_px);

	ui_outputPath.drawFrame = true;
	ui_outputPath.setPadding(0, 0, 20, 0);
	ui_outputPath.setConstraint(gui::LayerDirection::Height, ui_imageSavedStatusIcon, gui::LayerDirection::Height, 0.0, 0.5);
	ui_outputPath.setConstraint(gui::LayerDirection::Bottom, view(), gui::LayerDirection::Bottom);
	ui_outputPath.setConstraint(gui::LayerDirection::Left, ui_outputDirectory, gui::LayerDirection::Right);
	ui_outputPath.setConstraint(gui::LayerDirection::Right, ui_buttonsView, gui::LayerDirection::Left);

	/* Setup Cursor */
	ui_cursor.penetrateMouseEvent = true;
	ui_cursor.fillInner = false;
	ui_cursor.drawFrame = true;
	ui_cursor.frameThickness = 2.0;
	ui_cursor.backgroundColor = Color(255, 255, 255, 120);
}
