#pragma once

#include <Siv3D.hpp>

#include <libtiff_4.2.0/tiffio.h>

enum class TIFFArrayType :int {
	Scanline,
	Strip,
	Tiled,
	Unknown
};

struct TIFFInfo {
	uint32 width, height;
	uint16 samplePerPixel, bitPerSample;//4, 8
	uint16 photoMetric, planarConfig;//rgb(2), contig(1)
	uint16 compression;//lzw(5)

	//read only
	TIFFArrayType arrayType = TIFFArrayType::Unknown;
	uint32 rowsPerStrip;
	tmsize_t scanlineSize, stripSize;
	uint16 directories;
	uint32 strips, tiles;

	//method
    TIFFInfo(TIFF* tiff);
};
