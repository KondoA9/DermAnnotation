#include "ApplicationData.h"
#include "../../FileManager/FileManager.h"

const FilePath ApplicationData::Path = FileManager::ApplicationDataPath() + U"ApplicationData.bin";

ApplicationData::Data ApplicationData::AppData;

void ApplicationData::Load() {
	Deserializer<BinaryReader> reader(Path);
	if (reader.getReader()) {
		try {
			reader(AppData);
		}
		catch (...) {}
	}
}

void ApplicationData::Save() {
	Serializer<BinaryWriter> writer(Path);
	if (writer.getWriter()) {
		try {
			writer(AppData);
		}
		catch (...) {}
	}
}

void ApplicationData::Remove() {
	FileSystem::Remove(Path);
}
