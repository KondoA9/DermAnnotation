#pragma once

#include "UIPencil/UIPencil.h"

#include <GUIKit.h>

class UIPencilBoxView final : public gui::UIVStackView {
	std::function<void(size_t)> m_pencilChangedHandler;
	std::function<void(size_t, double)> m_pencilAlphaChangedHandler;

public:
	UIPencilBoxView():
		gui::UIVStackView()
	{
		scrollingEnabled = false;
	}

	Pencil pencil(size_t index) const {
		return static_cast<UIPencil*>(components()[index])->pencil();
	}

	void appendPencil(const Pencil& pencil);

	void setPencil(size_t index, const String& name, const Color& color);

	void selectPencil(size_t index);

	void release() override {
		gui::UIVStackView::release();
	}

	size_t pencilCount() const {
		return components().size();
	}

	void setAlphaRate(size_t index, double value) {
		static_cast<UIPencil*>(components()[index])->setAlphaRate(value);
	}

	void setPencilChangedHandler(const std::function<void(size_t)>& pencilChangedHandler) {
		m_pencilChangedHandler = pencilChangedHandler;
	}

	void setPencilAlphaChangedHandler(const std::function<void(size_t index, double value)>& pencilAlphaChangedHandler) {
		m_pencilAlphaChangedHandler = pencilAlphaChangedHandler;
	}
};
