#pragma once

#include "../UIPencilEditorPencilsView/UIPencilEditorPencilsView.h"

#include <GUIKit.h>

class UIPencilEditorSaveView final : public gui::UIView {
	Array<Pencil> m_pencils;

	UIPencilEditorPencilsView ui_pencilsView = UIPencilEditorPencilsView();
	gui::UIButton ui_saveSettingButton = gui::UIButton(U"設定を保存", gui::DynamicColor::Background, gui::DynamicColor::BackgroundSecondary, gui::DynamicColor::Text);

public:
	void setup(const Array<Pencil>& pencils);

protected:
	void initialize() override;
};
