#include "LayerTimeMachine.h"

Optional<size_t> LayerTimeMachine::redo(Array<Image>& layers) {
	if (m_timeMachine.redo()) {
		const auto& layer = m_timeMachine.currentElement().layer;
		if (layers.size() > layer.index) {
			layer.layer.overwrite(layers[layer.index], layer.drawnRect.x, layer.drawnRect.y);
			return layer.index;
		}
	}
	return none;
}

Optional<size_t> LayerTimeMachine::undo(Array<Image>& layers) {
	if (m_timeMachine.undo()) {
		const auto& layer = m_timeMachine.currentElement().differenceLayer.has_value() ?
			m_timeMachine.currentElement().differenceLayer.value() : m_timeMachine.currentElement().layer;
		if (layers.size() > layer.index) {
			layer.layer.overwrite(layers[layer.index], layer.drawnRect.x, layer.drawnRect.y);
			return layer.index;
		}
	}
	return none;
}


void LayerTimeMachine::release() {
	m_tmpImage.release();
	m_timeMachine.release();
}

void LayerTimeMachine::prepare(size_t index, const Array<Image>& layers) {
	m_tmpImage = layers[index];
	m_tmpIndex = index;
}

void LayerTimeMachine::updateLayer(size_t index, const Array<Image>& layers, const Rect& drawnRect) {
	const auto layer = createIndexedLayer(m_tmpIndex, m_tmpImage, drawnRect);

	if (m_timeMachine.hasElement()) {
		m_timeMachine.currentElement().differenceLayer = layer;
	}
	else {
		m_timeMachine.update({ .layer = layer });
	}

	m_timeMachine.update({ .layer = createIndexedLayer(index, layers[index], drawnRect) });
}

LayerTimeMachine::IndexedLayer LayerTimeMachine::createIndexedLayer(size_t index, const Image& layer, const Rect& drawnRect) {
	const int32 width = static_cast<int32>(layer.width());
	const int32 height = static_cast<int32>(layer.height());

	Rect rect = drawnRect;
	rect.x = Clamp(drawnRect.x, 0, width - 1);
	rect.y = Clamp(drawnRect.y, 0, height - 1);

	rect.w = rect.x + drawnRect.w <= width ? drawnRect.w : width - rect.x;
	rect.h = rect.y + drawnRect.h <= height ? drawnRect.h : height - rect.y;

	return {
	.index = index,
	.layer = layer.size() == drawnRect.size ? layer : layer.clipped(rect),
	.drawnRect = rect
	};
}
