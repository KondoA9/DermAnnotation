#include "UIPencilEditorPencilsView.h"

UIPencilEditorPencil* const UIPencilEditorPencilsView::appendPencil(const Pencil& pencil) {
	auto view = UIPencilEditorPencil(pencil);
	view.penetrateMouseEvent = true;
	appendTemporaryComponent(view);

	return static_cast<UIPencilEditorPencil*>(components()[components().size() - 1]);
}
