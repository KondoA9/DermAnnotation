#pragma once

#include <Siv3D.hpp>

struct Pencil {
	String name = U"Pencil";
	Color color = Color(0, 0, 0);
};
