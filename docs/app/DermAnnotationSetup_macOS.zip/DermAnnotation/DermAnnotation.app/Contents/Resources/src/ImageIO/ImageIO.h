#pragma once

#include "../DermImage/DermImage.h"

#include <Siv3D.hpp>

namespace ImageIO {
	bool isAvailableImageType(const FilePath& path);

	DermImage Load(const FilePath& path);

	bool Save(const DermImage& dermImage, const FilePath& path);
}
