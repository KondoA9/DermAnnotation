#include "Pages/Menu/MenuPage.h"
#include "Pages/Setting/SettingPage.h"
#include "Pages/Editor/EditorPage.h"
#include "Pages/Clipping/ClippingPage.h"

#include "Storage/ApplicationData/ApplicationData.h"
#include "Storage/UserConfiguration/UserConfiguration.h"
#include "Storage/FolderHistory/FolderHistory.h"

#include "UsetInterfaces/UINotifier/UINotifier.h"
#include "Updater/Updater.h"

#include <GUIKit.h>

void Main() {
	auto& guikit = gui::GUIKit::Instance();

	// Setup
	LicenseManager::DisableDefaultTrigger();
	Scene::SetTextureFilter(TextureFilter::Nearest);
	Graphics2D::SetSamplerState(0, SamplerState::ClampNearest);
	System::SetTerminationTriggers(UserAction::CloseButtonClicked);
	Window::SetTitle(U"DermAnnotation");

	// Load settings
	ApplicationData::Load();
	UserConfiguration::Load();
	FolderHistory::Load();

	if (ApplicationData::AppData.initialLaunch || ApplicationData::AppData.windowSize.isZero()) {
		ApplicationData::AppData.initialLaunch = false;
		Window::Maximize();
	}
	else {
		Window::Resize(ApplicationData::AppData.windowSize);
	}

	guikit.setColorMode(UserConfiguration::Config.colorMode);

	// Setup pages
	guikit.appendPage<MenuPage>(U"menu");
	guikit.appendPage<SettingPage>(U"setting");
	guikit.appendPage<EditorPage>(U"editor");
	guikit.appendPage<ClippingPage>(U"clipping");

	// Check new version
	guikit.insertAsyncProcess([&guikit] {
        if (Updater::IsNewVersionAvailable()) {
            guikit.insertProcessToMainThread([] {
                UINotifier::Show(U"新しいバージョン {} が利用可能です。"_fmt(Updater::LatestVersion()), UINotifier::MessageType::Info, false);
                });
        }
        });

	// Start
	guikit.start();

	// Save
	ApplicationData::AppData.windowSize = Window::ClientSize();
	ApplicationData::Save();
	UserConfiguration::Save();
	FolderHistory::Save();
}
