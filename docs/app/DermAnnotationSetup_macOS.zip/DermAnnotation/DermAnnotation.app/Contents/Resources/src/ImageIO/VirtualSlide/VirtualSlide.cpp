#include "VirtualSlide.h"

#include <openslide/openslide.h>

namespace ImageIO::VirtualSlide {
	namespace Internal {
		Image ConvertToImage(openslide_t* slide, const int32_t layerLevel, const int64_t width, const int64_t height) {
			uint32_t* dest = new uint32_t[width * height];

			openslide_read_region(slide, dest, 0, 0, layerLevel, width, height);

			Image image(width, height);

#pragma omp parallel for
			for (int y = 0; y < height; ++y) {
				const int64_t yw = y * width;

#pragma omp parallel for
				for (int x = 0; x < width; ++x) {
					const uint32_t pixel = dest[yw + x];
					image[y][x].r = pixel >> 16;
					image[y][x].g = pixel >> 8;
					image[y][x].b = pixel;
					image[y][x].a = pixel >> 24;
				}
			}

			delete[] dest;

			return image;
		}
	}

	DermImage Load(const String& path) {
		const std::string str = path.narrow();
		openslide_t* slide = openslide_open(str.c_str());

		if (slide == nullptr) {
			return DermImage();
		}

		const int32_t layersCount = openslide_get_level_count(slide);
		int64_t width = 0, height = 0;
		DermImage dermImage;

		for (int32_t i = 0; i < layersCount; i++) {
			openslide_get_level_dimensions(slide, i, &width, &height);

#if SIV3D_PLATFORM(WINDOWS)
			if (width <= 16384 && height <= 16384) {
#else
            if (width <= 8192 && height <= 8192) {
#endif
				dermImage.setOriginalImage(Internal::ConvertToImage(slide, i, width, height));
				break;
			}
		}

		openslide_close(slide);

		return dermImage;
	}
}
