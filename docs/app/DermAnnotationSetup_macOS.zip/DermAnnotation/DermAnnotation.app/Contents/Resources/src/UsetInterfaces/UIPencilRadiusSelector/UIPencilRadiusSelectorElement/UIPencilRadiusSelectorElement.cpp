#include "UIPencilRadiusSelectorElement.h"

void UIPencilRadiusSelectorElement::initialize() {
	addEventListener<gui::MouseEvent::Hovered>([this] {
		backgroundColor.highlight(gui::DynamicColor::BackgroundSecondary);
		});
	addEventListener<gui::MouseEvent::UnHovered>([this] {
		backgroundColor.lowlight(gui::DynamicColor::Background);
		});
	addEventListener<gui::MouseEvent::Hovering>([] {
		Cursor::RequestStyle(CursorStyle::Hand);
		});

	ui_circle.penetrateMouseEvent = true;
	ui_circle.setConstraint(gui::LayerDirection::CenterY, *this, gui::LayerDirection::CenterY);
	ui_circle.setConstraint(gui::LayerDirection::CenterX, *this, gui::LayerDirection::CenterX);
	ui_circle.setConstraint(gui::LayerDirection::Height, m_radius);
	ui_circle.setConstraint(gui::LayerDirection::Width, m_radius);

	appendComponent(ui_circle);

	UIView::initialize();
}
