#pragma once

#include "../../../../DermImage/Pencil.h"

#include <GUIKit.h>

class UIPencilEditorPencil final : public gui::UIView {
	Pencil m_pencil;

	gui::UICircle ui_circle = gui::UICircle();
	gui::UIText ui_name = gui::UIText();

public:
	UIPencilEditorPencil(const Pencil& pencil) :
		UIView(),
		m_pencil(pencil),
		ui_circle(gui::UICircle(m_pencil.color)),
		ui_name(gui::UIText(m_pencil.name))
	{}

	Pencil pencil() const {
		return m_pencil;
	}

	void setPencilColor(const Color& color);

	void setPencilName(const String& name);

protected:
	void initialize() override;
};
