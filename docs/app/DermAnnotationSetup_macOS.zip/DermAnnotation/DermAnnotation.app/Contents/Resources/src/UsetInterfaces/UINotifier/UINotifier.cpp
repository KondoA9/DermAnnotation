#include "UINotifier.h"

std::shared_ptr<UINotifier> UINotifier::ui_Notifier = nullptr;

void UINotifier::initialize() {
	setDirection(gui::TextDirection::Center);

	setCornerRadius(7.0_px);
	addEventListener<gui::MouseEvent::LeftDown>([this] {
		hide();
		});

	addEventListener<gui::MouseEvent::Hovering>([] {
		Cursor::RequestStyle(CursorStyle::Hand);
		});

	setConstraint(gui::LayerDirection::Height, [this] {
		return textRegion().h + 30_px; 
		});
	setConstraint(gui::LayerDirection::Bottom, [] {
		return Window::ClientHeight() - 80_px;
		});
	setConstraint(gui::LayerDirection::CenterX, [] {
		return Window::ClientCenter().x;
		});
	setConstraint(gui::LayerDirection::Width, [this] {
		return textRegion().w + 50_px;
		});

	UIText::initialize();
}

void UINotifier::draw() {
	UIText::draw();

	if (!hidden && !m_hideProgress && m_hideAutomatically) {
		m_timer += Scene::DeltaTime();
		if (m_timer > m_hideTime) {
			hide();
		}
	}

	if (backgroundColor.color().a == 0) {
		hidden = true;
	}
}

void UINotifier::Show(const String& message, MessageType type, bool hideAutomatically) {
	if (!ui_Notifier) {
		ui_Notifier = std::make_shared<UINotifier>(UINotifier());
		gui::GUIKit::Instance().appendIsolatedComponent(ui_Notifier);
	}

	const auto [bgColor, txtColor] = MessageColor(type);
	ui_Notifier->backgroundColor.setColor(bgColor, 0.6);
	ui_Notifier->textColor.setColor(txtColor, 0.6);
	ui_Notifier->hidden = false;
	ui_Notifier->setText(message);
	ui_Notifier->m_timer = 0.0;
	ui_Notifier->m_hideProgress = false;
	ui_Notifier->m_hideAutomatically = hideAutomatically;

	ui_Notifier->requestToUpdateLayer();
}

void UINotifier::Hide(bool instant) {
	if (ui_Notifier) {
		if (instant) {
			ui_Notifier->hide(0.0);
		}
		else if (!ui_Notifier->hidden && !ui_Notifier->m_hideProgress) {
			ui_Notifier->hide();
		}
	}
}

std::tuple<gui::ColorTheme, gui::ColorTheme> UINotifier::MessageColor(MessageType type) {
	switch (type)
	{
    case UINotifier::MessageType::Info:
		return { gui::DynamicColor::DefaultBlue, Palette::White };
		break;

    case UINotifier::MessageType::Warning:
		return { gui::DynamicColor::DefaultYellow, Palette::Black };
		break;

    case UINotifier::MessageType::Error:
		return { gui::DynamicColor::DefaultRed, Palette::White };
		break;

	default:
		return { Color(23, 162, 184), Palette::White };
		break;
	}
}

void UINotifier::hide(double transition) {
	backgroundColor.setColor(gui::DynamicColor::Clear, transition);
	textColor.setColor(gui::DynamicColor::Clear, transition);
	m_hideProgress = true;
}
